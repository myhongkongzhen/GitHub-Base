package com.yyfq.base.notify.facade;

import java.util.List;

import com.yyfq.base.notify.common.dto.CateInfoDTO;
import com.yyfq.base.notify.common.dto.Result;

/**
 * @ClassName: PropertyCodeFacade.java
 * @Description: 属性编码表，目前只有银行分类
 * @author zhuweicheng
 * @date 2016年3月17日
 */
public interface BaseInfoFacade {
	
	/**
	 * 通过条件查询属性明细列表
	 * @param cateInfoDto
	 * @return
	 */
	public Result<List<CateInfoDTO>> queryCateInfoList(CateInfoDTO cateInfoDto);
	
}
