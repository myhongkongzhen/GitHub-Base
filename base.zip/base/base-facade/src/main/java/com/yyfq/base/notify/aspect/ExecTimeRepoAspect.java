/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.aspect;

import com.yyfq.base.notify.common.exception.BizException;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.web.controller.aspect.ExecTimeRepoAspect
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 16:27
 *   LastChange: 2016-1-17 16:27
 *      History:
 * </pre>
 **************************************************************************/
@Service
public class ExecTimeRepoAspect
{
    private static final Logger logger = LoggerFactory.getLogger( ExecTimeRepoAspect.class );

    public Object around( ProceedingJoinPoint proceedingJoinPoint ) throws Throwable
    {
        long startTime = System.currentTimeMillis();

        try
        {
            logger.info( "开始执行：{}.{}()...", proceedingJoinPoint.getTarget().getClass().getSimpleName(),
                         proceedingJoinPoint.getSignature().getName() );
            return proceedingJoinPoint.proceed();
        }
        catch ( Throwable e )
        {
            throw BizException.SYSTEM_EXCEPTION.newInstance(
                    StringUtils.join( BizException.SYSTEM_EXCEPTION.getMsg(), "==", e.getMessage() ) );
        }
        finally
        {
            logger.info( "完成执行：{}.{}()，用時：{} sms.", proceedingJoinPoint.getTarget().getClass().getSimpleName(),
                         proceedingJoinPoint.getSignature().getName(), ( System.currentTimeMillis() - startTime ) );
        }
    }
}
