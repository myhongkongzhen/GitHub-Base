package com.yyfq.base.notify.facade.email;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailDTO;

/**
 * @ClassName: EmailFacade.java
 * @Description: 邮箱接口
 * @author zhuweicheng
 * @date 2016年1月28日
 */
public interface EmailFacade {
	
	/**
	 * 发送邮件
	 * @param emailDto
	 * @return Result<EmailDTO>
	 */
	public abstract Result sendEmail(EmailDTO emailDto);
	
}
