/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Properties;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.util.PropertiesUtil
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 00:05
 *   LastChange: 2016-1-26 00:05
 *      History:
 * </pre>
 **************************************************************************/
public enum PropertiesUtil
{
    INSTANCE;

    private static final Logger logger = LoggerFactory.getLogger( PropertiesUtil.class );

    PropertiesUtil()
    {
    }

    public Properties getPropertiesValue( String filename )
    {
        FileInputStream inStream = null;
        try
        {
            Properties serverProps = new Properties();
            URL        url         = Thread.currentThread().getContextClassLoader().getResource( filename );
            if ( null == url )
            {
                throw new FileNotFoundException( filename );
            }
            File file = new File( url.toURI() );
            inStream = new FileInputStream( file );
            serverProps.load( inStream );
            return serverProps;
        }
        catch ( Exception e )
        {
            logger.error( "读取属性文件{}时出现异常：{}.", filename, e.getMessage(), e );
            return null;
        }
        finally
        {
            try
            {
                if ( inStream != null )
                    inStream.close();
            }
            catch ( Exception e )
            {
            }
        }
    }
}
