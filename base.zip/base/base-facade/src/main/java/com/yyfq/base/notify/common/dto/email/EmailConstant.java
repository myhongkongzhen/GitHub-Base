package com.yyfq.base.notify.common.dto.email;

/**
 * @ClassName: EmailConstant.java
 * @Description: 邮箱常量类
 * @author zhuweicheng
 * @date 2016年1月28日
 */
public class EmailConstant {
	
	public static final String EMAIL_SEND_SUCCESS = "1";//发送成功
	public static final String EMAIL_PARAM_NULL = "2";// 发送邮件请求参数为空
	public static final String EMAIL_ERROR = "3";//发送邮件收件地址错误
	public static final String EMAIL_TYPE_ERROR = "4";//邮件类型为空
	public static final String EMAIL_SEND_FAIL = "5";//邮件发送异常
	public static final String EMAIL_INSERT_ERROR = "6";//数据库插入邮件发送记录表异常
	public static final String EMAIL_SEND_CACHE = "7";// 发送被缓存
	public static final String EMAIL_QUEUE_FULL = "8";//邮件发送队列已满,请稍候再发

	/**
	 * 通过错误码获取错误信息
	 * @param param
	 * @return String
	 */
	public static String getMsg(String param) {
		String result = new String();
		switch (param) {
			case "1":
				result = "发送成功";
				break;
			case "2":
				result = "发送邮件请求参数为空";
				break;
			case "3":
				result = "发送邮件收件地址错误";
				break;
			case "4":
				result = "邮件类型为空";
				break;
			case "5":
				result = "邮件发送异常";
				break;
			case "6":
				result = "数据库插入邮件发送记录表异常";
				break;
			case "7":
				result = "发送被缓存";
				break;
			case "8":
				result = "邮件发送队列已满,请稍候再发";
				break;
			default:
				result = "系统错误";
		}
		return result;
	}

}
