/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.template;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.template.MailTemplateEnum
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 00:26
 *   LastChange: 2016-1-26 00:26
 *      History:
 * </pre>
 **************************************************************************/
public enum MailTemplateEnum
{
    MAIL_MEMBER_RES_MA( "会员邮箱注册", 1001 );

    /**
     * 枚举值
     */
    private int type;

    /**
     * 描述
     */
    private String desc;

    MailTemplateEnum( String desc, int type )
    {
        this.desc = desc;
        this.type = type;
    }

    public static String getName( int value )
    {
        String             result  = null;
        MailTemplateEnum[] enumAry = MailTemplateEnum.values();
        for ( int i = 0; i < enumAry.length; i++ )
        {
            if ( value == enumAry[ i ].getType() )
            {
                result = enumAry[ i ].name();
                break;
            }
        }
        return result;
    }

    public int getType()
    {
        return type;
    }

    public void setType( int type )
    {
        this.type = type;
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc( String desc )
    {
        this.desc = desc;
    }
}
