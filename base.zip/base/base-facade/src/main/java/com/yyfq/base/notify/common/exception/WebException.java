/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.exception;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.exception.WebException
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:49
 *   LastChange: 2016-1-18 11:49
 *      History:
 * </pre>
 **************************************************************************/
public class WebException extends BizException
{
    public static final WebException WEB_REQ_ARGS_NULL              = new WebException( 90061000, "ACTION请求参数MSG为空" );
    public static final WebException WEB_REQ_ARGS_FORMAT_ERROR      = new WebException( 90061001, "ACTION请求参数MSG格式错误" );
    public static final WebException WEB_REQ_ARGS_SOURCE_NULL       = new WebException( 90061002, "发送业务通知请求来源异常" );
    public static final WebException WEB_REQ_ARGS_NOTIFY_TYPE_NULL  = new WebException( 90061003, "发送业务通知请求通知类型为空" );
    public static final WebException WEB_REQ_ARGS_DEPART_NULL       = new WebException( 90061004, "发送业务通知请求业务部门异常" );
    public static final WebException WEB_REQ_ARGS_MOBILE_ERROR      = new WebException( 90061005, "发送短信请求目标号码异常" );
    public static final WebException WEB_REQ_ARGS_MAILADRR_ERROR    = new WebException( 90061006, "发送邮件请求目标地址异常" );
    public static final WebException WEB_REQ_ARGS_NOTIFY_TYPE_ERROR = new WebException( 90061007, "发送业务通知请求通知类型不存在" );

    public WebException( int code, String msgFormat, Object... args )
    {
        super( code, msgFormat, args );
    }

    public WebException( String message, Throwable cause )
    {
        super( message, cause );
    }
}
