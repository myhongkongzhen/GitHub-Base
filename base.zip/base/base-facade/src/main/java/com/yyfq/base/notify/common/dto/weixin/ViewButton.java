package com.yyfq.base.notify.common.dto.weixin;

/**
 * @ClassName: ViewButton.java
 * @Description: 微信view菜单按钮，点击弹出二级菜单的那种
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class ViewButton extends Button{
	//view类型菜单url
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
