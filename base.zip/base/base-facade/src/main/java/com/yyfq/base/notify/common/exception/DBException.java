/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.exception;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.exception.DBException
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:47
 *   LastChange: 2016-1-18 11:47
 *      History:
 * </pre>
 **************************************************************************/
public class DBException extends BizException
{
    public static final BizException DB_INSERT_RESULT_0   = new DBException( 90060001, "数据库操作,插入数据库出现异常" );
    public static final BizException DB_UPDATE_RESULT_0   = new DBException( 90060002, "数据库操作,更新数据出现异常" );
    public static final BizException DB_SELECTONE_IS_NULL = new DBException( 90060003, "数据库操作,selectOne返回null" );
    public static final BizException DB_LIST_IS_NULL      = new DBException( 90060004, "数据库操作,list返回null" );
    public static final BizException DB_SYSTEM_EXCEPTION  = new DBException( 90060005, "数据库操作异常" );

    public DBException( int code, String msgFormat, Object... args )
    {
        super( code, msgFormat, args );
    }

    public DBException( String message, Throwable cause )
    {
        super( message, cause );
    }
}
