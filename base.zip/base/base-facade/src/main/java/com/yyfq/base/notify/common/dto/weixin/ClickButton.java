package com.yyfq.base.notify.common.dto.weixin;

/**
 * @ClassName: ClickButton.java
 * @Description: 点击菜单，一点直接跳页面的那种
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class ClickButton extends Button{
	//Click类型菜单key
	private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
