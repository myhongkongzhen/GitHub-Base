/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.exception;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.exception.ServiceException
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:50
 *   LastChange: 2016-1-18 11:50
 *      History:
 * </pre>
 **************************************************************************/
public class ServiceException extends BizException
{
    public static final ServiceException SERVICE_SMS_CHANNEL_EXCEPTION             = new ServiceException( 90062000,
                                                                                                           "短信通道信息缺失，无法发送短信" );
    public static final ServiceException SERVICE_NOTIFY_TYPE_ERROR                 = new ServiceException( 90062001,
                                                                                                           "发送业务通知请求通知类型模板異常" );
    public static final ServiceException SERVICE_NOTIFY_SEND_EXCEPTION             = new ServiceException( 90062002,
                                                                                                           "发送业务通知出现异常" );
    public static final ServiceException SERVICE_NOTIFY_SEND_URL_NULL              = new ServiceException( 90062003,
                                                                                                           "发送业务通知请求URL为null" );
    public static final ServiceException SERVICE_NOTIFY_SEND_URL_EXCEPTION         = new ServiceException( 90062004,
                                                                                                           "发送业务通知请求URL出现异常" );
    public static final ServiceException SERVICE_NOTIFY_SMS_PARSE_RESULT_EXCEPTION = new ServiceException( 90062005,
                                                                                                           "发送业务通知短信通道返回结果解析出现异常" );
    public static final ServiceException SERVICE_NOTIFY_REDIS_SET_EXCEPTION        = new ServiceException( 90062006,
                                                                                                           "发送业务通知Redis出现异常" );
    public static final ServiceException SERVICE_NOTIFY_READ_PROP_EXCEPTION        = new ServiceException( 90062007,
                                                                                                           "发送业务通知读取配置文件出现异常" );

    public ServiceException( int code, String msgFormat, Object... args )
    {
        super( code, msgFormat, args );
    }

    public ServiceException( String message, Throwable cause )
    {
        super( message, cause );
    }
}
