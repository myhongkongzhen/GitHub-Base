package com.yyfq.base.notify.common.dto.weixin;

import java.io.Serializable;
import java.util.Date;
/**
 * @ClassName: WeixinTemplateParam.java
 * @Description: 微信模版封装类
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class WeixinTemplateParam<T> implements Serializable {
	
	private long userId;
	private T data;//模版数据
	private String submitBussName;
	private Date submitBussTime;
	private int type;//操作标识，
	
	public Date getSubmitBussTime() {
		return submitBussTime;
	}
	public void setSubmitBussTime(Date submitBussTime) {
		this.submitBussTime = submitBussTime;
	}
	public String getSubmitBussName() {
		return submitBussName;
	}
	public void setSubmitBussName(String submitBussName) {
		this.submitBussName = submitBussName;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
}
