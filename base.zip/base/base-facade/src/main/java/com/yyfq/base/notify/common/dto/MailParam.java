/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.dto.MailParam
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-22 02:07
 *   LastChange: 2016-1-22 02:07
 *      History:
 * </pre>
 **************************************************************************/
public class MailParam extends Param implements Serializable
{
    /**
     * 收件人
     **/
    private String[] to;
    /**
     * 主题
     **/
    private String   subject;

    public MailParam()
    {

    }

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof MailParam ) )
            return false;
        if ( !super.equals( o ) )
            return false;
        MailParam mailParam = ( MailParam ) o;
        return Arrays.equals( getTo(), mailParam.getTo() ) && Objects.equals( getSubject(), mailParam.getSubject() );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( super.hashCode(), getTo(), getSubject() );
    }

    public String[] getTo()
    {

        return to;
    }

    public void setTo( String[] to )
    {
        this.to = to;
    }

    public String getSubject()
    {
        return subject;
    }

    public void setSubject( String subject )
    {
        this.subject = subject;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "MailParam{" );
        sb.append( "                subject='" ).append( subject ).append( '\'' );
        sb.append( ",                 to=" ).append( Arrays.toString( to ) );
        sb.append( ", super=>" );
        sb.append( super.toString() );
        sb.append( '}' );
        return sb.toString();
    }
}
