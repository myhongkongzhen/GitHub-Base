package com.yyfq.base.notify.common.dto.weixin;

import java.util.Map;

/**
 * @ClassName: WeixinTemplate.java
 * @Description: 微信发送模版
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class WeixinTemplate {

	private String touser;//接收方openId
	private String template_id;//模板ID
	private String url;//点击数据的链接
	private Map<String, Object> data;//数据

	public String getTouser() {
		return touser;
	}

	public void setTouser(String touser) {
		this.touser = touser;
	}

	public String getTemplate_id() {
		return template_id;
	}

	public void setTemplate_id(String template_id) {
		this.template_id = template_id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}

}