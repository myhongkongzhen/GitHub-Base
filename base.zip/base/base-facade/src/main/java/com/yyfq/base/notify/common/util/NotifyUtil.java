/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.util;

import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Pattern;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.NotifyUtil
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 20:20
 *   LastChange: 2016-1-17 20:20
 *      History:
 * </pre>
 **************************************************************************/
public enum NotifyUtil
{
    INSTANCE;

    public final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public final String YYYYMMDDHHMMSS      = "yyyyMMddHHmmss";

    NotifyUtil() { }

    public boolean isEmail( String str )
    {
        Pattern pattern = Pattern.compile( "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$" );
        return pattern.matcher( str ).matches();
    }

    public Date getDate( String date )
    {
        try
        {
            SimpleDateFormat ft = new SimpleDateFormat( YYYY_MM_DD_HH_MM_SS );
            return ft.parse( date );
        }
        catch ( ParseException e )
        {
            return null;
        }
    }

    public Date getDate( String date, String parse )
    {
        try
        {
            SimpleDateFormat ft = new SimpleDateFormat( parse );
            return ft.parse( date );
        }
        catch ( ParseException e )
        {
            return null;
        }
    }

    public boolean checkPhone( String mobile )
    {
        String regex = "^1[3|4|5|7|8][0-9]{9}$";
        return !StringUtils.isBlank( StringUtils.trimToEmpty( mobile ) ) && Pattern.matches( regex, mobile );
    }

    public String getsysuuid()
    {
        String uuid = StringUtils.replace( UUID.randomUUID().toString(), "-", "" );//.substring( 0, 20 );
        return uuid;
    }

    /**
     * 六位随机数字
     *
     * @return
     */
    public String getPhoneCode()
    {
        Random rand   = new Random();
        int    result = rand.nextInt( 999999 );
        // 对0开头的数字进行处理
        return "000000".substring( ( result + "" ).length() ) + result;
    }
}
