package com.yyfq.base.notify.common.dto.email;

import java.io.Serializable;

/**
 * @ClassName: EmailDTO.java
 * @Description: 邮件传输类
 * @author zhuweicheng
 * @date 2016年1月28日
 */
public class EmailDTO implements Serializable {
	
	private String mailTitle;//邮箱标题
	private String fromEmail;//发件人
	private String passWord;//密码
	private String toEmail;//收件人数组，[123@qq.com,456@qq.com]
	private String content;//内容
	private String bussName;//调用服务部门名称
	private Integer type;//邮件类型
	private String append_info;//附加数据，可设为空
	
	public String getFromEmail() {
		return fromEmail;
	}
	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getMailTitle() {
		return mailTitle;
	}
	public void setMailTitle(String mailTitle) {
		this.mailTitle = mailTitle;
	}
	public String getToEmail() {
		return toEmail;
	}
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getBussName() {
		return bussName;
	}
	public void setBussName(String bussName) {
		this.bussName = bussName;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getAppend_info() {
		return append_info;
	}
	public void setAppend_info(String append_info) {
		this.append_info = append_info;
	}
	
}
