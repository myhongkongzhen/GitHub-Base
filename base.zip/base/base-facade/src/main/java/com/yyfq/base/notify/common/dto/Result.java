/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.Result
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 17:38
 *   LastChange: 2016-1-17 17:38
 *      History:
 * </pre>
 **************************************************************************/
public class Result< T > implements Serializable
{
    private static final Logger logger = LoggerFactory.getLogger( Result.class );


    /**
     * 0:成功，非0失敗
     */
    private String ret = "0";
    /**
     * 具體錯誤碼
     */
    private String errCode;
    /**
     * 描述
     */
    private String msg = "SUCCESS";

    private T data;
    
    public static final String FAIL = "-1";
    public static final String SUCCESS = "0";

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof Result ) )
            return false;

        Result< ? > result = ( Result< ? > ) o;

        if ( getRet() != null ? !getRet().equals( result.getRet() ) : result.getRet() != null )
            return false;
        if ( getErrCode() != null ? !getErrCode().equals( result.getErrCode() ) : result.getErrCode() != null )
            return false;
        if ( getMsg() != null ? !getMsg().equals( result.getMsg() ) : result.getMsg() != null )
            return false;
        return getData() != null ? getData().equals( result.getData() ) : result.getData() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getRet() != null ? getRet().hashCode() : 0;
        result = 31 * result + ( getErrCode() != null ? getErrCode().hashCode() : 0 );
        result = 31 * result + ( getMsg() != null ? getMsg().hashCode() : 0 );
        result = 31 * result + ( getData() != null ? getData().hashCode() : 0 );
        return result;
    }

    public String getRet()
    {

        return ret;
    }

    public void setRet( String ret )
    {
        this.ret = ret;
    }

    public String getErrCode()
    {
        return errCode;
    }

    public void setErrCode( String errCode )
    {
        this.errCode = errCode;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg( String msg )
    {
        this.msg = msg;
    }

    public T getData()
    {
        return data;
    }

    public void setData( T data )
    {
        this.data = data;
    }

    public Result()
    {

    }

    public Result( String ret, String errCode, String msg, T data )
    {
        this.ret = ret;
        this.errCode = errCode;
        this.msg = msg;
        this.data = data;
    }

    public Result( T data )
    {
        this.data = data;
    }

    public Result( String ret, String errCode, String msg )
    {
        this.msg = msg;
        this.errCode = errCode;
        this.ret = ret;
    }

    public Result( String ret, String msg )
    {
        this.ret = ret;
        this.msg = msg;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "Result{" );
        sb.append( "data=" ).append( data );
        sb.append( ", errCode='" ).append( errCode ).append( '\'' );
        sb.append( ", msg='" ).append( msg ).append( '\'' );
        sb.append( ", ret='" ).append( ret ).append( '\'' );
        sb.append( '}' );
        return sb.toString();
    }
    
}
