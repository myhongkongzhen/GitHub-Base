/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.exception;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.yyfq.base.notify.common.dto.Result;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.exception.BizException
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:45
 *   LastChange: 2016-1-18 11:45
 *      History:
 * </pre>
 **************************************************************************/
public class BizException extends RuntimeException
{
    private static final long serialVersionUID = -5875371379845226068L;

    public static final BizException SYSTEM_EXCEPTION = new BizException( 90060000, "系统异常,请联系管理员！！！" );

    /**
     * 异常信息
     */
    protected String msg;

    /**
     * 具体异常码
     */
    protected int code;

    public BizException( int code, String msgFormat, Object... args )
    {
        super( String.format( msgFormat, args ) );
        this.code = code;
        this.msg = String.format( msgFormat, args );
    }

    public BizException newInstance( String msgFormat, Object... args )
    {
        return new BizException( this.code, msgFormat, args );
    }

    public static String webExceptionJson( BizException e, Object obj )
    {
        Result rs = new Result();
        rs.setRet( "1" );
        rs.setErrCode( String.valueOf( e.getCode() ) );
        rs.setMsg( e.getMsg() );
        rs.setData( obj );
        return JSONObject.toJSONString( rs, SerializerFeature.WriteMapNullValue );
    }

    public static String webExceptionJson( BizException e )
    {
        Result rs = new Result();
        rs.setErrCode( String.valueOf( e.getCode() ) );
        rs.setMsg( e.getMsg() );
        return JSONObject.toJSONString( rs, SerializerFeature.WriteMapNullValue );
    }

    public BizException( String message, Throwable cause )
    {
        super( message, cause );
    }

    public int getCode()
    {
        return code;
    }

    //    @JSONField( serialize = true )
    public void setCode( int code )
    {
        this.code = code;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg( String msg )
    {
        this.msg = msg;
    }

    @Override
    public synchronized Throwable fillInStackTrace()
    {
        return this;
    }
}
