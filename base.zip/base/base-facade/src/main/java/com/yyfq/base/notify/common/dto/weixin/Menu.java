package com.yyfq.base.notify.common.dto.weixin;

/**
 * @ClassName: Menu.java
 * @Description: 微信菜单
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class Menu {
	//一级菜单
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
	
}
