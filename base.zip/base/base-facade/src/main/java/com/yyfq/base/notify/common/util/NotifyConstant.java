/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.util;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.util.NotifyConstant
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 21:11
 *   LastChange: 2016-1-17 21:11
 *      History:
 * </pre>
 **************************************************************************/
public abstract class NotifyConstant
{

    public static final int    EXPIRE_ONE_HOUR         = 60 * 60; // 60秒(1分鐘) * 60
    public static final int    EXPIRE_FORTYFOUR_HOUR   = 24 * 60 * 60; // 60秒(1分鐘) * 60
    public static final String SMS_CONTENT_TEMPLATE    = "template/sms";
}
