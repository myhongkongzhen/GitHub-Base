package com.yyfq.base.notify.common.dto;

import java.io.Serializable;

/**
 * @ClassName: CateInfoDTO.java
 * @Description: 分类属性明细传输
 * @author zhuweicheng
 * @date 2016年3月17日
 */
public class CateInfoDTO implements Serializable {

	private long id;
	private String cateCode;// 分类编码
	private String name;// 属性名称
	private String code;// 属性编码

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCateCode() {
		return cateCode;
	}

	public void setCateCode(String cateCode) {
		this.cateCode = cateCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "CateInfoDTO [id=" + id + ", cateCode=" + cateCode + ", name="
				+ name + ", code=" + code + "]";
	}

}
