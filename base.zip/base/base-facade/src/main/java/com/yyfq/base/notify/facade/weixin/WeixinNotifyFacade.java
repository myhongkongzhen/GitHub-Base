package com.yyfq.base.notify.facade.weixin;

import com.yyfq.base.notify.common.dto.Result;

/**
 * @ClassName: WeixinNotifyFacade
 * @Description: 微信相关操作接口
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public interface WeixinNotifyFacade<T> {
	
	/**
	 * 发送模版消息
	 * @param WeixinTemplateParam
	 * @return 
	 */
	public Result<Integer> sendWeixinTemplate(final T t);

	/**
	 * 微信服务器有效性验证签名
	 * @param signature
	 * @param timestamp
	 * @param nonce
	 * @return boolean
	 */
	public boolean checkSignature(String signature, String timestamp,
			String nonce);

	/**
	 * 插入微信用户
	 * @param fromUserName：openId
	 * @return result
	 */
	public Result<Object> insertWeixinUser(String openId);

	/**
	 * 更新微信用户基本信息
	 * @param fromUserName
	 * @param nickname
	 * @param sex
	 * @param city
	 * @param country
	 * @param province
	 * @param headimgurl
	 * @return int
	 */
	public Result<Integer> updateWeixinUser(String openId, String nickName,
			int sex, String city, String country, String province,
			String headImgUrl,int subStatus);

	/**
	 * 更新微信用户二维码场景值
	 * @param valueOf
	 * @return
	 */
	public Result<Integer> updateWeixinScene(Integer scene,String openId);

	/**
	 * 修改关注状态
	 * @param fromUserName
	 * @param subStatus
	 * @return int
	 */
	public Result<Integer> updateSubStatus(String fromUserName, int subStatus);

}
