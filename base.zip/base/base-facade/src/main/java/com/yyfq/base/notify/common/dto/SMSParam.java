/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;
import java.util.Objects;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.facade.vo.SMSParam
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-11 12:17
 *   LastChange: 2016-1-11 12:17
 *      History:
 * </pre>
 **************************************************************************/
public class SMSParam extends Param implements Serializable
{
    private static final long serialVersionUID = -5794631498089056181L;

    private String mobile;

    public SMSParam()
    {

    }

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof SMSParam ) )
            return false;
        if ( !super.equals( o ) )
            return false;
        SMSParam param = ( SMSParam ) o;
        return Objects.equals( getMobile(), param.getMobile() );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( super.hashCode(), getMobile() );
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setMobile( String mobile )
    {
        this.mobile = mobile;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "SMSParam{" );
        sb.append( "                mobile='" ).append( mobile ).append( '\'' );
        sb.append( ", super=>" );
        sb.append( super.toString() );
        sb.append( '}' );
        return sb.toString();
    }
}
