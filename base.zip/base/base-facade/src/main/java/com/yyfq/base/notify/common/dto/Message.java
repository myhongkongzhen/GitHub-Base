/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;

/**************************************************************************
 * <pre>
 *     FileName: zzwu.std.util.Message
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 16:57
 *   LastChange: 2016-1-13 16:57
 *      History:
 * </pre>
 **************************************************************************/

public class Message implements Serializable
{
    /**
     * <response>
     * <code>03</code>
     * <message>
     * <desmobile>15098648522</desmobile>
     * <msgid>C4518016011316162400</msgid>
     * </message>
     * </response>
     */

    private String msgid;
    private String desmobile;

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof Message ) )
            return false;

        Message message = ( Message ) o;

        if ( getMsgid() != null ? !getMsgid().equals( message.getMsgid() ) : message.getMsgid() != null )
            return false;
        return getDesmobile() != null ? getDesmobile().equals( message.getDesmobile() )
                                      : message.getDesmobile() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getMsgid() != null ? getMsgid().hashCode() : 0;
        result = 31 * result + ( getDesmobile() != null ? getDesmobile().hashCode() : 0 );
        return result;
    }

    public String getMsgid()
    {

        return msgid;
    }

    public void setMsgid( String msgid )
    {
        this.msgid = msgid;
    }

    public String getDesmobile()
    {
        return desmobile;
    }

    public void setDesmobile( String desmobile )
    {
        this.desmobile = desmobile;
    }

    public Message()
    {

    }
}

