package com.yyfq.base.notify.common.dto.weixin;


import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * @ClassName: TextMessage.java
 * @Description: 微信文本消息类
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@XStreamAlias("TextMessage")
public class TextMessage extends BaseMessage{
	
	private String Content;//消息内容
	private String MsgId;//消息id
	public String getContent() {
		return Content;
	}
	public void setContent(String content) {
		Content = content;
	}
	public String getMsgId() {
		return MsgId;
	}
	public void setMsgId(String msgId) {
		MsgId = msgId;
	}
	
}
