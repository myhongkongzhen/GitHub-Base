package com.yyfq.base.notify.common.util.weixin;

import java.io.InputStream;
import java.util.Properties;

public class WeixinConfigUtil {
	public String getValue(String key) {
		Properties p = new Properties();
		try {
			InputStream in = getClass().getResourceAsStream("weixin.properties");
			p.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p.getProperty(key);
	}
}
