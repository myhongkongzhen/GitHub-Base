/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.facade.status;

import com.yyfq.base.notify.common.exception.BizException;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.facade.status.SMSStatusFacade
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 23:04
 *   LastChange: 2016-1-18 23:04
 *      History:
 * </pre>
 **************************************************************************/
public interface SMSStatusFacade
{
    public void parseResult( String statusbox ) throws BizException;
}
