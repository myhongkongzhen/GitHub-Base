package com.yyfq.base.notify.common.dto;

import java.io.Serializable;

/**
 * @ClassName: QuerySmsDTO.java
 * @Description: 查询短信传输类
 * @author zhuweicheng
 * @date 2016年2月19日
 */
public class QuerySmsDTO implements Serializable {
	
	private String mobile;//手机号
	private String content;//短信内容
	private String department;//调用服务部门
	private String startDate;//查询开始时间
	private String endDate;//查询结束时间
	private String channel;//通道
	private String source;//来源
	private String status;//状态
	private String sendTime;//短信发送时间
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}
	
}
