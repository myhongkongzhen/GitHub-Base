/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;

/**************************************************************************
 * <pre>
 *     FileName: ChannelEntity
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-12 16:06
 *   LastChange: 2016-1-12 16:06
 *      History:
 * </pre>
 **************************************************************************/
public class ChannelEntity implements Serializable, Comparable<ChannelEntity>
{
    private static final long serialVersionUID = 848521177386112391L;
    private volatile int     weight;
    private          String  channelCode;
    private volatile boolean status;

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof ChannelEntity ) )
            return false;

        ChannelEntity that = ( ChannelEntity ) o;

        if ( getWeight() != that.getWeight() )
            return false;
        if ( isStatus() != that.isStatus() )
            return false;
        return getChannelCode() != null ? getChannelCode().equals( that.getChannelCode() )
                                        : that.getChannelCode() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getWeight();
        result = 31 * result + ( getChannelCode() != null ? getChannelCode().hashCode() : 0 );
        result = 31 * result + ( isStatus() ? 1 : 0 );
        return result;
    }

    public boolean isStatus()
    {

        return status;
    }

    public void setStatus( boolean status )
    {
        this.status = status;
    }

    public int getWeight()
    {
        return weight;
    }

    public void setWeight( int weight )
    {
        this.weight = weight;
    }

    public String getChannelCode()
    {
        return channelCode;
    }

    public void setChannelCode( String channelCode )
    {
        this.channelCode = channelCode;
    }

    public ChannelEntity()
    {

    }
    
    @Override
	public int compareTo(ChannelEntity o) {
		if(o!=null){
            if(this.getWeight()>o.getWeight()){
               return 1;
            }else if(this.getWeight()==o.getWeight()){
               return 0;
            }
       }
        return -1;
	}

}
