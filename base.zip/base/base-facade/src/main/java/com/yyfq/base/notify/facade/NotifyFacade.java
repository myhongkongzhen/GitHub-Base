/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.facade;

import com.yyfq.base.notify.common.dto.QuerySmsDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.exception.BizException;

import java.util.Collection;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.facade.NotifyFacade
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:11
 *   LastChange: 2016-1-18 11:11
 *      History:
 * </pre>
 **************************************************************************/
public interface NotifyFacade< T >
{
    /**
     * 邮件服务可支持同一邮件内容，多个目标邮件地址
     * 短信服务只支持同一内容一个目标手机号码
     *
     * @param t
     *
     * @return
     *
     * @throws BizException
     */
    public Result< T > sendSingleMsg( final T t ) throws BizException;

    /**
     * 邮件短信、邮件 不同內容，不同目標号码、邮件地址发送
     *
     * @param list
     *
     * @return
     *
     * @throws BizException
     */
    public Result< T > sendMultMsg( final Collection< T > list ) throws BizException;
    
    /**
	 * 查询短信数据
	 * @param param
	 * @return Result<Object>
	 */
	Result<Object> querySmsData(QuerySmsDTO querySmsDto);
}
