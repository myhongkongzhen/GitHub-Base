package com.yyfq.base.notify.common.dto.weixin;

public class WeixinErrCode {
	public static final String WX_ERR_ONE = "1";//微信用户已存在
	public static final String WX_ERR_TWO = "2";//首次添加微信用户失败
	public static final String WX_ERR_THREE = "3";//微信用户已关注
	public static final String WX_ERR_FOUR = "4";//微信用户更新详细数据失败;
	public static final String WX_ERR_FIVE = "5";//更新微信二维码场景值失败
	public static final String WX_ERR_SEX = "6";//更新微信二维码场景值失败
	public static final String WX_ERR_SEVEN = "7";//用户openId不存在
	public static final String WX_ERR_EIGHT = "8";//发送微信模版消息失败

}
