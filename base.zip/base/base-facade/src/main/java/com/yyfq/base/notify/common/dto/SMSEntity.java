/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;
import java.util.Date;

/**************************************************************************
 * <pre>
 *     FileName: SMSEntity
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-12 16:05
 *   LastChange: 2016-1-12 16:05
 *      History:
 * </pre>
 **************************************************************************/
public class SMSEntity implements Serializable
{
    private static final long serialVersionUID = -8259290324650083838L;
    private String mobile;
    private String content;
    private Date   sendtime;
    private String smsid;
    private String channelDesc;

    private String notifysysuuid;

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof SMSEntity ) )
            return false;

        SMSEntity smsEntity = ( SMSEntity ) o;

        if ( getMobile() != null ? !getMobile().equals( smsEntity.getMobile() ) : smsEntity.getMobile() != null )
            return false;
        if ( getContent() != null ? !getContent().equals( smsEntity.getContent() ) : smsEntity.getContent() != null )
            return false;
        if ( getSendtime() != null ? !getSendtime().equals( smsEntity.getSendtime() )
                                   : smsEntity.getSendtime() != null )
            return false;
        if ( getSmsid() != null ? !getSmsid().equals( smsEntity.getSmsid() ) : smsEntity.getSmsid() != null )
            return false;
        if ( getChannelDesc() != null ? !getChannelDesc().equals( smsEntity.getChannelDesc() )
                                      : smsEntity.getChannelDesc() != null )
            return false;
        if ( getNotifysysuuid() != null ? !getNotifysysuuid().equals( smsEntity.getNotifysysuuid() )
                                        : smsEntity.getNotifysysuuid() != null )
            return false;
        if ( getChannelStatus() != null ? !getChannelStatus().equals( smsEntity.getChannelStatus() )
                                        : smsEntity.getChannelStatus() != null )
            return false;
        if ( getChannelEntity() != null ? !getChannelEntity().equals( smsEntity.getChannelEntity() )
                                        : smsEntity.getChannelEntity() != null )
            return false;
        return getSmsParam() != null ? getSmsParam().equals( smsEntity.getSmsParam() )
                                     : smsEntity.getSmsParam() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getMobile() != null ? getMobile().hashCode() : 0;
        result = 31 * result + ( getContent() != null ? getContent().hashCode() : 0 );
        result = 31 * result + ( getSendtime() != null ? getSendtime().hashCode() : 0 );
        result = 31 * result + ( getSmsid() != null ? getSmsid().hashCode() : 0 );
        result = 31 * result + ( getChannelDesc() != null ? getChannelDesc().hashCode() : 0 );
        result = 31 * result + ( getNotifysysuuid() != null ? getNotifysysuuid().hashCode() : 0 );
        result = 31 * result + ( getChannelStatus() != null ? getChannelStatus().hashCode() : 0 );
        result = 31 * result + ( getChannelEntity() != null ? getChannelEntity().hashCode() : 0 );
        result = 31 * result + ( getSmsParam() != null ? getSmsParam().hashCode() : 0 );
        return result;
    }

    public String getNotifysysuuid()
    {

        return notifysysuuid;
    }

    public void setNotifysysuuid( String notifysysuuid )
    {
        this.notifysysuuid = notifysysuuid;
    }

    public String getChannelDesc()
    {

        return channelDesc;
    }

    public void setChannelDesc( String channelDesc )
    {
        this.channelDesc = channelDesc;
    }

    public String getChannelStatus()
    {

        return channelStatus;
    }

    public void setChannelStatus( String channelStatus )
    {
        this.channelStatus = channelStatus;
    }

    private String channelStatus;

    private volatile ChannelEntity channelEntity;
    private          SMSParam      smsParam;

    public SMSParam getSmsParam()
    {

        return smsParam;
    }

    public void setSmsParam( SMSParam smsParam )
    {
        this.smsParam = smsParam;
    }

    public String getMobile()
    {

        return mobile;
    }

    public void setMobile( String mobile )
    {
        this.mobile = mobile;
    }

    public String getContent()
    {
        return content;
    }

    public void setContent( String content )
    {
        this.content = content;
    }

    public Date getSendtime()
    {
        return sendtime;
    }

    public void setSendtime( Date sendtime )
    {
        this.sendtime = sendtime;
    }

    public String getSmsid()
    {
        return smsid;
    }

    public void setSmsid( String smsid )
    {
        this.smsid = smsid;
    }

    public ChannelEntity getChannelEntity()
    {
        return channelEntity;
    }

    public void setChannelEntity( ChannelEntity channelEntity )
    {
        this.channelEntity = channelEntity;
    }

    public SMSEntity()
    {

    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "SMSEntity{" );
        sb.append( "channelDesc='" ).append( channelDesc ).append( '\'' );
        sb.append( ", channelEntity=" ).append( channelEntity );
        sb.append( ", channelStatus='" ).append( channelStatus ).append( '\'' );
        sb.append( ", content='" ).append( content ).append( '\'' );
        sb.append( ", mobile='" ).append( mobile ).append( '\'' );
        sb.append( ", notifysysuuid='" ).append( notifysysuuid ).append( '\'' );
        sb.append( ", sendtime=" ).append( sendtime );
        sb.append( ", smsid='" ).append( smsid ).append( '\'' );
        sb.append( ", smsParam=" ).append( smsParam );
        sb.append( '}' );
        return sb.toString();
    }
}
