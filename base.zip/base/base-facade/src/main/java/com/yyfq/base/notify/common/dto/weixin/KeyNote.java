package com.yyfq.base.notify.common.dto.weixin;

/**
 * @ClassName: KeyNote.java
 * @Description: 模版消息内容
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class KeyNote {
	
	private String value;// 信息
	private String color;// 字体颜色

	public KeyNote(String v, String c) {
		this.value = v;
		this.color = c;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
