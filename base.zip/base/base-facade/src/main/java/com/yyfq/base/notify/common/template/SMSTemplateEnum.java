/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.template;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.template.SMSTemplateEnum
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 00:26
 *   LastChange: 2016-1-26 00:26
 *      History:
 * </pre>
 **************************************************************************/
public enum SMSTemplateEnum
{
    MES_RES_MOB( "手机号注册", 2001 ),
    MES_BANG_MOB( "绑定手机", 2002 ),
    MES_FIND_CODE_LOGIN( "找回登录密码", 2003 ),
    MES_TRANS_REC( "转账-免费通知收款人", 2004 ),
    MES_BANG_MOB_MOD( "修改绑定手机", 2005 ),
    MES_FIND_CODE_PAY( "找回支付密码", 2006 ),
    MES_APP_DC( "数字证书申请", 2007 ),
    MES_COM_INF_MOD( "修改商户信息", 2008 ),
    MES_JYXE_US( "会员交易限额", 2009 ),
    MES_JYXE_ME( "商户交易限额", 2010 ),
    MES_RESET_CODE( "重置密码", 2011 );

    /**
     * 枚举值
     */
    private int type;

    /**
     * 描述
     */
    private String desc;

    SMSTemplateEnum( String desc, int type )
    {
        this.desc = desc;
        this.type = type;
    }
}
