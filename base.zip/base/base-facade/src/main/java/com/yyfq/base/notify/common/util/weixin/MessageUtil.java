package com.yyfq.base.notify.common.util.weixin;


import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import com.thoughtworks.xstream.XStream;
import com.yyfq.base.notify.common.dto.weixin.BaseMessage;
import com.yyfq.base.notify.common.dto.weixin.TextMessage;

/**
 * @ClassName: MessageUtil.java
 * @Description: 主要进行一些消息的格式转换，微信那边用的是xml格式
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class MessageUtil {
	/**
	 * 文本消息
	 */
	public static final String MESSAGE_TEXT = "text";
	/**
	 * 图文消息
	 */
	public static final String MESSAGE_NEWS = "news";
	/**
	 * 图片消息
	 */
	public static final String MESSAGE_IMAGE = "image";
	/**
	 * 语音消息
	 */
	public static final String MESSAGE_VOICE = "voice";
	/**
	 * 音乐消息
	 */
	public static final String MESSAGE_MUSIC = "music";
	/**
	 * 视频消息
	 */
	public static final String MESSAGE_VIDEO = "video";
	/**
	 * 链接消息
	 */
	public static final String MESSAGE_LINK = "link";
	/**
	 * 地理位置消息
	 */
	public static final String MESSAGE_LOCATION = "location";
	/**
	 * 事件消息
	 */
	public static final String MESSAGE_EVNET = "event";
	/**
	 * 关注
	 */
	public static final String MESSAGE_SUBSCRIBE = "subscribe";
	/**
	 * 取消关注
	 */
	public static final String MESSAGE_UNSUBSCRIBE = "unsubscribe";
	/**
	 * 点击
	 */
	public static final String MESSAGE_CLICK = "CLICK";
	public static final String MESSAGE_VIEW = "VIEW";
	public static final String MESSAGE_SCANCODE= "scancode_push";
	/**
	 * 用户已关注时的事件推送
	 */
	public static final String MESSAGE_SCAN = "SCAN";
	/**
	 * 多客服
	 */
	public static final String MESSAGE_TRANSFER_CUSTOMER_SERVICE = "transfer_customer_service";
	
	/**
	 * xml转换成map集合
	 * @param request
	 * @return Map
	 * @throws IOException
	 * @throws DocumentException
	 */
	public static Map<String,String> xmlToMap(HttpServletRequest request) throws IOException, DocumentException{
		Map<String,String> map = new HashMap<String,String>();
		SAXReader reader = new SAXReader();
		InputStream is = request.getInputStream();
		Document doc = reader.read(is);
		Element root = doc.getRootElement();
		List<Element> list = root.elements(); 
		
		for(Element element:list){
			map.put(element.getName(), element.getText());
		}
		is.close();
		return map;
	}
	
	/**
	 * 将文本消息对象转换为xml
	 * @param textMessage
	 * @return String
	 */
	public static String textMessageToXml(TextMessage textMessage){
		XStream xstream = new XStream();
		xstream.alias("xml", textMessage.getClass());
		return xstream.toXML(textMessage);
	}
	
	/**
	 * 基本信息转成xml
	 * @param baseMessage
	 * @return String
	 */
	public static String baseMessageToXml(BaseMessage baseMessage){
		XStream xstream = new XStream();
		xstream.alias("xml", baseMessage.getClass());
		return xstream.toXML(baseMessage);
	}
	
	/**
	 * 组装文本消息
	 * @param toUserName
	 * @param fromUserName
	 * @param content
	 * @return String
	 */
	public static String initText(String toUserName,String fromUserName,String content){
		TextMessage textMessage = new TextMessage();
		//此处是反的，返回消息给用户
		textMessage.setFromUserName(toUserName);
		textMessage.setToUserName(fromUserName);
		textMessage.setContent(content);
		textMessage.setMsgType(MessageUtil.MESSAGE_TEXT);
		textMessage.setCreateTime(new Date().getTime());
		return textMessageToXml(textMessage);
	}
	
	/**
	 * 把消息转发到多客服
	 * @param toUserName
	 * @param fromUserName
	 * @return String
	 */
	public static String toDuokefu(String toUserName,String fromUserName){
		BaseMessage duokefu = new BaseMessage();
		duokefu.setFromUserName(toUserName);
		duokefu.setToUserName(fromUserName);
		duokefu.setMsgType(MessageUtil.MESSAGE_TRANSFER_CUSTOMER_SERVICE);
		duokefu.setCreateTime(new Date().getTime());
		
		return baseMessageToXml(duokefu);
	}
	
	/**
	 * 测试关注回复
	 * @return String
	 */
	public static String menuText() {
		StringBuffer sb = new StringBuffer();
		sb.append("欢迎关注维成之光，请按菜单中的提示进行操作:\n\n");
		sb.append("1:测试介绍\n");
		sb.append("2:相关描述\n");
		sb.append("回复？调出此菜单");
		return sb.toString();
	}
	
	/**
	 * 测试发文本1处理
	 * @return String
	 */
	public static String firstMenu() {
		StringBuffer sb = new StringBuffer();
		sb.append("你向公从号发送了1，为了测试微信开发的接口");
		return sb.toString();
	}
	
	/**
	 * 测试发文本2处理
	 * @return String
	 */
	public static String secondMenu() {
		StringBuffer sb = new StringBuffer();
		sb.append("你向公从号发送了2，为了测试微信开发的接口");
		return sb.toString();
	}

	

}

