/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.aspect;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.web.controller.aspect.ExceptionAspect
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 16:31
 *   LastChange: 2016-1-17 16:31
 *      History:
 * </pre>
 **************************************************************************/
@Service
public class ExceptionAspect
{
    private static final Logger logger = LoggerFactory.getLogger( ExceptionAspect.class );

    public void afterThrowing( Throwable e )
    {
        logger.error( "平台系統发生未检测异常:{}！！！！", e.getMessage(), e );
    }

//    public void afterThrowing( Method method, Object[] args, Object target, Throwable e )
//    {
//        logger.error( "平台系統发生未检测异常,发生异常类方法：{}.{}({})...", target.getClass().getName(), method.getName(),
//                      JSONObject.toJSONString( args ) );
//        logger.error( "异常信息：{}>>>>{}！！！！", e.getMessage(), e.getCause() );
//        logger.error( "详细异常信息：{}!!!!!!", e.fillInStackTrace() );
//    }
}
