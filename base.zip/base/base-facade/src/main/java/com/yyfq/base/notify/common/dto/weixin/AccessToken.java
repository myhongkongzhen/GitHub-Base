package com.yyfq.base.notify.common.dto.weixin;


/**
 * @ClassName: AccessToken.java
 * @Description: 微信票据
 * @author zhuweicheng
 * @date 2016年1月22日
 */
public class AccessToken {

	private String token;//凭证 
	private int expiresIn;//凭证有效时间
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public int getExpiresIn() {
		return expiresIn;
	}
	public void setExpiresIn(int expiresIn) {
		this.expiresIn = expiresIn;
	}
	
}
