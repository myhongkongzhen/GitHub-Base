package com.yyfq.base.notify.common.util.weixin;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.weixin.AccessToken;
import com.yyfq.base.notify.common.dto.weixin.Button;
import com.yyfq.base.notify.common.dto.weixin.ClickButton;
import com.yyfq.base.notify.common.dto.weixin.Menu;
import com.yyfq.base.notify.common.dto.weixin.ViewButton;
import com.yyfq.base.notify.common.dto.weixin.WeixinBaseInfo;

/**
 * @ClassName: WeixinUtil
 * @Description: 微信工具类
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@SuppressWarnings("deprecation")
public class WeixinUtil {
	
	public static final String APPID = "wxe5a91bb2b48b2b0b";
	public static final String APPSECRET = "f9f0b211e5451dfba9cab31b7f9f9d0f";
	
	//测试号，维成之光公众号
	public static final String APPID_TEST = "wx26991282ba3b54c5";
	public static final String APPSECRET_TEST = "d4624c36b6795d1d99dcf0547af5443d";
	
	//获取token
	public static final String ACCESS_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
	
	//创建菜单
	public static final String CREATE_MENU_URL = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN";
	
	//OAUTH2.0授权，获取code值
	public static final String OAUTH_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=APPID&redirect_uri=REDIRECT_URI&response_type=code&scope=SCOPE&state=STATE#wechat_redirect";
	
	//根据code获取openid
	public static final String GET_OPENID_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
	
	//生成二维码
	public static final String CREATE_TWOCODE_URL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=TOKEN";
	
	//查看二维码
	public static final String SHOW_TWOCODE_URL ="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=TICKET";
	
	//获取用户基本信息
	public static final String USER_BASE_INFO_URL = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";
	
	//设置所属行业
	public static final String MSG_TEMPLATE_INDUSTRY_URL = "https://api.weixin.qq.com/cgi-bin/template/api_set_industry?access_token=ACCESS_TOKEN";
	
	//获取模板ID
	public static final String MSG_TEMPLATE_ID_URL = "https://api.weixin.qq.com/cgi-bin/template/api_add_template?access_token=ACCESS_TOKEN";
	
	//发送模板消息
	public static String MSG_TEMPLATE_SEND_URL = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=ACCESS_TOKEN";
	
	//微信模版id
	public static String WEIXIN_TEMPLATE_TEST = "VBX16gm3dcaM_CmrKBIwyHmIWJ4A-pIKeh-sT5Zi7PY";
	
	//获取模板列表详细信息
	public static String WEIXIN_TEMPLATE_LIST = "https://api.weixin.qq.com/cgi-bin/template/get_all_private_template?access_token=ACCESS_TOKEN";
	
	//获取jsapi_ticket
	public static String WEIXIN_JS_TICKET = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi";
	
	/**
	 * get请求
	 * @param url
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject doGetStr(String url) throws ClientProtocolException, IOException{
		DefaultHttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(url);
		JSONObject jsonObject = null;
		HttpResponse httpResponse = client.execute(httpGet);
		HttpEntity httpEntity = httpResponse.getEntity();
		if(httpEntity != null){
			String result = EntityUtils.toString(httpEntity, "UTF-8");
			jsonObject = JSONObject.parseObject(result);
		}
		
		return jsonObject;
	}
	
	/**
	 * Post请求
	 * @param url
	 * @param outStr
	 * @return JSONObject
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject doPostStr(String url,String outStr) throws ClientProtocolException, IOException{
		DefaultHttpClient client = new DefaultHttpClient();
		HttpPost httpPost = new HttpPost(url);
		JSONObject jsonObject = null;
		HttpEntity httpEntity = new StringEntity(outStr, "UTF-8");
		httpPost.setEntity(httpEntity);
		HttpResponse httpResponse = client.execute(httpPost);
		String result = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
		jsonObject = JSONObject.parseObject(result);
		
		return jsonObject;
	}
	
	/*public static boolean isDemo(HttpServletRequest request){
		String projectPath  = request.getSession().getServletContext().getRealPath(File.separator);
		ConfigRead read = new ConfigRead(projectPath);
		String isDemo = read.getValue("isDemo");
		if("1".equals(isDemo)){
			return true;
		}
		
		return false;
	}*/
	
	/**
	 * 获取accessToken
	 * @param request
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @return AccessToken
	 */
	public static AccessToken getAccessToken(HttpServletRequest request) throws ClientProtocolException, IOException{
		AccessToken token = new AccessToken();
		String url = null;
		url = ACCESS_TOKEN_URL.replace("APPID", APPID_TEST).replace("APPSECRET", APPSECRET_TEST);
		/*if(isDemo(request)){
		} else {
			url = ACCESS_TOKEN_URL.replace("APPID", APPID_TEST).replace("APPSECRET", APPSECRET_TEST);
		}*/
		
		JSONObject jsonObject = doGetStr(url);
		
		if(jsonObject != null){
			token.setToken(jsonObject.getString("access_token"));
			token.setExpiresIn(jsonObject.getIntValue("expires_in"));
		}
		
		return token;
	}
	
	/**
	 * 获取AccessToken,微信接口凭据
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @return AccessToken
	 */
	public static AccessToken getAccessToken() throws ClientProtocolException, IOException{
		AccessToken token = new AccessToken();
		
		String url = ACCESS_TOKEN_URL.replace("APPID", APPID_TEST).replace("APPSECRET", APPSECRET_TEST);
		
		JSONObject jsonObject = doGetStr(url);
		
		if(jsonObject != null){
			token.setToken(jsonObject.getString("access_token"));
			token.setExpiresIn(jsonObject.getIntValue("expires_in"));
		}
		
		return token;
	}
	
	/**
	 * 发送模版消息时的获取凭据
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @return AccessToken
	 */
	public static AccessToken getAccessTokenLine() throws ClientProtocolException, IOException{
		AccessToken token = new AccessToken();
		
		String url = ACCESS_TOKEN_URL.replace("APPID", APPID_TEST).replace("APPSECRET", APPSECRET_TEST);
		
		JSONObject jsonObject = doGetStr(url);
		
		if(jsonObject != null){
			token.setToken(jsonObject.getString("access_token"));
			token.setExpiresIn(jsonObject.getIntValue("expires_in"));
		}
		
		return token;
	}
	
	/**
	 * 获取用户基本信息
	 * @param token
	 * @param openid
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 * @return WeixinBaseInfo
	 */
	public static WeixinBaseInfo getUserBaseInfo(String token,String openid) throws ClientProtocolException, IOException{
		WeixinBaseInfo ubf = null;
		String url = USER_BASE_INFO_URL.replace("ACCESS_TOKEN", token).replace("OPENID", openid);
		
		JSONObject jsonObject = doGetStr(url);
		if(jsonObject != null){
			int subscribe = jsonObject.getIntValue("subscribe");
			if( subscribe != 0){
				ubf = new WeixinBaseInfo();
				ubf.setNickname(jsonObject.getString("nickname"));
				ubf.setSex(jsonObject.getIntValue("sex"));
				ubf.setCity(jsonObject.getString("city"));
				ubf.setCountry(jsonObject.getString("country"));
				ubf.setProvince(jsonObject.getString("province"));
				ubf.setHeadimgurl(jsonObject.getString("headimgurl"));
			}
		}
		
		return ubf;
	}
	
	/**
	 * 组装菜单
	 * @return
	 * @throws UnsupportedEncodingException 
	 * @return Menu
	 */
	public static Menu initMenu() throws UnsupportedEncodingException{
		Menu menu = new Menu();
		
		ViewButton button1 = new ViewButton();
		String index = "http://m.yyfq.com/";
		String url1 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(index, "utf-8")).replace("APPID", WeixinUtil.APPID).replace("SCOPE", "snsapi_base");
		
		button1.setName("我要投资");
		button1.setType("view");
		button1.setUrl(url1);
		
		ViewButton button25 = new ViewButton();
		button25.setName("周年庆活动");
		button25.setType("view");
		button25.setUrl("http://m.yyfq.com/activity/mapDial/mapDial.html");
		
		ViewButton button24 = new ViewButton();
		button24.setName("财商测试");
		button24.setType("view");
		button24.setUrl("http://m.yyfq.com/activity/weixinTest/FQda.html");
		
		ViewButton button31 = new ViewButton();
		String register = "http://m.yyfq.com/register/register.html";
		String url31 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(register, "utf-8")).replace("APPID", WeixinUtil.APPID).replace("SCOPE", "snsapi_base");
		button31.setName("注册");
		button31.setType("view");
		button31.setUrl(url31);
		
		ViewButton button32 = new ViewButton();
		String login = "http://m.yyfq.com/login/login.html";
		String url32 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(login, "utf-8")).replace("APPID", WeixinUtil.APPID).replace("SCOPE", "snsapi_base");
		button32.setName("登录");
		button32.setType("view");
		button32.setUrl(url32);
		
		ClickButton button33 = new ClickButton();
		button33.setName("联系客服");
		button33.setType("click");
		button33.setKey("33");
		
		
		Button button2 = new Button();
		button2.setName("精彩活动");
		button2.setSub_button(new Button[]{button25,button24});
		
		Button button3 = new Button();
		button3.setName("注册登录");
		button3.setSub_button(new Button[]{button31,button32,button33});
		
		menu.setButton(new Button[]{button1,button2,button3});
		
		return menu;
	}
	
	/**
	 * 测试环境组装微信菜单
	 * @return
	 * @throws UnsupportedEncodingException
	 * @return Menu
	 */
	public static Menu initMenuTest() throws UnsupportedEncodingException{
		Menu menu = new Menu();
		
		ViewButton button1 = new ViewButton();
		String index = "http://m.yyfq.com/";
		//String url1 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(index, "utf-8")).replace("APPID", WeixinUtil.APPID_TEST).replace("SCOPE", "snsapi_base");
		
		button1.setName("有用无忧");
		button1.setType("view");
		button1.setUrl(index);
		
		ViewButton button25 = new ViewButton();
		button25.setName("腾讯");
		button25.setType("view");
		button25.setUrl("http://qq.com");
		
		ViewButton button24 = new ViewButton();
		button24.setName("新浪");
		button24.setType("view");
		String xinna = "http://sina.com";
		button24.setUrl(xinna);
		
		ViewButton button31 = new ViewButton();
		String register = "http://m.yyfq.com/consumer/html/login?source=wx";
//		String url31 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(register, "utf-8")).replace("APPID", WeixinUtil.APPID_TEST).replace("SCOPE", "snsapi_base");
		button31.setName("登录");
		button31.setType("view");
		button31.setUrl(register);
		
		ViewButton button32 = new ViewButton();
		String wy = "http://m.yyfq.com/consumer/html/register?source=wx";
//		String url32 = OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(login, "utf-8")).replace("APPID", WeixinUtil.APPID_TEST).replace("SCOPE", "snsapi_base");
		button32.setName("注册");
		button32.setType("view");
		button32.setUrl(wy);
		
		ClickButton button33 = new ClickButton();
		button33.setName("联系客服");
		button33.setType("click");
		button33.setKey("33");
		
		
		Button button2 = new Button();
		button2.setName("腾讯新浪");
		button2.setSub_button(new Button[]{button25,button24});
		
		Button button3 = new Button();
		button3.setName("登录注册");
		button3.setSub_button(new Button[]{button31,button32,button33});
		
		menu.setButton(new Button[]{button1,button2,button3});
		
		return menu;
	}
	
	/**
	 * 创建菜单
	 * @param token
	 * @param menu
	 * @return
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 * @return int
	 */
	public static int createMenu(String token,String menu) throws ClientProtocolException, IOException{
		int result = 0;
		String url = CREATE_MENU_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = doPostStr(url, menu);
		if(jsonObject != null){
			result = jsonObject.getIntValue("errcode");
		}
		return result;
	}
	
	/**
	 * 创建二维码
	 * @param token
	 * @param twoCode
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @return JSONObject
	 */
	public static JSONObject createTwoCode(String token,String twoCode) throws ClientProtocolException, IOException{
		String url = CREATE_TWOCODE_URL.replace("TOKEN", token);
		return doPostStr(url,twoCode);
	}

	/**
	 * 获取用户openid
	 * @param code
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @return String
	 */
	public static String getOpenid(String code,HttpServletRequest request) throws ClientProtocolException, IOException{
		String result = null;
		String url = "";
		url = GET_OPENID_URL.replace("APPID", APPID).replace("SECRET",APPSECRET).replace("CODE", code);
		/*if(isDemo(request)){
		} else {
			url = GET_OPENID_URL.replace("APPID", APPID_TEST).replace("SECRET",APPSECRET_TEST).replace("CODE", code);
		}*/
		JSONObject jsonObject = doGetStr(url);
		if(jsonObject != null){
			result = jsonObject.getString("openid");
		}
		return result;
	}
	
	/**
	 * 模板消息设置行业属性
	 * @param token
	 * @param industry
	 * @return JSONObject
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject setIndustry(String token,String industry) throws ClientProtocolException, IOException{
		String url = MSG_TEMPLATE_INDUSTRY_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = doPostStr(url,industry);
		return jsonObject;
	}
	
	/**
	 * 获得消息模板ID
	 * @param token
	 * @param templateid
	 * @return JSONObject
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject getTemplateid(String token,String templateid) throws ClientProtocolException, IOException{
		String url = MSG_TEMPLATE_ID_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = doPostStr(url,templateid);
		return jsonObject;
	}
	
	/**
	 * 发送模板消息
	 * @param token
	 * @param templateMsg
	 * @return JSONObject
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static JSONObject sendTemplateMsg(String token,String templateMsg) throws ClientProtocolException, IOException{
		String url = MSG_TEMPLATE_SEND_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = doPostStr(url,templateMsg);
		return jsonObject;
	}

	/**
	 * 获取模版列表详细信息
	 * @param token
	 * @return
	 * @throws IOException
	 * @return JSONObject
	 */
	public static JSONObject getTemplateList(String token) throws IOException{
		// TODO Auto-generated method stub
		String url = WEIXIN_TEMPLATE_LIST.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = doGetStr(url);
		return jsonObject;
	}
	
}
