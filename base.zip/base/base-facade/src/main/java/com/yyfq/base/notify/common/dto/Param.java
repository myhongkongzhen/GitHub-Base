/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common.dto;

import java.io.Serializable;
import java.util.Date;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.facade.vo.SMSParam
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-11 12:17
 *   LastChange: 2016-1-11 12:17
 *      History:
 * </pre>
 **************************************************************************/
public class Param implements Serializable
{
    private static final long serialVersionUID = -5794631498089056181L;

    /**
     * 系統全局唯一uuid
     */
    private String notifysysuuid;

    private String content;
    /**
     * 短信类型 register 注册 ，resetpasswd 重置秘密 ，forgetpasswd 忘记密码
     */
    private String type;
    /**
     * yyfq註冊用戶id，用戶發送必填，子業務系統發送可留空
     */
    private String bussuid;
    /**
     * 調用服務子業務系統
     */
    private String bussdepartment;
    /**
     * 時間
     */
    private Date   sendTime;
    /**
     * 來源 app，html5,
     */
    private String source;

    private String templatePath;

    public Param()
    {

    }

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof Param ) )
            return false;

        Param param = ( Param ) o;

        if ( getNotifysysuuid() != null ? !getNotifysysuuid().equals( param.getNotifysysuuid() )
                                        : param.getNotifysysuuid() != null )
            return false;
        if ( getContent() != null ? !getContent().equals( param.getContent() ) : param.getContent() != null )
            return false;
        if ( getType() != null ? !getType().equals( param.getType() ) : param.getType() != null )
            return false;
        if ( getBussuid() != null ? !getBussuid().equals( param.getBussuid() ) : param.getBussuid() != null )
            return false;
        if ( getBussdepartment() != null ? !getBussdepartment().equals( param.getBussdepartment() )
                                         : param.getBussdepartment() != null )
            return false;
        if ( getSendTime() != null ? !getSendTime().equals( param.getSendTime() ) : param.getSendTime() != null )
            return false;
        if ( getSource() != null ? !getSource().equals( param.getSource() ) : param.getSource() != null )
            return false;
        return getTemplatePath() != null ? getTemplatePath().equals( param.getTemplatePath() )
                                         : param.getTemplatePath() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getNotifysysuuid() != null ? getNotifysysuuid().hashCode() : 0;
        result = 31 * result + ( getContent() != null ? getContent().hashCode() : 0 );
        result = 31 * result + ( getType() != null ? getType().hashCode() : 0 );
        result = 31 * result + ( getBussuid() != null ? getBussuid().hashCode() : 0 );
        result = 31 * result + ( getBussdepartment() != null ? getBussdepartment().hashCode() : 0 );
        result = 31 * result + ( getSendTime() != null ? getSendTime().hashCode() : 0 );
        result = 31 * result + ( getSource() != null ? getSource().hashCode() : 0 );
        result = 31 * result + ( getTemplatePath() != null ? getTemplatePath().hashCode() : 0 );
        return result;
    }

    public String getNotifysysuuid()
    {

        return notifysysuuid;
    }

    public void setNotifysysuuid( String notifysysuuid )
    {
        this.notifysysuuid = notifysysuuid;
    }

    public String getContent()
    {
        return content;
    }

    public void setContent( String content )
    {
        this.content = content;
    }

    public String getType()
    {
        return type;
    }

    public void setType( String type )
    {
        this.type = type;
    }

    public String getBussuid()
    {
        return bussuid;
    }

    public void setBussuid( String bussuid )
    {
        this.bussuid = bussuid;
    }

    public String getBussdepartment()
    {
        return bussdepartment;
    }

    public void setBussdepartment( String bussdepartment )
    {
        this.bussdepartment = bussdepartment;
    }

    public Date getSendTime()
    {
        return sendTime;
    }

    public void setSendTime( Date sendTime )
    {
        this.sendTime = sendTime;
    }

    public String getSource()
    {
        return source;
    }

    public void setSource( String source )
    {
        this.source = source;
    }

    public String getTemplatePath()
    {
        return templatePath;
    }

    public void setTemplatePath( String templatePath )
    {
        this.templatePath = templatePath;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "Param{" );
        sb.append( "bussdepartment='" ).append( bussdepartment ).append( '\'' );
        sb.append( ", bussuid='" ).append( bussuid ).append( '\'' );
        sb.append( ", content='" ).append( content ).append( '\'' );
        sb.append( ", notifysysuuid='" ).append( notifysysuuid ).append( '\'' );
        sb.append( ", sendTime=" ).append( sendTime );
        sb.append( ", source='" ).append( source ).append( '\'' );
        sb.append( ", templatePath='" ).append( templatePath ).append( '\'' );
        sb.append( ", type='" ).append( type ).append( '\'' );
        sb.append( '}' );
        return sb.toString();
    }
}
