/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms;

import java.util.Collections;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.ChannelEntity;
import com.yyfq.base.notify.common.exception.ServiceException;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.SMSChannelSeletor
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-12 16:17
 *   LastChange: 2016-1-12 16:17
 *      History:
 * </pre>
 **************************************************************************/
public enum SMSChannelSeletor
{
    INSTANCE;

    private final Logger logger = LoggerFactory.getLogger( SMSChannelSeletor.class );
    private final Random random = new Random();

    SMSChannelSeletor()
    {
        logger.info( "通知服务平台，短信通道选择器初始化..." );
    }


    /**
   	 * 短信通道选择，通过权重比例选择通道
   	 * @param list
   	 * @return ChannelEntity
   	 */
   	public ChannelEntity selectChannel(CopyOnWriteArrayList<ChannelEntity> list) {

   		int length = list.size();
   		if (length == 0) {//如果通道集合为空，抛异常
   			throw ServiceException.SERVICE_SMS_CHANNEL_EXCEPTION;
   		}
   		
   		//下面对通道的list里通道的权重值进行从大到小的排序，返回权重最大的通道
   		for (int i = 0; i < length; i++) {
   			ChannelEntity channelI = list.get(i);
   			if (!channelI.isStatus()) {//判断通道状态是否打开，1为打开，0为关闭
   				list.remove(channelI);
   				logger.warn("{}通道标记为不可用状态，从选择器中移出...",JSONObject.toJSONString(channelI));
   				continue;
   			}
   			
   			int weight = channelI.getWeight();
   			if (weight < 0 || weight > 200) {//如果权重小于0或者大于200，重设回100
   				setList(list);
   				return list.get(length-1);
   			}
   	    }
   		
   		//返回权重值最大的通道
   		return Collections.max(list);
   	}

   	private void setList(CopyOnWriteArrayList<ChannelEntity> list) {
   		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getChannelCode().equals("YM_CHANNEL_CODE")) {
				list.get(i).setWeight(110);
			} else {
				list.get(i).setWeight(100);
			}
		}
   	}

}
