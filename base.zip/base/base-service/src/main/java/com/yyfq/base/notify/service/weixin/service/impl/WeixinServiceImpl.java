package com.yyfq.base.notify.service.weixin.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.weixin.AccessToken;
import com.yyfq.base.notify.common.dto.weixin.KeyNote;
import com.yyfq.base.notify.common.dto.weixin.WeixinErrCode;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplate;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplateParam;
import com.yyfq.base.notify.common.util.weixin.WeixinUtil;
import com.yyfq.base.notify.dao.weixin.WeixinMapper;
import com.yyfq.base.notify.dao.weixin.WeixinSendMapper;
import com.yyfq.base.notify.dao.weixin.model.TWeixinSend;
import com.yyfq.base.notify.dao.weixin.model.WeixinUser;
import com.yyfq.base.notify.service.weixin.service.WeixinService;

/**
 * @ClassName: WeixinServiceImpl.java
 * @Description: 微信服务实现类
 * @author zhuweicheng
 * @date 2016年2月1日
 */
@Service
public class WeixinServiceImpl implements WeixinService {

	private static final Logger logger = LoggerFactory
			.getLogger(WeixinServiceImpl.class);
	
	@Resource
	private WeixinMapper weixinDao;
	
	@Resource
	private WeixinSendMapper weixinSendDao;
	
	/**
	 * 通过userId获取openId
	 * @param userId
	 * @return String
	 */
	@Override
	public String getOpenIdByUser(long userId) {
		return weixinDao.getOpenIdByUser(userId);
	}

	/**
	 * 微信普通模版发送
	 * @param openId
	 * @return Result<Integer>
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	@Override
	public Result<Integer> normalSend(String openId,long userId,WeixinTemplateParam t) 
						throws ClientProtocolException, IOException{
		Result<Integer> result = new Result<Integer>();
		// 获取票据
		AccessToken token = WeixinUtil.getAccessToken();
		KeyNote first = new KeyNote("有用分期。", "#173177");
		KeyNote kn1 = new KeyNote("啦啦啦，测试成功", "#173177");
		KeyNote kn2 = new KeyNote(
				new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
				"#173177");
		KeyNote remark = new KeyNote("如您有任何问题，欢迎来电询问。 88888888", "#173177");

		Map<String, Object> data = new HashMap<String, Object>();
		data.put("first", first);
		data.put("keynote1", kn1);
		data.put("keynote2", kn2);
		data.put("remark", remark);

		WeixinTemplate mt = new WeixinTemplate();
		mt.setTouser(openId);
		mt.setTemplate_id(WeixinUtil.WEIXIN_TEMPLATE_TEST);
		mt.setUrl("http://m.yyfq.com/");
		mt.setData(data);

		String outStr = JSONObject.toJSONString(mt);
		
		//获取模版列表详细信息，拿到title
		JSONObject json = WeixinUtil.getTemplateList(token.getToken());
		String templateList = json.getString("template_list");
		JSONArray array = JSONObject.parseArray(templateList);
		String title = null;
		for (int i = 0; i < array.size(); i++) {
			JSONObject ob = (JSONObject) array.get(i);
			title = ob.getString("title");
		}
		
		//插入模版消息记录
		String content = first.getValue() + " | " + kn1.getValue() + " | " + kn2.getValue() + " | " +remark.getValue();
		TWeixinSend tws = new TWeixinSend();
		tws.setUserId(userId);
		tws.setTitle(title);
		tws.setContent(content);
		tws.setCreateTime(new Date());
		tws.setStatus(-1);//-1为发送状态
		tws.setSubmitBussName(t.getSubmitBussName());
		tws.setSubmitBussTime(t.getSubmitBussTime());
		weixinSendDao.insertTWeixinSend(tws);
		
		// 发送消息
		JSONObject jsonObject = WeixinUtil.sendTemplateMsg(token.getToken(),outStr);

		String errcode = jsonObject.getString("errcode");
		if (errcode.equals("0")) {
			//更改发送的状态，为成功
			weixinSendDao.updateStatus(0,tws.getId(),new Date());
			
			logger.info("发送微信模版消息成功:" + errcode);
			return result;
		} else {
			//更改发送的状态，为失败
			weixinSendDao.updateStatus(1, tws.getId(), new Date());
			
			result.setErrCode(WeixinErrCode.WX_ERR_EIGHT);
			result.setRet(WeixinErrCode.WX_ERR_EIGHT);
			result.setMsg("发送微信模版消息失败");
			logger.info("微信发送模版消息失败");
			return result;
		}
	}

	@Override
	public WeixinUser findByOpenid(String openId) {
		return weixinDao.findByOpenid(openId);
	}

	@Override
	public Result<Object> insertWeixinUser(String openId) {
		Result<Object> result = new Result<Object>();
		WeixinUser user = weixinDao.findByOpenid(openId);
		if (null != user) {
			result.setRet(WeixinErrCode.WX_ERR_ONE);
			result.setMsg("微信用户已存在");
			result.setErrCode(WeixinErrCode.WX_ERR_ONE);
			return result;
		}
		WeixinUser wxUser = new WeixinUser();
		wxUser.setOpenId(openId);
		wxUser.setIsLogin(0);// 未登录
		wxUser.setUserId(0);
		wxUser.setSubStatus(0);// 未关注
		int addInt = weixinDao.insertWeixinUser(wxUser);
		if (addInt != 1) {
			result.setErrCode(WeixinErrCode.WX_ERR_TWO);
			result.setRet(WeixinErrCode.WX_ERR_TWO);
			result.setMsg("首次添加微信用户失败");
			return result;
		}
		result.setData(wxUser);
		return result;
	}

	/**
	 * 更新微信用户信息
	 * @param openId
	 * @param nickName
	 * @param sex
	 * @param city
	 * @param country
	 * @param province
	 * @param headImgUrl
	 * @param subStatus
	 * @return Result<Integer>
	 */
	@Override
	public Result<Integer> updateWeixinUser(String openId, String nickName,
			int sex, String city, String country, String province,
			String headImgUrl, int subStatus) {
		Result<Integer> result = new Result<Integer>();
		// 查询openId用户是否存在,是否是已关注的状态
		WeixinUser user = weixinDao.findByOpenid(openId);
		if (null != user && user.getSubStatus() == 1) {
			result.setRet(WeixinErrCode.WX_ERR_THREE);
			result.setErrCode(WeixinErrCode.WX_ERR_THREE);
			result.setMsg("微信用户已关注，更新数据失败");
			return result;
		}
		int resultInt = weixinDao.updateWeixinUser(openId, nickName, sex, city,
				country, province, headImgUrl, subStatus);
		if (resultInt != 1) {
			result.setMsg("更新详细数据失败");
			result.setErrCode(WeixinErrCode.WX_ERR_FOUR);
			result.setRet(WeixinErrCode.WX_ERR_FOUR);
			return result;
		}
		result.setData(resultInt);
		return result;
	}

	/**
	 * 修改改关注状态
	 * @param openId
	 * @param subStatus
	 * @return
	 */
	@Override
	public int updateSubStatus(String openId, int subStatus) {
		return weixinDao.updateSubStatus(openId, subStatus);
	}

	/**
	 * 修改场景值
	 * @param scene
	 * @param openId
	 * @return
	 */
	@Override
	public int updateWeixinScene(Integer scene, String openId) {
		return weixinDao.updateWeixinScene(scene, openId);
	}

}
