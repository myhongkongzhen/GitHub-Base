package com.yyfq.base.notify.service.facade.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.yyfq.base.notify.common.dto.CateInfoDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.facade.BaseInfoFacade;
import com.yyfq.base.notify.service.cateinfo.BaseInfoService;

@Service(value="baseInfoFacade")
public class BaseInfoFacadeImpl implements BaseInfoFacade {

	private static final Logger logger = LoggerFactory.getLogger(BaseInfoFacadeImpl.class);

	@Resource
	private BaseInfoService baseInfoService;
	
	/**
	 * 通过条件查询属性明细列表
	 * @param cateInfoDto
	 * @return 
	 */
	/** 异常提示 */
    private static final String ERROR_MSG = "查询属性编码明细表发生异常";
	
	@Override
	public Result<List<CateInfoDTO>> queryCateInfoList(CateInfoDTO cateInfoDto) {
		Result<List<CateInfoDTO>> result=new Result<List<CateInfoDTO>>();
		List<CateInfoDTO> list = null;
		try {
			if(null == cateInfoDto) {
				result.setRet("-1");
				result.setMsg("查询请求参数为空");
				return result;
			}
			logger.info("【银行信息查询开始】");
			list = baseInfoService.queryCateInfoList(cateInfoDto);
			logger.info("【银行信息查询结束，数据条数】"+list.size());
			result.setData(list);
			result.setRet("0");
			result.setMsg("操作成功");
		} catch (Exception e) {
			logger.error(ERROR_MSG, e);
			result.setRet("-1");
			result.setMsg(ERROR_MSG);
		}
		return result;
	}

}
