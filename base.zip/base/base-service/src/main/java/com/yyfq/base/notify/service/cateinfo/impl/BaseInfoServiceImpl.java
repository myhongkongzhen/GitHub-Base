package com.yyfq.base.notify.service.cateinfo.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.yyfq.base.notify.common.dto.CateInfoDTO;
import com.yyfq.base.notify.dao.cateinfo.CateInfoMapper;
import com.yyfq.base.notify.dao.entity.cateinfo.CateInfo;
import com.yyfq.base.notify.service.cateinfo.BaseInfoService;

/**
 * @ClassName: CateInfoServiceImpl.java
 * @Description:属性明细服务实现层 
 * @author zhuweicheng
 * @date 2016年3月17日
 */
public class BaseInfoServiceImpl implements BaseInfoService {

	private static final Logger logger = LoggerFactory.getLogger(BaseInfoServiceImpl.class);
	
	@Resource
	private CateInfoMapper cateInfoMapper;
	
	/**
	 * 通过条件查询属性明细列表
	 */
	@Override
	public List<CateInfoDTO> queryCateInfoList(CateInfoDTO cateInfoDto) {
		
		List<CateInfoDTO> result = null;
		try {
			CateInfo cateInfo = construct(cateInfoDto);
			logger.info("【数据库查询开始】");
			result = convert(cateInfoMapper.queryCateInfoList(cateInfo));
			logger.info("【数据库查询结束，数据条数为】"+result.size());
		} catch (Exception e) {
			logger.info("【查询属性明细列表发生异常】",e);
		}
		return result;
	}

	//转换
	private List<CateInfoDTO> convert(List<CateInfo> queryCateInfoList) {
		List<CateInfoDTO> list = new ArrayList<CateInfoDTO>();
		CateInfoDTO cateInfoDto = null;
		for (CateInfo cateInfo : queryCateInfoList) {
			cateInfoDto = new CateInfoDTO();
			cateInfoDto.setCateCode(cateInfo.getCateCode());
			cateInfoDto.setCode(cateInfo.getCode());
			cateInfoDto.setName(cateInfo.getName());
			cateInfoDto.setId(cateInfo.getId());
			list.add(cateInfoDto);
		}
		return list;
	}

	//构造实体
	private CateInfo construct(CateInfoDTO cateInfoDto) {
		CateInfo cateInfo = new CateInfo();
		cateInfo.setCateCode(cateInfoDto.getCateCode());
		cateInfo.setCode(cateInfoDto.getCode());
		cateInfo.setName(cateInfoDto.getName());
		return cateInfo;
	}

}
