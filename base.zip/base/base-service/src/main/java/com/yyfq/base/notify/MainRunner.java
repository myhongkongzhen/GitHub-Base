/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.MainRunner
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 13:36
 *   LastChange: 2016-1-18 13:36
 *      History:
 * </pre>
 **************************************************************************/
public class MainRunner
{
    private static final Logger logger = LoggerFactory.getLogger( MainRunner.class );

    public static void main( String[] args )
    {
//        com.alibaba.dubbo.container.Main.main( args );
        try
        {
            ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                    "classpath:spring/spring.xml" );
            context.start();
        }
        catch ( Exception e )
        {
            logger.error( "DubboProvider MainRunner context start error:{}", e.getMessage(), e );
            System.exit( 1 );
        }
        synchronized ( MainRunner.class )
        {
            while ( true )
            {
                try
                {
                    MainRunner.class.wait();
                }
                catch ( InterruptedException e )
                {
                    logger.error( "== synchronized error:{}", e.getMessage(), e );
                    System.exit( 1 );
                }
            }
        }
    }
}
