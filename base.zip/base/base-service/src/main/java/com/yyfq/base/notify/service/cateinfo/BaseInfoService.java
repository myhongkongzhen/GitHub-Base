package com.yyfq.base.notify.service.cateinfo;

import java.util.List;

import com.yyfq.base.notify.common.dto.CateInfoDTO;

/**
 * @ClassName: CateInfoService.java
 * @Description: 属性明细服务接口
 * @author zhuweicheng
 * @date 2016年3月17日
 */
public interface BaseInfoService {

	/**
	 * 通过条件查询属性明细列表
	 * @param cateInfoDto
	 * @return List<CateInfoDTO>
	 */
	List<CateInfoDTO> queryCateInfoList(CateInfoDTO cateInfoDto);

}
