package com.yyfq.base.notify.service.weixin.facade;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.weixin.WeixinErrCode;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplateParam;
import com.yyfq.base.notify.common.util.weixin.WeixinCheckUtil;
import com.yyfq.base.notify.facade.weixin.WeixinNotifyFacade;
import com.yyfq.base.notify.service.weixin.service.WeixinService;

/**
 * @ClassName: WeixinNotifyFacadeImpl.java
 * @Description: 微信接口实现类，业务处理
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@Component("weixinNotifyFacade")
public class WeixinNotifyFacadeImpl implements
		WeixinNotifyFacade<WeixinTemplateParam> {

	private static final Logger logger = LoggerFactory
			.getLogger(WeixinNotifyFacadeImpl.class);

	@Resource
	private WeixinService weixinService;

	/**
	 * 微信发送模版实现类
	 * 
	 * @param WeixinTemplateParam
	 * @return int
	 */
	@Override
	public Result<Integer> sendWeixinTemplate(WeixinTemplateParam t) {
		Result<Integer> result = new Result<Integer>();
		String openId = weixinService.getOpenIdByUser(t.getUserId());
		// 判断用户是否绑定了微信
		if (StringUtils.isBlank(openId)) {
			logger.info("send fail,no fond openid");
			result.setErrCode(WeixinErrCode.WX_ERR_SEVEN);
			result.setRet(WeixinErrCode.WX_ERR_SEVEN);
			result.setMsg("微信用户openId不存在");
			return result;
		}
		try {
			if (t.getType() == 0) {// 普通模版
				return weixinService.normalSend(openId,t.getUserId(),t);
			}
		} catch (Exception e) {
			System.out.println("send fail,system error");
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 微信签名验证
	 * 
	 * @param signature
	 *            ,timestamp,nonce return boolean
	 */
	@Override
	public boolean checkSignature(String signature, String timestamp,
			String nonce) {
		return WeixinCheckUtil.checkSignature(signature, timestamp, nonce);
	}

	/**
	 * 首次添加微信用户表
	 * 
	 * @param openId
	 * @return Result<Object>
	 */
	@Override
	public Result<Object> insertWeixinUser(String openId) {
		// 查询openId用户是否存在
		Result<Object> result = weixinService.insertWeixinUser(openId);
		return result;
	}


	/**
	 * 更新微信用户信息
	 * 
	 * @param openId
	 * @param nickName
	 * @param sex
	 * @param city
	 * @param country
	 * @param province
	 * @param headImgUrl
	 * @param subStatus
	 * @return int
	 */
	@Override
	public Result<Integer> updateWeixinUser(String openId, String nickName,
			int sex, String city, String country, String province,
			String headImgUrl, int subStatus) {
		Result<Integer> result = weixinService.updateWeixinUser(openId, nickName, sex, city, country,
				province, headImgUrl, subStatus);
		return result;
	}


	/**
	 * 更新微信用户场景值
	 * 
	 * @param scene
	 * @param openId
	 * @return int
	 */
	@Override
	public Result<Integer> updateWeixinScene(Integer scene, String openId) {
		Result<Integer> result = new Result<Integer>();
		int variable = weixinService.updateWeixinScene(scene, openId);
		if (variable != 1) {
			result.setErrCode(WeixinErrCode.WX_ERR_FIVE);
			result.setRet(WeixinErrCode.WX_ERR_FIVE);
			result.setMsg("更新微信用户场景值失败");
			return result;
		}
		result.setData(variable);
		return result;
	}

	/**
	 * 更新微信用户关注状态
	 * 
	 * @param openId
	 * @param subStatus
	 * @return int
	 */
	@Override
	public Result<Integer> updateSubStatus(String openId, int subStatus) {
		Result<Integer> result = new Result<Integer>();
		int variable = weixinService.updateSubStatus(openId, subStatus);
		if (variable != 1) {
			result.setErrCode(WeixinErrCode.WX_ERR_FIVE);
			result.setRet(WeixinErrCode.WX_ERR_FIVE);
			result.setMsg("更新微信用户关注状态失败");
			return result;
		}
		result.setData(variable);
		return result;
	}

}
