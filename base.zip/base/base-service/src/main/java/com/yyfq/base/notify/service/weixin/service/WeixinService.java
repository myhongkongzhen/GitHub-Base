package com.yyfq.base.notify.service.weixin.service;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplateParam;
import com.yyfq.base.notify.dao.weixin.model.WeixinUser;

/**
 * @ClassName: WeixinService.java
 * @Description: 微信服务接口
 * @author zhuweicheng
 * @date 2016年2月1日
 */
public interface WeixinService {

	/**
	 * 通过userId获取openId
	 * @param userId
	 * @return String
	 */
	String getOpenIdByUser(long userId);

	/**
	 * 微信普通模版发送
	 * @param openId
	 * @return Result<Integer>
	 * @throws IOException 
	 * @throws ClientProtocolException
	 */
	Result<Integer> normalSend(String openId,long userId,WeixinTemplateParam t) throws ClientProtocolException, IOException;

	/**
	 * 根据OpenId查找weixinUser
	 * @param openId
	 * @return WeixinUser
	 */
	WeixinUser findByOpenid(String openId);


	/**
	 * 首次添加微信用户
	 * @param openId
	 * @return Result<Object>
	 */
	Result<Object> insertWeixinUser(String openId);

	/**
	 * 更新微信用户信息
	 * @param openId
	 * @param nickName
	 * @param sex
	 * @param city
	 * @param country
	 * @param province
	 * @param headImgUrl
	 * @param subStatus
	 * @return Result<Integer>
	 */
	Result<Integer> updateWeixinUser(String openId, String nickName, int sex,
			String city, String country, String province, String headImgUrl,
			int subStatus);

	/**
	 * 修改用户关注状态，已关注或者取消关注
	 * @param openId
	 * @param subStatus
	 * @return
	 * @return int
	 */
	int updateSubStatus(String openId, int subStatus);

	/**
	 * 修改微信场景值
	 * @param scene
	 * @param openId
	 * @return
	 * @return int
	 */
	int updateWeixinScene(Integer scene, String openId);

}
