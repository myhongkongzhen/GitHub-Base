/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.impl;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.MailParam;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.facade.NotifyFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.impl.MailNotifyFacadeImplTest
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 01:05
 *   LastChange: 2016-1-26 01:05
 *      History:
 * </pre>
 **************************************************************************/
@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( locations = { "classpath:spring/spring.xml" } )
public class MailNotifyFacadeImplTest
{
    
    private static final Logger logger = LoggerFactory.getLogger( MailNotifyFacadeImplTest.class );
   private NotifyFacade mailNotifyFacade;
    
    @Test
    public void testSendSingleMsg() throws Exception
    {
        try
        {
            MailParam mailParam = new MailParam();
//            mailParam.setContent( "this is test" );
//            mailParam.setTo( "zhenzhen.wu@mljr.com" );
//            mailParam.setSubject( "test" );
            Result< MailParam >
                    result
                    = mailNotifyFacade.sendSingleMsg( mailParam );
            logger.info( "==={}===", JSONObject.toJSONString( result ) );
        }
        catch ( BizException e )
        {
            e.printStackTrace();
        }
        System.in.read();
    }

    @Test
    public void testSendMultMsg() throws Exception
    {

    }

    public NotifyFacade getMailNotifyFacade()
    {
        return mailNotifyFacade;
    }

    @Resource(name = "mailNotifyFacade")
    public void setMailNotifyFacade( NotifyFacade mailNotifyFacade )
    {
        this.mailNotifyFacade = mailNotifyFacade;
    }
}