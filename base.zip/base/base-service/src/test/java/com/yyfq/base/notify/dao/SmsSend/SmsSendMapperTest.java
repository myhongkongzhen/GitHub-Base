/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.dao.SmsSend;

import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.dao.SmsSend.SmsSendMapperTest
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:39
 *   LastChange: 2016-1-18 11:39
 *      History:
 * </pre>
 **************************************************************************/
@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( locations = { "classpath:spring/spring.xml" } )
public class SmsSendMapperTest
{
    private SmsSendMapper smsSendMapper;
    private static final Logger logger = LoggerFactory.getLogger( SmsSendMapperTest.class );
    
    
    @Test
    public void testInsertSelective() throws Exception
    {
        try
        {
            TSmsSend tSmsSend = new TSmsSend();
            tSmsSend.setSmsSource( "htm5" );
            tSmsSend.setSubmitBussUid( "zhandgsan" );
            tSmsSend.setSubmitBussDepartment( "fengdkong" );
            tSmsSend.setSmsChannelCode( "test_dcode" );
            tSmsSend.setSmsContent( "jljlkjluoiuoi" );
            tSmsSend.setReceiveMobile( "jflsdd3242" );
            tSmsSend.setSmsType( 1 );
            tSmsSend.setNotifySysUuid( "823fjsdljfldsj" );
            int rs = smsSendMapper.insertSelective( tSmsSend );
            logger.info( "insert : {}", rs );
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    @Test
    public void testUpdateByUUIDSelective() throws Exception
    {
        try
        {
            TSmsSend tSmsSend = new TSmsSend();
            tSmsSend.setSmsSource( "htm5" );
            tSmsSend.setSubmitBussUid( "zhdangsan" );
            tSmsSend.setSubmitBussDepartment( "fengkong" );
            tSmsSend.setSmsChannelCode( "tedst_code" );
            tSmsSend.setSmsContent( "jljlkjlduoiuoi" );
            tSmsSend.setReceiveMobile( "jfldsd3242" );
            tSmsSend.setSmsType( 1 );
            tSmsSend.setNotifySysUuid( "823fjdsdljfldsj" );
            int rs = smsSendMapper.updateByUUIDSelective( tSmsSend );
            logger.info( "update : {}", rs );

            if ( rs == 0 )
            {
                rs = smsSendMapper.insertSelective( tSmsSend );
                logger.info( "update : {}", rs );
            }
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    public SmsSendMapper getSmsSendMapper()
    {
        return smsSendMapper;
    }

    @Resource
    public void setSmsSendMapper( SmsSendMapper smsSendMapper )
    {
        this.smsSendMapper = smsSendMapper;
    }
}