/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.service.sms.SMSNotifyService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.SMSNotifyServiceTest
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:17
 *   LastChange: 2016-1-18 11:17
 *      History:
 * </pre>
 **************************************************************************/
@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( locations = { "classpath:spring/spring.xml" } )
public class SMSNotifyServiceTest
{
    private static final Logger logger = LoggerFactory.getLogger( SMSNotifyServiceTest.class );

    private SMSNotifyService smsNotifyService;
    
    
    @Test
    public void testInsert() throws Exception
    {
        try
        {
            TSmsSend tSmsSend = new TSmsSend();
            tSmsSend.setSmsSource( "htm5" );
            tSmsSend.setSubmitBussUid( "zhangsan" );
            tSmsSend.setSubmitBussDepartment( "fengkong" );
            tSmsSend.setSmsChannelCode( "test_code" );
            tSmsSend.setSmsContent( "jljlkjluoiuoi" );
            tSmsSend.setReceiveMobile( "jflsd3242" );
            tSmsSend.setSmsType( 1 );
            tSmsSend.setNotifySysUuid( "823fjsdljfldsj" );
            logger.info( "insert : {}==.",  JSONObject.toJSONString( tSmsSend ));
            int rs = smsNotifyService.insert( tSmsSend );
            logger.info( "insert : {}=={}.", rs , JSONObject.toJSONString( tSmsSend ));
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    @Test
    public void testUpdateByUUID() throws Exception
    {
        try
        {
            TSmsSend tSmsSend = new TSmsSend();
            tSmsSend.setSmsSource( "htm5" );
            tSmsSend.setSubmitBussUid( "zhangsan" );
            tSmsSend.setSubmitBussDepartment( "fengkong" );
            int rs = smsNotifyService.updateByUUID( tSmsSend );
            logger.info( "update : {}", rs );

            if ( rs == 0 )
            {
                rs = smsNotifyService.insert( tSmsSend );
                logger.info( "update : {}", rs );
            }
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    public SMSNotifyService getSmsNotifyService()
    {
        return smsNotifyService;
    }

    @Resource( name = "smsNotifyService" )
    public void setSmsNotifyService( SMSNotifyService smsNotifyService )
    {
        this.smsNotifyService = smsNotifyService;
    }
}