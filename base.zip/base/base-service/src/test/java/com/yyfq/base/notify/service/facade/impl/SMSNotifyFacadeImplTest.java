/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.impl;

import com.yyfq.base.notify.common.dto.SMSParam;
import com.yyfq.base.notify.facade.NotifyFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collection;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.impl.SMSNotifyFacadeImplTest
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 12:02
 *   LastChange: 2016-1-18 12:02
 *      History:
 * </pre>
 **************************************************************************/
@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( locations = { "classpath:spring/spring-base.xml", "classpath:spring-dubbo-consumer.xml" } )
public class SMSNotifyFacadeImplTest
{
    private static final Logger logger = LoggerFactory.getLogger( SMSNotifyFacadeImplTest.class );
    private NotifyFacade notifyFacade;
    
    @Test
    public void testSendSingleSMS() throws Exception
    {
        try
        {
            SMSParam param = new SMSParam();
            notifyFacade.sendSingleMsg( param );
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    @Test
    public void testSendMultSMS() throws Exception
    {
        try
        {
            Collection< SMSParam > list  = new ArrayList<>();
            SMSParam               param = new SMSParam();
            list.add( param );
            notifyFacade.sendMultMsg( list );
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    public NotifyFacade getNotifyFacade()
    {
        return notifyFacade;
    }

    @Resource( name = "smsNotifyFacade" )
    public void setNotifyFacade( NotifyFacade notifyFacade )
    {
        this.notifyFacade = notifyFacade;
    }
}