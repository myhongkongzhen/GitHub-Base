/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms;

import com.yyfq.base.notify.common.dto.ChannelEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.SMSChannelCache
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 09:33
 *   LastChange: 2016-1-13 09:33
 *      History:
 * </pre>
 **************************************************************************/
public class SMSChannelCache
{
    private static final Logger                                logger = LoggerFactory.getLogger(
            SMSChannelCache.class );
    private static       CopyOnWriteArrayList< ChannelEntity > cache  = new CopyOnWriteArrayList<>();
    private static       ReadWriteLock                         lock   = new ReentrantReadWriteLock();

    public static void updateCache( Collection< ChannelEntity > cacheTmp )
    {
        try
        {
            lock.writeLock().lock();
            cache.clear();
            cache.addAll( cacheTmp );
//            logger.info( " == > {}", JSONObject.toJSONString( cache ) );
        }
        finally
        {
            lock.writeLock().unlock();
        }
    }

    public static CopyOnWriteArrayList< ChannelEntity > getCache()
    {
        try
        {
            lock.readLock().lock();
            return cache;
        }
        finally
        {
            lock.readLock().unlock();
        }
    }

    public static int size()
    {
        try
        {
            lock.readLock().lock();
            return cache.size();
        }
        finally
        {
            lock.readLock().unlock();
        }
    }

    public static ChannelEntity getChannelEntity( String channelCode )
    {
        try
        {
            lock.readLock().lock();

            for ( ChannelEntity channelEntity : cache )
            {
                if ( StringUtils.equalsIgnoreCase( channelCode, channelEntity.getChannelCode() ) )
                {
                    return channelEntity;
                }
            }
        }
        finally
        {
            lock.readLock().unlock();
        }
        return null;
    }
}
