/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.vo;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.sender.vo.YMResponse
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 17:22
 *   LastChange: 2016-1-18 17:22
 *      History:
 * </pre>
 **************************************************************************/
@XStreamAlias( "response" )
public class YMResponse implements Serializable
{
    //<?xml version="1.0" encoding="UTF-8"?><response><error>0</error><message></message></response>
    private String            error;
    @XStreamImplicit( itemFieldName = "message" )
    private List< YMMessage > message;


    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof YMResponse ) )
            return false;

        YMResponse that = ( YMResponse ) o;

        if ( getError() != null ? !getError().equals( that.getError() ) : that.getError() != null )
            return false;
        return getMessage() != null ? getMessage().equals( that.getMessage() ) : that.getMessage() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getError() != null ? getError().hashCode() : 0;
        result = 31 * result + ( getMessage() != null ? getMessage().hashCode() : 0 );
        return result;
    }

    public String getError()
    {

        return error;
    }

    public void setError( String error )
    {
        this.error = error;
    }

    public List< YMMessage > getMessage()
    {
        return message;
    }

    public void setMessage( List< YMMessage > message )
    {
        this.message = message;
    }

    public YMResponse()
    {

    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "YMResponse{" );
        sb.append( "error='" ).append( error ).append( '\'' );
        sb.append( ", message=" ).append( message );
        sb.append( '}' );
        return sb.toString();
    }
}
