/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.common.RedisKeyConstant
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-12 22:17
 *   LastChange: 2016-1-12 22:17
 *      History:
 * </pre>
 **************************************************************************/
public abstract class RedisKeyConstant
{
    private static final String KEY_DELIMITER                             = "::";
    private static final String KEY_BASE                                  = "YYFQ";
    private static final String KEY_PLANTFORM
                                                                          = KEY_BASE + KEY_DELIMITER + "BASE" + KEY_DELIMITER + "NOTIFY";
    private static final String KEY_SMS                                   = KEY_PLANTFORM + KEY_DELIMITER + "SMS";
    public static final  String KEY_SMS_SECURITYCODE_TYPE_MOBILE_CONTENT
                                                                          = KEY_SMS + KEY_DELIMITER + "TYPE" + KEY_DELIMITER + "%s" + KEY_DELIMITER + "MOBILE" + KEY_DELIMITER + "%s";
    private static final String KEY_MAIL                                  = KEY_PLANTFORM + KEY_DELIMITER + "MAIL";
    public static final  String KEY_MAIL_SECURITYCODE_TYPE_MAILTO_CONTENT
                                                                          = KEY_MAIL + KEY_DELIMITER + "TYPE" + KEY_DELIMITER + "%s" + KEY_DELIMITER + "MAILTO" + KEY_DELIMITER + "%s";
}
