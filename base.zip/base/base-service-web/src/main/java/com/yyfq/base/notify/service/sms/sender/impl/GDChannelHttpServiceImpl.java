/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.impl;

import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.common.exception.ServiceException;
import com.yyfq.base.notify.service.sms.sender.SMSNotifyServerHttp;
import com.yyfq.base.notify.service.sms.sender.vo.GDSenderStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.sender.GDChannelHttpServiceImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 14:19
 *   LastChange: 2016-1-13 14:19
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "GD_CHANNEL_CODE" )
public class GDChannelHttpServiceImpl extends SMSNotifyServerHttp
{
    private final static Logger logger       = LoggerFactory.getLogger( GDChannelHttpServiceImpl.class );
    private static final String CHANNEL_NAME = "【国都】通道";

    @Value( "${channel.gd.operid}" )
    private String operid;
    @Value( "${channel.gd.operpass}" )
    private String operpass;
    @Value( "${channel.gd.url}" )
    private String httpUrl;

    public GDChannelHttpServiceImpl()
    {
        super();
        super.channelName = CHANNEL_NAME;
    }

    @Async( value = "GD_CHANNEL_Executor" )
    @Override
    public synchronized void sendData( final SMSEntity smsEntity )
    {
        super.sendData( smsEntity );
    }

    @Override
    public String httpUrl()
    {
        return httpUrl;
    }

    /**
     * url += "?OperID=tdjr01&OperPass=tdjr01";
     * url = url + "&AppendID=1234&DesMobile=" + mobile + "&Content="
     * + URLEncoder.encode(content,  encode) + "&ContentType=" + ( content.length() >= 70 ? 8 : 15);
     *
     * @param smsEntity
     */
    @Override
    public void httpParam( final SMSEntity smsEntity )
    {

        try
        {
            param = new ConcurrentHashMap< String, String >();
            param.put( "OperID", operid );
            param.put( "OperPass", operpass );
            param.put( "AppendID", "1234" );
            param.put( "DesMobile", smsEntity.getMobile() );
            param.put( "Content", smsEntity.getContent() );
            param.put( "ContentType", ( smsEntity.getContent().length() >= 70 ? "8" : "15" ) );
            param.put( "encode", "utf-8" );

        }
        catch ( Exception e )
        {
            logger.error( "{}組裝http請求參數時出現異常：{}", channelName, e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_SEND_EXCEPTION;
        }
    }

    @Override
    protected void parseResult( final SMSEntity smsEntity )
    {

        try
        {
            super.parseResult( smsEntity );

            //03,ofds99fsdf9ds089wr324
            String[] strings = StringUtils.splitByWholeSeparatorPreserveAllTokens( result, "," );
            if ( null == strings || strings.length != 2 )
            {
                logger.warn( "{}短信发送结果异常！", channelName );
                throw ServiceException.SERVICE_NOTIFY_SMS_PARSE_RESULT_EXCEPTION;
            }

            smsEntity.setChannelStatus( strings[ 0 ] );
            smsEntity.setSmsid( strings[ 1 ] );
            smsEntity.setChannelDesc( GDSenderStatus.getDesc( strings[ 0 ] ) );
        }
        catch ( Exception e )
        {
            logger.error( "短信發送完畢，組裝發送結果出現異常：{}", e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_SMS_PARSE_RESULT_EXCEPTION;
        }
    }
}
