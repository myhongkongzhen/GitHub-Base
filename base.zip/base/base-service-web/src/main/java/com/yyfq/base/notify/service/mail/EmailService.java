package com.yyfq.base.notify.service.mail;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailDTO;

/**
 * @ClassName: MailService.java
 * @Description: 邮件服务接口
 * @author zhuweicheng
 * @date 2016年1月30日
 */
public interface EmailService {

	/**
	 * 发送邮件
	 * @param emailDto
	 * @return void
	 */
	Result sendNewEmail(EmailDTO emailDto, Result result) throws Exception;

}
