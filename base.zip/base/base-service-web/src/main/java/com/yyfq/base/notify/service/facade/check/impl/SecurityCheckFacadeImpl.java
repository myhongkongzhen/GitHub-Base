/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.check.impl;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.SMSParam;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.common.util.NotifyConstant;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.facade.check.SecurityCheckFacade;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.check.impl.SecurityCheckFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-19 15:35
 *   LastChange: 2016-1-19 15:35
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "securityCheckFacade" )
public class SecurityCheckFacadeImpl implements SecurityCheckFacade< SMSParam >
{
    private static final Logger logger = LoggerFactory.getLogger( SecurityCheckFacadeImpl.class );
    private VelocityEngine velocityEngine;

    //    @Async
    @Override
    public Result< SMSParam > checkParam( final SMSParam param ) throws BizException
    {
        try
        {
            logger.info( "开始校验的参数：{}.", JSONObject.toJSONString( param ) );
            checkMoble( param );
            checkType( param );
            checkDepartmentNull( param.getBussdepartment() );
            checkSourceNull( param.getSource() );
            return new Result< SMSParam >( param );
        }
        catch ( BizException e )
        {
            logger.error( "发短信請求出现业务异常：{}.", e.getMessage() );
            return new Result< SMSParam >( "1", String.valueOf( e.getCode() ), e.getMsg(), param );
        }
        catch ( Exception e )
        {
            return new Result< SMSParam >( "1", String.valueOf( BizException.SYSTEM_EXCEPTION.getCode() ), StringUtils
                    .join( BizException.SYSTEM_EXCEPTION.getMessage(), "==", e.getMessage() ), param );
        }
        finally
        {
            logger.info( "完成参数校验..{}...", JSONObject.toJSONString( param ) );
        }
    }


    private void checkSourceNull( String source )
    {
        checkNull( source, WebException.WEB_REQ_ARGS_SOURCE_NULL );
    }

    private void checkDepartmentNull( String bussdepartment )
    {
        checkNull( bussdepartment, WebException.WEB_REQ_ARGS_DEPART_NULL );
    }

    private void checkType( SMSParam param )
    {
        checkNull( param.getType(), WebException.WEB_REQ_ARGS_NOTIFY_TYPE_NULL );
        if ( !StringUtils.isBlank( param.getContent() ) )
            return;

        try
        {
            getTemplatePath( param );
            String path    = param.getTemplatePath();
           /* String content =*/
            VelocityEngineUtils.mergeTemplateIntoString( velocityEngine, path, "UTF-8", null );
//            param.setContent( content );
        }
        catch ( VelocityException e )
        {
            throw WebException.WEB_REQ_ARGS_NOTIFY_TYPE_ERROR;
        }
    }

    private void getTemplatePath( SMSParam param )
    {
        StringBuilder smsTemplatePath = new StringBuilder( NotifyConstant.SMS_CONTENT_TEMPLATE );
        smsTemplatePath.append( "/" );
        smsTemplatePath.append( param.getType() );
        smsTemplatePath.append( ".template.vm" );
        logger.info( "请求短信模板路径：{}", smsTemplatePath.toString() );
        param.setTemplatePath( smsTemplatePath.toString() );
    }

    private void checkNull( String string, WebException e )
    {
        if ( StringUtils.isBlank( StringUtils.trimToEmpty( string ) ) )
        {
            throw e;
        }

    }

    private void checkMoble( SMSParam param )
    {
        if ( !NotifyUtil.INSTANCE.checkPhone( param.getMobile() ) )
        {
            throw WebException.WEB_REQ_ARGS_MOBILE_ERROR;
        }
    }

    public VelocityEngine getVelocityEngine()
    {
        return velocityEngine;
    }

    @Resource
    public void setVelocityEngine( VelocityEngine velocityEngine )
    {
        this.velocityEngine = velocityEngine;
    }

}
