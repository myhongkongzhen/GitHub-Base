/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.impl;

import com.thoughtworks.xstream.XStream;
import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.service.sms.sender.SMSNotifyServerHttp;
import com.yyfq.base.notify.service.sms.sender.vo.YMResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.sender.YMChannelHttpServiceImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 14:42
 *   LastChange: 2016-1-13 14:42
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "YM_CHANNEL_CODE_REGISTER" )
public class YMChannelRegisterServiceImpl extends SMSNotifyServerHttp
{
    private final static Logger logger       = LoggerFactory.getLogger( YMChannelRegisterServiceImpl.class );
    private static final String CHANNEL_NAME = "【亿美】通道";

    @Value( "${channel.ym.cdkey}" )
    private String cdkey;
    @Value( "${channel.ym.password}" )
    private String password;
    @Value( "${channel.ym.url.register}" )
    private String httpUrl;

    public YMChannelRegisterServiceImpl()
    {
        super();
        super.channelName = CHANNEL_NAME;
    }

    @Override
    protected void parseResult( final SMSEntity smsEntity )
    {
        try
        {
            result = StringUtils.trimToEmpty( result );
            //<?xml version="1.0" encoding="UTF-8"?><response><error>0</error><message></message></response>

            XStream xStream = new XStream();
            xStream.processAnnotations( YMResponse.class );
            YMResponse xml = ( YMResponse ) xStream.fromXML( result );
            if ( null == xml || StringUtils.isBlank( StringUtils.trimToEmpty( xml.getError() ) ) || !StringUtils
                    .equalsIgnoreCase( "0", StringUtils.trimToEmpty( xml.getError() ) ) )
            {
                logger.error( "亿美短信通道注册出现异常：{}.", result );
                throw BizException.SYSTEM_EXCEPTION;
            }
        }
        catch ( Exception e )
        {
            logger.error( "短信發送完畢，組裝發送結果出現異常：{}", e.getMessage(), e );
            System.exit( 1 );
        }
    }

    @Override
    public String httpUrl()
    {
        return httpUrl;
    }

    @Override
    public void httpParam( final SMSEntity smsEntity )
    {
        param = new ConcurrentHashMap< String, String >();
        param.put( "cdkey", cdkey );
        param.put( "password", password );
        param.put( "encode", "utf-8" );
    }

    @Override
    protected void updateDatabase( final SMSEntity smsEntity )
    {
    }
}
