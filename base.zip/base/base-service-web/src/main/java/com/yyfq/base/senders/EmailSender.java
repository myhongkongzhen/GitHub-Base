package com.yyfq.base.senders;

import com.yyfq.base.notify.common.dto.email.EmailDTO;

/**
 * 邮件发送器
 * @author 文龙 2014-04-09
 *
 */
public interface EmailSender {
	
	/**
	 * 原始的邮箱发送
	 */
	public void sendHtmlStringEmail(EmailDTO eMailDTO);
	
}
