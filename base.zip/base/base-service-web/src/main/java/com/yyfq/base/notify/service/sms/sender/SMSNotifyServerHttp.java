/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.service.NotifyService;
import com.yyfq.base.notify.service.sms.sender.http.HttpServerFactory;
import com.yyfq.base.notify.service.sms.SMSNotifyService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.Date;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.sender.SMSNotifyServerHttp
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 14:11
 *   LastChange: 2016-1-13 14:11
 *      History:
 * </pre>
 **************************************************************************/
public abstract class SMSNotifyServerHttp extends HttpServerFactory implements NotifyService< SMSEntity >
{
    private static final Logger logger = LoggerFactory.getLogger( SMSNotifyServerHttp.class );

    protected SMSNotifyService smsNotifyService;

    @Override
    public void sendData( final SMSEntity smsEntity )
    {
        try
        {
            httpParam( smsEntity );
            httpHeader( smsEntity );

            send();

            // -- 2016-1-13 14:37:11 發送成功處理發送結果
            parseResult( smsEntity );

            // 更新數據庫
            updateDatabase( smsEntity );

        }
        catch ( Exception e )
        {
            smsEntity.getChannelEntity().setWeight( smsEntity.getChannelEntity().getWeight() - 30 );
            logger.error( "{}发送短信出现异常:{}.", channelName, e.getMessage(), e );
            // -- 2016-1-13 14:17:13 細節優化，處理異常發送短信后的通道權重問題等
//            throw ServiceException.SERVICE_NOTIFY_SEND_EXCEPTION;
        }
    }

    protected void updateDatabase( final SMSEntity smsEntity )
    {
        try
        {
            TSmsSend ss = new TSmsSend();
            ss.setChannelSubmitStatus( smsEntity.getChannelStatus() );
            ss.setChannelSubmitDesc( smsEntity.getChannelDesc() );
            ss.setSmsId( smsEntity.getSmsid() );
            ss.setChannelReceiveTime( new Date() );
            ss.setNotifySysUuid( smsEntity.getNotifysysuuid() );

            smsNotifyService.updateByUUID( ss );
            logger.info( "通知服务短信发送完成，构造短信实体完成：{},存入短信发送基础表及发送短信.", JSONObject.toJSONString( ss ) );
        }
        catch ( Exception e )
        {
            logger.error( "短信发送记录{},更新数据库出现异常,{}", JSONObject.toJSONString( smsEntity ), e.getMessage(), e );
//            throw new DatabaseOperateException( "发送短信记录存入数据库时出现异常" );
        }
    }


    protected void parseResult( final SMSEntity smsEntity )
    {
        try
        {
            smsEntity.getChannelEntity().setWeight( smsEntity.getChannelEntity().getWeight() - 10 );
            result = StringUtils.trimToEmpty( result );
        }
        catch ( Exception e )
        {
            logger.error( "短信發送完畢，組裝發送結果出現異常：{}", e.getMessage(), e );
//            throw new SenderException( e.getMessage(), e );
        }
        finally
        {
            logger.info( "{}短信發送結果：{}.", channelName, result );
        }
    }

    public SMSNotifyService getSmsNotifyService()
    {
        return smsNotifyService;
    }

    @Resource( name = "smsNotifyService" )
    public void setSmsNotifyService( SMSNotifyService smsNotifyService )
    {
        this.smsNotifyService = smsNotifyService;
    }
}
