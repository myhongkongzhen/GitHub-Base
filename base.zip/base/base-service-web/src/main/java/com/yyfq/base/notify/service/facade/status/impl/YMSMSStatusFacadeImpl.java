/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.status.impl;

import com.thoughtworks.xstream.XStream;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.service.facade.status.impl.vo.Report;
import com.yyfq.base.notify.service.facade.status.impl.vo.ReportList;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.status.impl.YMSMSStatusFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 23:12
 *   LastChange: 2016-1-18 23:12
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "ymSMSStatusFacade" )
public class YMSMSStatusFacadeImpl extends SMSStatusFacadeImpl //implements YMSMSStatusFacade
{
    private static final Logger logger = LoggerFactory.getLogger( YMSMSStatusFacadeImpl.class );

    @Async
    @Override
    public void parseResult( String statusbox ) throws BizException
    {
        statusbox = getStatus( statusbox );
        logger.info( "亿美短信通道状态报告解析:{}.", statusbox );

        List< TSmsSend > list = new ArrayList<>();

        ReportList xml = null;
        try
        {
            XStream xStream = new XStream();
            xStream.processAnnotations( ReportList.class );
            xml = ( ReportList ) xStream.fromXML( statusbox );
        }
        catch ( Exception e )
        {
            logger.error( "解析状态报告结果出现异常..{}", e.getMessage(), e );
        }
        List< Report > reportList = xml.getReport();
        if ( null != xml && null != reportList && !reportList.isEmpty() )
        {
            for ( Report report : reportList )
            {

                TSmsSend smsSend = null;
                try
                {
                    smsSend = new TSmsSend();
                    smsSend.setChannelReceiveStatus( report.getReportStatus() );
                    smsSend.setChannelSubmitDesc( report.getErrorCode() );
                    smsSend.setSmsId( report.getSeqId() );
                    Date receiveTime = NotifyUtil.INSTANCE.getDate( report.getReceiveDate(),
                                                                    NotifyUtil.INSTANCE.YYYYMMDDHHMMSS );
                    smsSend.setChannelReceiveTime( ( ( null == receiveTime ) ? new Date() : receiveTime ) );
                }
                catch ( Exception e )
                {
                    logger.error( "解析状态报告结果出现异常..{}", e.getMessage(), e );
                }

                list.add( smsSend );

            }
        }

        udpateDatabase( list );
    }

    private String getStatus( String statusbox )
    {
        statusbox = StringUtils.trimToEmpty( statusbox );
        try
        {
            statusbox = URLDecoder.decode( statusbox, "utf-8" );
        }
        catch ( UnsupportedEncodingException e )
        {
        }
        return statusbox;
    }
}
