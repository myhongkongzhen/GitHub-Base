package com.yyfq.base.wei.controller;

import java.io.IOException;
import java.net.URLDecoder;

import javax.annotation.Resource;

import org.apache.http.client.ClientProtocolException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.facade.email.EmailFacade;

@Controller
public class SendEmailServiceWebController {
	
	@Resource(name="emailFacade")
	private EmailFacade emailFacade;
	
	@RequestMapping(value = "sendEmail", method = RequestMethod.GET)
	@ResponseBody
	public Result testSendMoBan(Model model, String param) throws ClientProtocolException, IOException {
		EmailDTO email = getSmsParam(param);
		Result result = null;
		System.out.println("【==>】次发送邮件开始");
		result = emailFacade.sendEmail(email);
		System.out.println("【==>】次发送邮件结束");
		return result;
	}
	
	private EmailDTO getSmsParam(String msg) {
		EmailDTO param = null;
		try {
			msg = URLDecoder.decode(msg, "utf-8");
			param = JSONObject.parseObject(msg, EmailDTO.class);
			if (null == param) {
				throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
			}
			return param;
		} catch (Exception e) {
			throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
		}
	}
}
