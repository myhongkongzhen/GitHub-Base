/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.impl;

import com.thoughtworks.xstream.XStream;
import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.common.exception.ServiceException;
import com.yyfq.base.notify.service.sms.sender.SMSNotifyServerHttp;
import com.yyfq.base.notify.service.sms.sender.vo.YMResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.sender.YMChannelHttpServiceImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 14:42
 *   LastChange: 2016-1-13 14:42
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "YM_CHANNEL_CODE" )
public class YMChannelHttpServiceImpl extends SMSNotifyServerHttp
{
    private final static Logger logger       = LoggerFactory.getLogger( YMChannelHttpServiceImpl.class );
    private static final String CHANNEL_NAME = "【亿美】通道";

    @Value( "${channel.ym.cdkey}" )
    private String cdkey;
    @Value( "${channel.ym.password}" )
    private String password;
    @Value( "${channel.ym.url}" )
    private String httpUrl;

    public YMChannelHttpServiceImpl()
    {
        super();
        super.channelName = CHANNEL_NAME;
    }

    @Async( value = "YM_CHANNEL_Executor" )
    @Override
    public synchronized void sendData( final SMSEntity smsEntity )
    {
        super.sendData( smsEntity );
    }

    @Override
    protected void parseResult( final SMSEntity smsEntity )
    {
        try
        {
            super.parseResult( smsEntity );

            XStream xStream = new XStream();
            xStream.processAnnotations( YMResponse.class );
            YMResponse xml = ( YMResponse ) xStream.fromXML( result );

            if ( null == xml || StringUtils.isBlank( StringUtils.trimToEmpty( xml.getError() ) ) || !StringUtils
                    .equalsIgnoreCase( "0", StringUtils.trimToEmpty( xml.getError() ) ) || null == xml.getMessage() ||
                 xml.getMessage().isEmpty() )
            {
                logger.warn( "{}短信发送结果异常！", channelName );
                throw ServiceException.SERVICE_NOTIFY_SMS_PARSE_RESULT_EXCEPTION;
            }

//            smsEntity.setChannelStatus( xml.getMessage().get( 0 ).getState() );
//            smsEntity.setSmsid( xml.getMessage().get( 0 ).getSeqid() );
            smsEntity.setChannelStatus( xml.getError() );
        }
        catch ( Exception e )
        {
            logger.error( "短信發送完畢，組裝發送結果出現異常：{}", e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_SMS_PARSE_RESULT_EXCEPTION;
        }
    }

    @Override
    public String httpUrl()
    {
        return httpUrl;
    }

    @Override
    public void httpParam( final SMSEntity smsEntity )
    {
        param = new ConcurrentHashMap< String, String >();
        param.put( "cdkey", cdkey );
        param.put( "password", password );
        param.put( "encode", "utf-8" );

        param.put( "phone", smsEntity.getMobile() );
        param.put( "message", smsEntity.getContent() );
        param.put( "seqid", smsEntity.getSmsid() );

    }
}
