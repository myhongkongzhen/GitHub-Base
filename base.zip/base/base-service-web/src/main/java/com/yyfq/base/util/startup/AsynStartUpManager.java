package com.yyfq.base.util.startup;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.stereotype.Component;

import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.senders.EmailSender;

/**
 * 线程、Queue管理器
 * 
 * @author 文龙 2014-04-09
 */
@Component("asynStartUpManage")
@Lazy(false)
public class AsynStartUpManager extends ApplicationObjectSupport {
	
	private static Logger log = LoggerFactory.getLogger(AsynStartUpManager.class);
	
	/**
	 * 线程池的大小
	 */
	private String threadPoolCount = "50";
	
	/**
	 * 邮件发送接口
	 */
	@Resource
	private EmailSender emailSender;

	/**
	 * 异步线程池
	 */
	private ExecutorService executor = null;
	
	/**
	 * 短信队列
	 * 
	 *//*
	private ConcurrentLinkedQueue<SmsMessagePo> smsQueue;*/

	/**
	 * 参数模式邮件发送队列
	 *//*
	private ConcurrentLinkedQueue<Map<String, String>> commonParamEmailQueue;*/

	/**
	 * HTML内容模式邮件发送队列
	 */
	private ConcurrentLinkedQueue<EmailDTO> htmlStringEmailQueue;

	/**
	 * 下订单邮件发送队列
	 *//*
	private ConcurrentLinkedQueue<MailSendNewDTO> downOrderEmailQueue;*/
	
	/**
	 * 短信发送线程
	 *//*
	private SendSmsCall sendSmsCall;
	*/
	/**
	 * 参数模式邮件发送线程
	 *//*
	private CommonParamEmailSendCall commonParamEmailSendcall;*/
	
	/**
	 * 下订单邮件发送线程
	 *//*
	private DownOrderEmailSendCall downOrderEmailSendCall;
	
	/**
	 * HTML内容模式邮件发送线程
	 */
	private HtmlStringEmailSendCall htmlStringEmailSendCall;

	/**
	 * 初始化方法
	 */
	@PostConstruct
	public void init() {
		// 初始化线程池，Queue
		/*smsQueue = new ConcurrentLinkedQueue<SmsMessagePo>();*/
		/*commonParamEmailQueue = new ConcurrentLinkedQueue<Map<String, String>>();*/
		htmlStringEmailQueue = new ConcurrentLinkedQueue<EmailDTO>();
		/*downOrderEmailQueue = new ConcurrentLinkedQueue<MailSendNewDTO>();*/
		executor = Executors.newFixedThreadPool(Integer.valueOf(threadPoolCount));
	}

	/**
	 * 发送HTML内容邮件Queue
	 */
	public boolean sendHtmlStringMailQueue(EmailDTO eMailDTO) {
		boolean result =  htmlStringEmailQueue.offer(eMailDTO);
		if(result){
			log.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +":Html内容模板邮件已经放入htmlStringEmailQueue中:" + eMailDTO);
			htmlStringEmailSendCall = new HtmlStringEmailSendCall(emailSender, htmlStringEmailQueue);
			this.executor.submit(htmlStringEmailSendCall);
		}
		return result;
	}

}
