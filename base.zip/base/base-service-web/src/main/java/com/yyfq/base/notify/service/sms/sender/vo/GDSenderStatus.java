/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.vo;

import org.apache.commons.lang3.StringUtils;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.status.GDSenderStatus
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 20:53
 *   LastChange: 2016-1-13 20:53
 *      History:
 * </pre>
 **************************************************************************/
public enum GDSenderStatus
{
    /**
     * 01	批量短信提交成功
     * 02	IP限制
     * 03	单条短信提交成功
     * 04	用户名错误
     * 05	 密码错误
     * 07	 发送时间错误
     * 08	信息内容为黑内容
     * 09	该用户的该内容 受同天内，内容不能重复发 限制
     * 10	 扩展号错误
     * 97	短信参数有误
     * 11	余额不足
     * -1	程序异常
     */
    MULT_SUBMIT( "批量短信提交成功", "01" ),
    IP_CHECK( "02", "IP限制" ),
    SINGLE_SUBMIT( "单条短信提交成功", "03" ),
    USERNAME_ERROR( "用户名错误", "04" ),
    USERPASS_ERROR( "密码错误", "05" ),
    SENDTIME_ERROR( "发送时间错误", "07" ),
    CONTENT_ERROR( "信息内容为黑内容", "08" ),
    TIMES_CHECK( "该用户的该内容 受同天内，内容不能重复发 限制", "09" ),
    EXTEND_ERROR( "扩展号错误", "10" ),
    PARAM_ERROR( "短信参数有误", "97" ),
    MONEY_ERROR( "余额不足", "11" ),
    SYS_ERROR( "程序异常", "-1" );

    private String status;
    private String desc;

    GDSenderStatus( String desc, String status )
    {
        this.status = status;
        this.desc = desc;
    }

    public static String getDesc( String status )
    {
        for ( GDSenderStatus c : GDSenderStatus.values() )
        {
            if ( StringUtils.equalsIgnoreCase( c.status, status ) )
            {
                return c.desc;
            }
        }
        return null;
    }
}
