/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.status.impl.vo;

/**************************************************************************
 * <pre>
 *     FileName: zzwu.std.util.ReportList
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-19 12:09
 *   LastChange: 2016-1-19 12:09
 *      History:
 * </pre>
 **************************************************************************/

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;

@XStreamAlias( "reportList" )
public class ReportList
{
    /**
     * <?xml version="1.0" encoding="UTF-8"?>
     * <reportList>
     * <report>
     * <seqId>3456</seqId>
     * <reportStatus>0</reportStatus>
     * <mobile>15010359299</mobile>
     * <errorCode>deliver</errorCode>
     * <submitDate>20100109152333</submitDate>
     * <receiveDate>20100109152339</receiveDate>
     * </report>
     * </reportList>
     */

    @XStreamImplicit( itemFieldName = "report" )
    private List< Report > report = null;

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof ReportList ) )
            return false;

        ReportList that = ( ReportList ) o;

        return getReport() != null ? getReport().equals( that.getReport() ) : that.getReport() == null;

    }

    @Override
    public int hashCode()
    {
        return getReport() != null ? getReport().hashCode() : 0;
    }

    public List< Report > getReport()
    {

        return report;
    }

    public void setReport( List< Report > report )
    {
        this.report = report;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "ReportList{" );
        sb.append( "report=" ).append( report );
        sb.append( '}' );
        return sb.toString();
    }
}
