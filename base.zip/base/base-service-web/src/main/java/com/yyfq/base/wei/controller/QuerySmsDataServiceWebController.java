package com.yyfq.base.wei.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.QuerySmsDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.facade.NotifyFacade;

/**
 * @ClassName: QuerySmsDataController.java
 * @Description: 短信查询Controller
 * @author zhuweicheng
 * @date 2016年2月19日
 */
@Controller
public class QuerySmsDataServiceWebController {
	
	@Resource(name="smsNotifyFacade")
	private NotifyFacade smsNotifyFacade;
	
	@RequestMapping(value="querySmsData")
	@ResponseBody
	public Result<Object> querySmsData(Model model,String param) {
		
		QuerySmsDTO querySmsDto = JSONObject.parseObject(param, QuerySmsDTO.class);
		
		Result<Object> result = smsNotifyFacade.querySmsData(querySmsDto); 
		
		if(result.getRet().equals("0")){
			model.addAttribute("flag", 0);
			model.addAttribute("data", result.getData());
		} else {
			model.addAttribute("flag", 1);
		}
		
		return result;
	}
	
}
