package com.yyfq.base.notify.service.mail.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailConstant;
import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.dao.MailSend.EmailSendMapper;
import com.yyfq.base.notify.dao.entity.MailSend.TEmailSend;
import com.yyfq.base.notify.service.mail.EmailService;
import com.yyfq.base.util.startup.AsynStartUpManager;

/**
 * @ClassName: MailServiceImpl.java
 * @Description: 邮件服务实现类
 * @author zhuweicheng
 * @date 2016年1月30日
 */
@SuppressWarnings("all")
@Component
public class EmailServiceImpl implements EmailService {

	//日志
	private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);
	
	@Resource
	private EmailSendMapper emailDao;
	
	/**
	 * 异步线程、Queue管理器
	 */
	@Resource(name="asynStartUpManage")
	private AsynStartUpManager asynStartUpManage;
	
	/**
	 * 检查参数
	 * @param emailDto
	 * @return Result<EmailDTO>
	 */
	public Result checkParam(EmailDTO emailDto) {
		//先检查对象与对象的参数是否为空
		if (null == emailDto || StringUtils.isBlank(emailDto.getToEmail()) 
				|| StringUtils.isBlank(emailDto.getFromEmail())
				|| StringUtils.isBlank(emailDto.getPassWord())
				|| StringUtils.isBlank(emailDto.getMailTitle()) 
				|| StringUtils.isBlank(String.valueOf(emailDto.getType()))) {
			logger.info(EmailConstant.getMsg(EmailConstant.EMAIL_PARAM_NULL));
			return new Result(EmailConstant.EMAIL_PARAM_NULL, 
										EmailConstant.EMAIL_PARAM_NULL, 
										EmailConstant.getMsg(EmailConstant.EMAIL_PARAM_NULL), 
										null);
		}
		
		//邮箱是否合法
		 if (!NotifyUtil.INSTANCE.isEmail( emailDto.getToEmail())){
            logger.warn( "邮件不合法，");
            return new Result(EmailConstant.EMAIL_ERROR,
										EmailConstant.EMAIL_ERROR,
										EmailConstant.getMsg(EmailConstant.EMAIL_ERROR),
										null);
        }
		return null;
	}

	/**
	 * 插入邮件发送记录
	 * @param emailDto
	 * return Result<TEmailSend>
	 */
	public Result insert(EmailDTO emailDto,String status) {
		Result<TEmailSend> result = new Result<TEmailSend>();
		TEmailSend email = new TEmailSend();
		try {
			email.setContent(emailDto.getContent());
			email.setFromEmail(emailDto.getFromEmail());
			email.setSendTime(new Date());
			email.setStatus(Integer.valueOf(status));
			email.setSubmitBussName(emailDto.getBussName());
			email.setSubmitBussTime(new Date());
			email.setMailTitle(emailDto.getMailTitle());
			email.setToEmail(emailDto.getToEmail());
			email.setSendType(emailDto.getType());
			email.setSendErrMsg(EmailConstant.getMsg(status));
			
			int insertResult = emailDao.insert(email);
			if(1 == insertResult) {//插入成功
				result.setData(email);
			} else { //插入失败
				result.setMsg(EmailConstant.getMsg(EmailConstant.EMAIL_INSERT_ERROR));
				result.setRet(EmailConstant.EMAIL_INSERT_ERROR);
				result.setErrCode(EmailConstant.EMAIL_INSERT_ERROR);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("insert TEmailSend record is fail(插入邮件发送记录失败):"+e.getMessage());
		}
		return result;
	}

	/**
	 * 发送邮件
	 * 	1，检查参数
	 * 	2，发送邮件，拿到状态
	 * 	3，插入数据库
	 * @param emailDto
	 * @param result
	 * @throws Exception
	 */
	@Override
	public Result sendNewEmail(EmailDTO emailDto, Result result) throws Exception{
		// 检查参数，合格返回空
		long start = System.currentTimeMillis();
		result = checkParam(emailDto);
		long end = System.currentTimeMillis();
		logger.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +":1.1 邮件内容验证时间："+ (end-start));
		if (null != result) {//验证没有通过
			return result;
		}
		// 发送邮件
		String status = "";
		result = new Result();
		try {
			start = System.currentTimeMillis();
			//放入异步队列池
			boolean sendSuc = asynStartUpManage.sendHtmlStringMailQueue(emailDto);
			end = System.currentTimeMillis();
			logger.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +":1.2 邮件发Queue提交线程时间："+ (end-start));
			
			if(sendSuc){
				status = EmailConstant.EMAIL_SEND_CACHE;
			} else {
				status = EmailConstant.EMAIL_SEND_FAIL;
				result.setRet(EmailConstant.EMAIL_SEND_FAIL);
				result.setMsg(EmailConstant.getMsg(EmailConstant.EMAIL_QUEUE_FULL));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("发送邮件异常。邮件信息： " + emailDto.toString(), e);
			status = EmailConstant.EMAIL_SEND_FAIL;
			result.setRet(EmailConstant.EMAIL_SEND_FAIL);
			result.setMsg(EmailConstant.getMsg(EmailConstant.EMAIL_SEND_FAIL));
		}
		
		try {
			Result insertResult = insert(emailDto,status);
		} catch (Exception e) {
			logger.error("邮件发送记录插入到数据库异常(注意：邮件发送不受影响，继续发送)。邮件发送记录信息：" + emailDto, e);
		}
		return result;
	}

}
