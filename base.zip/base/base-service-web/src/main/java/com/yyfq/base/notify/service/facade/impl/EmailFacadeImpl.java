package com.yyfq.base.notify.service.facade.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailConstant;
import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.notify.facade.email.EmailFacade;
import com.yyfq.base.notify.service.mail.EmailService;

/**
 * @ClassName: EmailServiceImpl.java
 * @Description: 邮件facade实现类
 * @author zhuweicheng
 * @date 2016年1月29日
 */
@Component("emailFacade")
public class EmailFacadeImpl implements EmailFacade {

	private static final Logger logger = LoggerFactory.getLogger(EmailFacadeImpl.class);

	@Resource
	private EmailService emailService;
	
	 /** 异常提示 */
    private static final String ERROR_MSG = "发送邮件异常";

	@Override
	public Result sendEmail(EmailDTO emailDto){
		Result result=new Result();
		try {
			long start = System.currentTimeMillis();
			result = emailService.sendNewEmail(emailDto, result);
			long end = System.currentTimeMillis();
			logger.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +":1 邮件总发送时间："+ (end - start) +":单条邮件内容：" + emailDto);
		} catch (Exception ex) {
			logger.error(ERROR_MSG, ex);
			result.setRet(EmailConstant.EMAIL_SEND_FAIL);
			result.setMsg(ex.getMessage());
		}
		return result;
	}
	
}
