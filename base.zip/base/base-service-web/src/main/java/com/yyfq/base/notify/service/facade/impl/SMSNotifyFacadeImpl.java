/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.impl;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.RedisKeyConstant;
import com.yyfq.base.notify.common.ShardedJedisOperator;
import com.yyfq.base.notify.common.dto.ChannelEntity;
import com.yyfq.base.notify.common.dto.QuerySmsDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.common.dto.SMSParam;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.exception.DBException;
import com.yyfq.base.notify.common.exception.ServiceException;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.common.util.NotifyConstant;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.facade.NotifyFacade;
import com.yyfq.base.notify.facade.check.SecurityCheckFacade;
import com.yyfq.base.notify.service.NotifyService;
import com.yyfq.base.notify.service.sms.QuerySmsDataService;
import com.yyfq.base.notify.service.sms.SMSChannelCache;
import com.yyfq.base.notify.service.sms.SMSChannelSeletor;
import com.yyfq.base.notify.service.sms.SMSNotifyService;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import javax.annotation.Resource;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.impl.SMSNotifyFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 12:00
 *   LastChange: 2016-1-18 12:00
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "smsNotifyFacade" )
public class SMSNotifyFacadeImpl implements NotifyFacade< SMSParam >
{
    private static final Logger logger = LoggerFactory.getLogger( SMSNotifyFacadeImpl.class );
    private ShardedJedisOperator            shardedJedisOperator;
    private SMSNotifyService                smsNotifyService;
    private VelocityEngine                  velocityEngine;
    private NotifyService< SMSEntity >      notifyService;
    private ApplicationContext              applicationContext;
    private SecurityCheckFacade< SMSParam > securityCheckFacade;
    
    @Resource
	private QuerySmsDataService querySmsDataService;

    @Value( "${yy.sms.isdemo}" )
    private String isdemo;
    
    @Override
    public /*synchronized*/ Result< SMSParam > sendSingleMsg( final SMSParam smsParam ) throws BizException
    {
        logger.info( "Dubbo服务调用单发短信请求开始....." );
        Result< SMSParam > rs = checkSmsParam( smsParam );
        if ( rs != null && StringUtils.equalsIgnoreCase( rs.getRet(), "1" ) )
            return rs;


        TSmsSend ss = null;
        try
        {
            logger.info( "发送短信业务请求参数校验完成，开始准备发送短信数据...{}.", JSONObject.toJSONString( smsParam ) );
            sendSMS( smsParam, ss );

            return new Result< SMSParam >( smsParam );
        }
        catch ( BizException e )
        {
            updateDatabaseFail( smsParam, ss );
            return new Result< SMSParam >( "1", String.valueOf( e.getCode() ), e.getMsg(), smsParam );
        }
        catch ( Exception e )
        {
            updateDatabaseFail( smsParam, ss );
            return new Result< SMSParam >( "1", String.valueOf( WebException.SYSTEM_EXCEPTION.getCode() ),
                                           WebException.SYSTEM_EXCEPTION.getMsg(), smsParam );
        }
    }

    private void sendSMS( SMSParam smsParam, TSmsSend ss ) throws Exception
    {
        smsParam.setNotifysysuuid( NotifyUtil.INSTANCE.getsysuuid() );
        smsParam.setSendTime( new Date() );

        // -- 2016-1-12 09:47:03 查詢redis，判斷 mobile-type 是否存在，60m
        // 如果存在，使用緩存中的code，否則，重新生成code
        constructSMSContant( smsParam );

        // -- 2016-1-12 16:41:50 通道選擇
        ChannelEntity channelEntity = getChannelEntity( smsParam );

        // 存入數據庫
        ss = insertSMSSendRecord( smsParam, channelEntity.getChannelCode() );

        // -- 2016-1-13 10:23:34 發送短信服務調用
        if(isdemo.equals("99")) {
        	sendSMSContent( smsParam, channelEntity, ss.getId() );
        }
    }

    private ChannelEntity getChannelEntity( SMSParam smsParam )
    {
        ChannelEntity channelEntity /*= null;
        if ( StringUtils.equalsIgnoreCase( smsParam.getType(), "-1" ) )
        {
            channelEntity = SMSChannelCache.getChannelEntity( "YM_CHANNEL_CODE" );
        }
        if ( null == channelEntity )
            channelEntity*/ = SMSChannelSeletor.INSTANCE.selectChannel( SMSChannelCache.getCache() );

        logger.info( "智能调度短信通道==>>>{}.", JSONObject.toJSONString( channelEntity ) );
        return channelEntity;
    }

    private Result< SMSParam > checkSmsParam( SMSParam smsParam )
    {
        if ( null == smsParam )
        {
            return new Result< SMSParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_NULL.getCode() ),
                                           WebException.WEB_REQ_ARGS_NULL.getMsg(), smsParam );
        }

        logger.info( "准备校验请求参数..{}..", smsParam.toString() );

        try
        {
            Result< SMSParam > result = securityCheckFacade.checkParam( smsParam );
            if ( null != result )
                logger.info( "完成参数校验...{}..", JSONObject.toJSONString( result ) );
            return result;
        }
        catch ( BizException e )
        {
            return new Result< SMSParam >( "1", String.valueOf( e.getCode() ), e.getMsg(), smsParam );
        }
        catch ( Exception e )
        {
            return new Result< SMSParam >( "1", String.valueOf( WebException.SYSTEM_EXCEPTION.getCode() ),
                                           WebException.SYSTEM_EXCEPTION.getMsg(), smsParam );
        }
    }

//    private Result< SMSParam > getSmsParamResult( String errCode, String msg )
//    {
//        Result rs = new Result();
//        rs.setErrCode( errCode );
//        rs.setMsg( msg );
//        rs.setRet( "1" );
//        return rs;
//    }

    //    @Async( value = "smsAsyncThread" )
    @Override
    public /*synchronized*/ Result< SMSParam > sendMultMsg( final Collection< SMSParam > list ) throws BizException
    {

        logger.info( "Dubbo服务调用群发短信请求开始....." );

        if ( null == list || list.isEmpty() )
        {
            return new Result< SMSParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_NULL.getCode() ),
                                           WebException.WEB_REQ_ARGS_NULL.getMsg() );
        }

        boolean flag = false;
        for ( SMSParam smsParam : list )
        {
            try
            {
                Result< SMSParam > result = sendSingleMsg( smsParam );
                if ( result != null && StringUtils.equalsIgnoreCase( result.getRet(), "1" ) )
                {
                    flag = true;
                }
            }
            catch ( Exception e )
            {
                logger.error( "批量发送短信：{}，出现异常.{}..", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
                flag = true;
            }
        }

        if ( flag )
        {
            return new Result< SMSParam >( "1", String.valueOf( WebException.SYSTEM_EXCEPTION.getCode() ),
                                           "群发短信中存在异常请求，其他正常请求短信已发送." );
        }
        else
            return new Result< SMSParam >( "0", "全部群发短信提交成功" );
    }

    private void updateDatabaseFail( final SMSParam smsParam, TSmsSend smsSend )
    {
        try
        {
            if ( null == smsSend )
            {
                smsSend = constructSMSSendRecord( smsParam, "ERROR_CHANNEL_CODE" );
            }

            int rs = smsNotifyService.updateByUUID( smsSend );
            if ( rs == 0 )
            {
                smsNotifyService.insert( smsSend );
            }
        }
        catch ( Exception e )
        {
            logger.error( "短信发送记录{},更新数据库出现异常,{}", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
//            throw new DatabaseOperateException( "发送短信记录存入数据库时出现异常" );
        }
    }

    private void sendSMSContent( final SMSParam smsParam, final ChannelEntity channelEntity, Long id ) throws Exception
    {
        try
        {
            SMSEntity smsEntity = new SMSEntity();
            smsEntity.setContent( smsParam.getContent() );
            smsEntity.setMobile( smsParam.getMobile() );
            smsEntity.setChannelEntity( channelEntity );
            smsEntity.setSmsParam( smsParam );
            smsEntity.setNotifysysuuid( smsParam.getNotifysysuuid() );
            //  -- 2016-1-18 19:24:01 億美通道需要長整形消息ID
            smsEntity.setSmsid( String.valueOf( id.intValue() ) );

            logger.info( "通知服务准备短信发送实体完成:{},异步发送短信.", smsEntity.toString() );
            notifyService = ( NotifyService< SMSEntity > ) applicationContext.getBean( channelEntity.getChannelCode() );
            notifyService.sendData( smsEntity );
        }
        catch ( Exception e )
        {
            logger.error( "选择通道发送短信:{}，出现异常,{}", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_SEND_EXCEPTION;
        }
    }

    private TSmsSend insertSMSSendRecord( final SMSParam smsParam, String channelCode )
    {
        TSmsSend ss = null;
        try
        {
            ss = constructSMSSendRecord( smsParam, channelCode );
            if ( smsNotifyService.insert( ss ) == 0 )
            {
                throw DBException.DB_INSERT_RESULT_0;
            }

            return ss;
        }
        catch ( Exception e )
        {
            logger.error( "短信发送记录{},存入数据库出现异常,{}", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
            //  -- 2016-1-13 10:22:27 存入數據庫異常后的處理，後續添加
            throw DBException.DB_INSERT_RESULT_0;
        }
    }

    private TSmsSend constructSMSSendRecord( final SMSParam smsParam, String channelCode )
    {
        TSmsSend ss = new TSmsSend();
        ss.setReceiveMobile( smsParam.getMobile() );
        ss.setSmsChannelCode( channelCode );
        ss.setSmsContent( smsParam.getContent() );
        ss.setSmsSendTime( new Date() );
        ss.setSmsSource( smsParam.getSource() );
        ss.setSmsType( Integer.valueOf( smsParam.getType() ) );
        ss.setSubmitBussDepartment( smsParam.getBussdepartment() );
        ss.setSubmitBussTime( smsParam.getSendTime() );
        ss.setSubmitBussUid( smsParam.getBussuid() );
        ss.setNotifySysUuid( smsParam.getNotifysysuuid() );

        logger.info( "通知服务构造短信实体完成：{},存入短信发送基础表.", JSONObject.toJSONString( ss ) );
        return ss;
    }

    private void constructSMSContant( final SMSParam smsParam )
    {

        String mobile  = smsParam.getMobile();
        String content = smsParam.getContent();
        String type    = smsParam.getType();

        // 短信內容由業務系統傳入，還是後台生成
        String redisKey = String.format( RedisKeyConstant.KEY_SMS_SECURITYCODE_TYPE_MOBILE_CONTENT, type, mobile );

        try
        {
            if ( StringUtils.isBlank( content ) )
            {
                if ( shardedJedisOperator.exists( redisKey ) )
                {
                    // 存在
                    String _content = shardedJedisOperator.get( redisKey );

                    if ( StringUtils.isBlank( _content ) )
                    {
                        logger.info( "Redis键值key：{}，对应数据为[{}]，重新构造短信内容.", redisKey, _content );

                        content = resetContent( smsParam, redisKey );
                    }
                    else
                    {
                        content = _content;
                    }
                }
                else
                {
                    // 不存在
                    content = resetContent( smsParam, redisKey );
                }

                smsParam.setContent( content );
            }
            else
            {
                smsParam.setContent( StringUtils.join( "【有用分期】", content ) );
            }

            if ( !StringUtils.equalsIgnoreCase( "-1", smsParam.getType() ) && !shardedJedisOperator.exists( redisKey ) )
                setContentRedis( redisKey, content );
        }
        catch ( BizException e )
        {
            logger.error( "根据短信类型模板{}，构造短信内容时出现异常,{}", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
            throw e;
        }
        catch ( Exception e )
        {
            logger.error( "根据短信类型模板{}，构造短信内容时出现异常,{}", JSONObject.toJSONString( smsParam ), e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_TYPE_ERROR;
        }
        finally
        {
            logger.info( "短信内容准备完成===>Redis键值key：{}，商户1小时内验证码类短信对应数据：{}.", redisKey, content );
        }
    }

    private String resetContent( final SMSParam smsParam, String redisKey )
    {
        String content = constructContent( smsParam );
        smsParam.setContent( content );
        setContentRedis( redisKey, content );

        return content;
    }

    private void setContentRedis( String redisKey, String content )
    {
        if ( StringUtils.isBlank( StringUtils.trimToEmpty( shardedJedisOperator.set( redisKey, content ) ) ) )
        {
            throw ServiceException.SERVICE_NOTIFY_REDIS_SET_EXCEPTION;
        }
        shardedJedisOperator.expire( redisKey, NotifyConstant.EXPIRE_ONE_HOUR );
    }

    private String constructContent( final SMSParam smsParam )
    {
        String                path = smsParam.getTemplatePath();
        Map< String, Object > map  = new HashMap<>();
        map.put( "code", NotifyUtil.INSTANCE.getPhoneCode() );
        // TODO -- 2016-1-17 22:48:44 多參數替換
        map.put( "userid", NotifyUtil.INSTANCE.getPhoneCode() );
        return VelocityEngineUtils.mergeTemplateIntoString( velocityEngine, path, "UTF-8", map );
    }

    public ShardedJedisOperator getShardedJedisOperator()
    {
        return shardedJedisOperator;
    }

    @Resource
    public void setShardedJedisOperator( ShardedJedisOperator shardedJedisOperator )
    {
        this.shardedJedisOperator = shardedJedisOperator;
    }

    public SMSNotifyService getSmsNotifyService()
    {
        return smsNotifyService;
    }

    @Resource( name = "smsNotifyService" )
    public void setSmsNotifyService( SMSNotifyService smsNotifyService )
    {
        this.smsNotifyService = smsNotifyService;
    }

    public VelocityEngine getVelocityEngine()
    {
        return velocityEngine;
    }

    @Resource
    public void setVelocityEngine( VelocityEngine velocityEngine )
    {
        this.velocityEngine = velocityEngine;
    }

    public ApplicationContext getApplicationContext()
    {
        return applicationContext;
    }

    @Resource
    public void setApplicationContext( ApplicationContext applicationContext )
    {
        this.applicationContext = applicationContext;
    }

    public SecurityCheckFacade< SMSParam > getSecurityCheckFacade()
    {
        return securityCheckFacade;
    }

    @Resource( name = "securityCheckFacade" )
    public void setSecurityCheckFacade( SecurityCheckFacade< SMSParam > securityCheckFacade )
    {
        this.securityCheckFacade = securityCheckFacade;
    }
    
    //短信查询facade实现
    @Override
	public Result<Object> querySmsData(QuerySmsDTO querySmsDto) {
		Result<Object> result = new Result<Object>();
		try {
			//判断一下手机号码不能为空
			if(StringUtils.isBlank(querySmsDto.getMobile())) {
				result.setRet("1");
				result.setErrCode("1");
				result.setMsg("查询手机号为空");
				return result;
			}
			//查询
			long start = System.currentTimeMillis();
			List<QuerySmsDTO> list = querySmsDataService.querySmsData(querySmsDto);
			long end = System.currentTimeMillis();
			logger.info("query smsData log-->"+ Thread.currentThread().getName() +":1查询短信时间："+ (end - start) +":查询条件为：" + querySmsDto);
			result.setData(list);
		} catch (Exception ex) {
			logger.error("短信查询异常", ex);
			result.setRet("-1");
			result.setMsg(ex.getMessage());
		}
		return result;
	}
}
