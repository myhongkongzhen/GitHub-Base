package com.yyfq.base.senders.impl;

import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import com.yyfq.base.notify.common.dto.email.EmailConstant;
import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.senders.EmailSender;

/**
 * 默认邮件发送器
 * @author 文龙 2014-04-09
 */
@Service
public class EmailSenderImpl implements EmailSender{
	
	private static Logger logger = LoggerFactory.getLogger(EmailSenderImpl.class);

	/**
	 * 邮件发送器
	 */
	@Resource(name="mailSender")
    private JavaMailSenderImpl mailSender;
    
    /**
     * 邮件信息
     */
	@Resource(name="simpleMailMessage")
    private SimpleMailMessage simpleMailMessage;
    
    /**
     * 线程构造器
     * @param paramMap 模版参数集
     * @param javaMailSender 邮件发送器
     */
	/*public EmailSenderImpl(SimpleMailMessage simpleMailMessage, JavaMailSender mailSender){
    	this.mailSender = mailSender;
    	this.simpleMailMessage = simpleMailMessage;
    }*/
	
	/**
	 * 原始的邮箱发送
	 * @param eMailDTO
	 */
	public void sendHtmlStringEmail(EmailDTO eMailDTO){
		JavaMailSenderImpl jmsi = new JavaMailSenderImpl();
        try {  
        	/*第一种，不可设置发件人
        	 * MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage,true);  
            messageHelper.setTo(eMailDTO.getToEmail());  
            messageHelper.setFrom(simpleMailMessage.getFrom());  
            messageHelper.setSubject(eMailDTO.getMailTitle());
            messageHelper.setText(eMailDTO.getContent(),true);
            mailSender.send(mimeMessage);*/
        	
        	//邮件smtp发件服务器配置，可自由设置发件人地址与密码
        	jmsi.setDefaultEncoding(mailSender.getDefaultEncoding());
        	jmsi.setHost(mailSender.getHost());
        	jmsi.setPassword(eMailDTO.getPassWord());
        	jmsi.setUsername(eMailDTO.getFromEmail());
        	Properties pt = new Properties();
            pt.setProperty("mail.smtp.auth", mailSender.getJavaMailProperties().getProperty("mail.smtp.auth"));
            pt.setProperty("mail.smtp.timeout", mailSender.getJavaMailProperties().getProperty("mail.smtp.timeout"));
            jmsi.setJavaMailProperties(pt);
            
            //邮件信息
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(eMailDTO.getFromEmail());//发件地址
            msg.setTo(eMailDTO.getToEmail());//收件地址
            msg.setSubject(eMailDTO.getMailTitle());//标题
            msg.setText(eMailDTO.getContent());//内容
            
            mailSender.send(msg);
            
        } catch (Exception e) { 
        	e.printStackTrace();
            logger.error(EmailConstant.getMsg(EmailConstant.EMAIL_SEND_FAIL), e);
        }
	}
	
}
