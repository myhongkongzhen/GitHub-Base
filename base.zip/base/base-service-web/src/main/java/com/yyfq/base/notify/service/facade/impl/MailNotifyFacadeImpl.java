/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.impl;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.RedisKeyConstant;
import com.yyfq.base.notify.common.ShardedJedisOperator;
import com.yyfq.base.notify.common.dto.MailParam;
import com.yyfq.base.notify.common.dto.QuerySmsDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.exception.DBException;
import com.yyfq.base.notify.common.exception.ServiceException;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.common.template.MailTemplateEnum;
import com.yyfq.base.notify.common.util.NotifyConstant;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.common.util.PropertiesUtil;
import com.yyfq.base.notify.dao.MailSend.MailSendMapper;
import com.yyfq.base.notify.dao.entity.MailSend.TMailSend;
import com.yyfq.base.notify.facade.NotifyFacade;
import com.yyfq.base.notify.service.mail.MailNotifyService;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import javax.annotation.Resource;

import java.util.*;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.impl.MailNotifyFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 22:16
 *   LastChange: 2016-1-26 22:16
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "mailNotifyFacade" )
public class MailNotifyFacadeImpl implements NotifyFacade< MailParam >
{
    private static final Logger logger           = LoggerFactory.getLogger( MailNotifyFacadeImpl.class );
    private static final String EMAIL_PROPERTIES = "email.properties";
    private MailNotifyService    mailNotifyService;
    private ShardedJedisOperator shardedJedisOperator;
    private VelocityEngine       velocityEngine;
    private MailSendMapper       mailSendMapper;

    @Override
    public Result< MailParam > sendSingleMsg( MailParam mailParam ) throws BizException
    {
        logger.info( "通知服务平台单发邮件服务开始..." );

        try
        {
            //  -- 2016-1-26 01:24:50 做郵件校驗工作，內容模板，數據庫存儲工作
            Result< MailParam > x = checkParam( mailParam );
            if ( x != null )
                return x;
        }
        catch ( BizException e )
        {
            return new Result< MailParam >( "1", String.valueOf( e.getCode() ), e.getMsg(), mailParam );
        }

        TMailSend tMailSend = null;
        try
        {
            tMailSend = insertDBMailRecord( mailParam, tMailSend );

            // 異步發送郵件
            mailNotifyService.sendData( mailParam );

            return new Result<>( mailParam );
        }
        catch ( BizException e )
        {
            updateDatabaseFail( mailParam, tMailSend );

            return new Result< MailParam >( "1", String.valueOf( e.getCode() ), e.getMsg(), mailParam );
        }
        catch ( Exception e )
        {
            updateDatabaseFail( mailParam, tMailSend );
            return new Result< MailParam >( "1", String.valueOf( WebException.SYSTEM_EXCEPTION.getCode() ),
                                            WebException.SYSTEM_EXCEPTION.getMsg(), mailParam );
        }
    }

    private TMailSend insertDBMailRecord( MailParam mailParam, TMailSend tMailSend )
    {
        constructMailContant( mailParam );

        tMailSend = constructMailSend( mailParam );

        if ( mailSendMapper.insertSelective( tMailSend ) == 0 )
        {
            throw DBException.DB_INSERT_RESULT_0;
        }
        mailParam.setNotifysysuuid( String.valueOf( tMailSend.getId() ) );
        return tMailSend;
    }

    private void updateDatabaseFail( MailParam mailParam, TMailSend tMailSend )
    {
        try
        {
            if ( null == mailParam )
            {
                tMailSend = constructMailSend( mailParam );
            }

            if ( mailSendMapper.updateByPrimaryKeySelective( tMailSend ) == 0 )
            {
                mailSendMapper.insertSelective( tMailSend );
                mailParam.setNotifysysuuid( String.valueOf( tMailSend.getId() ) );
            }
        }
        catch ( Exception e )
        {
            logger.error( "郵件发送记录{},插入或更新数据库出现异常,{}", JSONObject.toJSONString( mailParam ), e.getMessage(), e );
        }
    }

    private TMailSend constructMailSend( MailParam mailParam )
    {
        TMailSend tMailSend = new TMailSend();
        tMailSend.setMailContent( mailParam.getContent() );
        tMailSend.setMailSendTime( mailParam.getSendTime() );
        tMailSend.setMailSource( mailParam.getSource() );
        tMailSend.setMailSub( mailParam.getSubject() );
        tMailSend.setMailTo( ArrayUtils.toString( mailParam.getTo() ) );
        tMailSend.setMailType( Integer.valueOf( mailParam.getType() ) );
        tMailSend.setSubmitBussUid( mailParam.getBussuid() );
        tMailSend.setSubmitBussDepartment( mailParam.getBussdepartment() );
        tMailSend.setMailSendStatus( false );
        logger.info( "通知服务构造郵件实体完成：{},存入郵件发送基础表.", JSONObject.toJSONString( tMailSend ) );
        return tMailSend;
    }

    private void constructMailContant( MailParam mailParam )
    {
        mailParam.setSendTime( new Date() );

        String content = mailParam.getContent();
        String mailTo  = JSONObject.toJSONString( mailParam.getTo() );
        String type    = mailParam.getType();

        // 短信內容由業務系統傳入，還是後台生成
        String redisKey = String.format( RedisKeyConstant.KEY_MAIL_SECURITYCODE_TYPE_MAILTO_CONTENT, type, mailTo );
        try
        {
            if ( StringUtils.isBlank( content ) )
            {
                if ( shardedJedisOperator.exists( redisKey ) )
                {
                    // 存在
                    String _content = shardedJedisOperator.get( redisKey );

                    if ( StringUtils.isBlank( _content ) )
                    {
                        logger.info( "Redis键值key：{}，对应数据为[{}]，重新构造郵件内容.", redisKey, _content );

                        content = resetContent( mailParam, redisKey );
                    }
                    else
                    {
                        content = _content;
                    }
                }
                else
                {
                    // 不存在
                    content = resetContent( mailParam, redisKey );
                }

                mailParam.setContent( content );
            }

            if ( !StringUtils.equalsIgnoreCase( "-1", mailParam.getType() ) && !shardedJedisOperator.exists(
                    redisKey ) )
                setContentRedis( redisKey, content );
        }
        catch ( Exception e )
        {
            logger.error( "根据类型模板{}，构造郵件内容时出现异常,{}", JSONObject.toJSONString( mailParam ), e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_TYPE_ERROR;
        }
        finally
        {
            logger.info( "郵件内容准备完成===>Redis键值key：{}，24小时内用戶郵件主題：{}，內容：{}.", redisKey, mailParam.getSubject(), content );
        }
    }

    private String resetContent( MailParam mailParam, String redisKey )
    {
        String     content    = "";
        Properties properties = PropertiesUtil.INSTANCE.getPropertiesValue( EMAIL_PROPERTIES );

        String mailTypeDesc = MailTemplateEnum.getName( Integer.valueOf( mailParam.getType() ) );
        String templateName = properties.getProperty( mailTypeDesc + "_VM" );// 模板
        String subject      = properties.getProperty( mailTypeDesc + "_SUB" );// 主题
        String url          = mailTypeDesc + "_URL";// URL

        // 封装邮件发送
        Map< String, Object > mapModel = new HashMap< String, Object >();
        mapModel.put( "loginName", mailParam.getBussuid() );
        mapModel.put( "la", properties.getProperty( url ) );

        content = VelocityEngineUtils.mergeTemplateIntoString( velocityEngine, templateName, "UTF-8", mapModel );
        mailParam.setContent( content );
        mailParam.setSubject( subject );

        setContentRedis( content, redisKey );
        return content;
    }

    private void setContentRedis( String content, String redisKey )
    {
        if ( StringUtils.isBlank( StringUtils.trimToEmpty( shardedJedisOperator.set( redisKey, content ) ) ) )
        {
            throw ServiceException.SERVICE_NOTIFY_REDIS_SET_EXCEPTION;
        }
        shardedJedisOperator.expire( redisKey, NotifyConstant.EXPIRE_FORTYFOUR_HOUR );
    }

    private Result< MailParam > checkParam( MailParam mailParam )
    {
        if ( null == mailParam )
        {
            return new Result< MailParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_NULL.getCode() ),
                                            WebException.WEB_REQ_ARGS_NULL.getMsg(), mailParam );
        }

        if ( null == mailParam.getTo() || mailParam.getTo().length == 0 )
        {
            return new Result< MailParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_MAILADRR_ERROR.getCode() ),
                                            WebException.WEB_REQ_ARGS_MAILADRR_ERROR.getMsg(), mailParam );
        }

        for ( int i = 0; i < mailParam.getTo().length; i++ )
        {
            if ( !NotifyUtil.INSTANCE.isEmail( mailParam.getTo()[ i ] ) )
            {
                logger.warn( "群发邮件中存在异常邮箱地址，过滤掉....{}..", mailParam.getTo()[ i ] );
                mailParam.getTo()[ i ] = null;
            }
        }

        if ( StringUtils.isBlank( mailParam.getType() ) )
        {
            return new Result< MailParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_NOTIFY_TYPE_NULL.getCode() ),
                                            WebException.WEB_REQ_ARGS_NOTIFY_TYPE_NULL.getMsg(), mailParam );
        }
        return null;
    }

    @Override
    public Result< MailParam > sendMultMsg( Collection< MailParam > list ) throws BizException
    {
        logger.info( "通知服务平台群发邮件服务开始..." );

        if ( null == list || list.isEmpty() )
        {
            return new Result< MailParam >( "1", String.valueOf( WebException.WEB_REQ_ARGS_NULL.getCode() ),
                                            WebException.WEB_REQ_ARGS_NULL.getMsg() );
        }

        boolean flag = false;
        for ( MailParam mailParam : list )
        {
            try
            {
                Result< MailParam > result = sendSingleMsg( mailParam );
                if ( result != null && StringUtils.equalsIgnoreCase( result.getRet(), "1" ) )
                {
                    flag = true;
                }
            }
            catch ( Exception e )
            {
                logger.error( "批量发送邮件：{}，出现异常.{}..", JSONObject.toJSONString( mailParam ), e.getMessage(), e );
                flag = true;
            }
        }

        if ( flag )
        {
            return new Result< MailParam >( "1", String.valueOf( WebException.SYSTEM_EXCEPTION.getCode() ),
                                            "群发邮件中存在异常请求，其他正常请求邮件已发送." );
        }
        else
            return new Result< MailParam >( "0", "全部群发邮件提交成功" );

    }

    public MailNotifyService getMailNotifyService()
    {
        return mailNotifyService;
    }

    @Resource
    public void setMailNotifyService( MailNotifyService mailNotifyService )
    {
        this.mailNotifyService = mailNotifyService;
    }

    public ShardedJedisOperator getShardedJedisOperator()
    {
        return shardedJedisOperator;
    }

    @Resource
    public void setShardedJedisOperator( ShardedJedisOperator shardedJedisOperator )
    {
        this.shardedJedisOperator = shardedJedisOperator;
    }

    public VelocityEngine getVelocityEngine()
    {
        return velocityEngine;
    }

    @Resource
    public void setVelocityEngine( VelocityEngine velocityEngine )
    {
        this.velocityEngine = velocityEngine;
    }

    public MailSendMapper getMailSendMapper()
    {
        return mailSendMapper;
    }

    @Resource
    public void setMailSendMapper( MailSendMapper mailSendMapper )
    {
        this.mailSendMapper = mailSendMapper;
    }

	@Override
	public Result<Object> querySmsData(QuerySmsDTO querySmsDto) {
		return null;
	}
}
