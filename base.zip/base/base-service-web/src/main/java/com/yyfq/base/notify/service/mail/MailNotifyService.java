/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.mail;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.MailParam;
import com.yyfq.base.notify.dao.MailSend.MailSendMapper;
import com.yyfq.base.notify.dao.entity.MailSend.TMailSend;
import com.yyfq.base.notify.service.NotifyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.mail.MailNotifyService
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-26 01:15
 *   LastChange: 2016-1-26 01:15
 *      History:
 * </pre>
 **************************************************************************/
@Service
public class MailNotifyService implements NotifyService< MailParam >
{
    private static final Logger logger = LoggerFactory.getLogger( MailNotifyService.class );
    private JavaMailSender    mailSender;
    private SimpleMailMessage simpleMailMessage;
    private MailSendMapper    mailSendMapper;

    @Async( value = "mailAsyncThread" )
    @Override
    public synchronized void sendData( final MailParam mailParam )
    {
        logger.info( "开始异步发送邮件通知...." );
        String from = simpleMailMessage.getFrom();

        try
        {
            simpleMailMessage.setFrom( from ); // 发送人,从配置文件中取得
            simpleMailMessage.setTo( mailParam.getTo() ); // 接收人,單發群發自動選擇
            simpleMailMessage.setSubject( mailParam.getSubject() );
            simpleMailMessage.setText( mailParam.getContent() );
            mailSender.send( simpleMailMessage );

            updateMailRecord( mailParam, from, true );
        }
        catch ( MailException e )
        {
            updateMailRecord( mailParam, from, false );

            logger.error( "异步发送邮件：{}出现异常：{}", JSONObject.toJSONString( mailParam ), e.getMessage(), e );
        }
    }

    private void updateMailRecord( MailParam mailParam, String from, boolean status )
    {
        TMailSend tMailSend = new TMailSend();
        tMailSend.setId( Long.valueOf( mailParam.getNotifysysuuid() ) );
        tMailSend.setMailSendStatus( status );
        tMailSend.setMailFrom( from );

        if ( mailSendMapper.updateByPrimaryKeySelective( tMailSend ) == 0 )
        {
//            tMailSend.setMailContent( mailParam.getContent() );
//            tMailSend.setMailSendTime( mailParam.getSendTime() );
//            tMailSend.setMailSource( mailParam.getSource() );
//            tMailSend.setMailSub( mailParam.getSubject() );
//            tMailSend.setMailTo( mailParam.getTo() );
//            tMailSend.setMailType( Integer.valueOf( mailParam.getType() ) );
//            tMailSend.setSubmitBussUid( mailParam.getBussuid() );
//            tMailSend.setSubmitBussDepartment( mailParam.getBussdepartment() );
//            tMailSend.setMailSendStatus( status );
//            mailSendMapper.insertSelective( tMailSend );
        }
    }

    public JavaMailSender getMailSender()
    {
        return mailSender;
    }

    @Resource( name = "mailSender" )
    public void setMailSender( JavaMailSender mailSender )
    {
        this.mailSender = mailSender;
    }

    public SimpleMailMessage getSimpleMailMessage()
    {
        return simpleMailMessage;
    }

    @Resource( name = "simpleMailMessage" )
    public void setSimpleMailMessage( SimpleMailMessage simpleMailMessage )
    {
        this.simpleMailMessage = simpleMailMessage;
    }

    public MailSendMapper getMailSendMapper()
    {
        return mailSendMapper;
    }

    @Resource
    public void setMailSendMapper( MailSendMapper mailSendMapper )
    {
        this.mailSendMapper = mailSendMapper;
    }
}
