/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.common;

import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Response;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPipeline;
import redis.clients.jedis.ShardedJedisPool;

import javax.annotation.Resource;
import java.util.Map;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.core.common.JedisSharedOperator
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-12 22:07
 *   LastChange: 2016-1-12 22:07
 *      History:
 * </pre>
 **************************************************************************/
@Service
public class ShardedJedisOperator
{
    private static final Logger logger = LoggerFactory.getLogger( ShardedJedisOperator.class );

    private ShardedJedisPool shardedJedisPool;

    public ShardedJedisPool getShardedJedisPool()
    {
        return shardedJedisPool;
    }

    @Resource
    public void setShardedJedisPool( ShardedJedisPool shardedJedisPool )
    {
        this.shardedJedisPool = shardedJedisPool;
    }

    public ShardedJedis getShardedJedis()
    {
        try
        {
            ShardedJedis jedis = shardedJedisPool.getResource();
            return jedis;
        }
        catch ( Exception e )
        {
            logger.error( "获取Redis客户端实例出现异常，{}.", e.getMessage(), e );
            return null;
        }
    }

    public void returnJedisResource( ShardedJedis jedis )
    {
        try
        {
            if ( null != jedis )
            {
                jedis.close();
                jedis = null;
            }
        }
        catch ( Exception e )
        {
            // ignore
        }
        finally
        {
            jedis = null;
        }
    }

    public Boolean exists( String redisKey )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return false;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< Boolean >  response = pipeline.exists( redisKey );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "判断Redis键值:{}是否存在时出现异常，{}.", redisKey, e.getMessage(), e );
            return false;
        }
        finally
        {
            returnJedisResource( jedis );
        }

    }

    public String get( String redisKey )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return null;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< String >   response = pipeline.get( redisKey );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "获取Redis键值:{}字符串值时出现异常，{}.", redisKey, e.getMessage(), e );
            return null;
        }
        finally
        {
            returnJedisResource( jedis );
        }
    }

    public Boolean hexists( String redisKey, String field )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return false;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< Boolean >  response = pipeline.hexists( redisKey, field );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "判断Redis键值:{}，hash域:{}是否存在时出现异常，{}.", redisKey, field, e.getMessage(), e );
            return false;
        }
        finally
        {
            returnJedisResource( jedis );
        }

    }

    public String hget( String redisKey, String field )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return null;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< String >   response = pipeline.hget( redisKey, field );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "获取Redis键值:{}，hash域值时出现异常，{}.", redisKey, field, e.getMessage(), e );
            return null;
        }
        finally
        {
            returnJedisResource( jedis );
        }
    }

    public String set( String redisKey, String value )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return null;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< String >   response = pipeline.set( redisKey, value );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "设置Redis键值:{}，value:{}時出现异常，{}.", redisKey, value, e.getMessage(), e );
            return null;
        }
        finally
        {
            returnJedisResource( jedis );
        }
    }

    public Long expire( String redisKey, int expire )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return null;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< Long >     response = pipeline.expire( redisKey, expire );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "设置Redis键值:{}，有效时常:{}時出现异常，{}.", redisKey, expire, e.getMessage(), e );
            return null;
        }
        finally
        {
            returnJedisResource( jedis );
        }
    }

    public String hmset( String redisKey, Map< String, String > hash )
    {
        ShardedJedis jedis = getShardedJedis();
        if ( null == jedis )
        {
            return null;
        }

        try
        {
            ShardedJedisPipeline pipeline = jedis.pipelined();
            Response< String >   response = pipeline.hmset( redisKey, hash );
            pipeline.syncAndReturnAll();
            return response.get();
        }
        catch ( Exception e )
        {
            logger.error( "存储Redis键值:{}，hash:{}時出现异常，{}.", redisKey, JSONObject.toJSONString( hash ), e.getMessage(),
                          e );
            return null;
        }
        finally
        {
            returnJedisResource( jedis );
        }
    }
}
