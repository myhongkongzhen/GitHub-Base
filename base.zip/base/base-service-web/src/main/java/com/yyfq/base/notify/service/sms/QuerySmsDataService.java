package com.yyfq.base.notify.service.sms;

import java.util.List;

import com.yyfq.base.notify.common.dto.QuerySmsDTO;

/**
 * @ClassName: QuerySmsDataService.java
 * @Description: 查询短信服务
 * @author zhuweicheng
 * @date 2016年2月19日
 */
public interface QuerySmsDataService {

	/**
	 * 通过条件查询短信内容
	 * @param querySmsDto
	 * @return List<QuerySmsDTO>
	 */
	List<QuerySmsDTO> querySmsData(QuerySmsDTO querySmsDto);
	
}
