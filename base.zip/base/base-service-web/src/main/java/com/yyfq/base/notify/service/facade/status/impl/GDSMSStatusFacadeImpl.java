/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.status.impl;

import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.util.NotifyUtil;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.status.impl.GDSMSStatusFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 23:08
 *   LastChange: 2016-1-18 23:08
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "gdSMSStatusFacade" )
public class GDSMSStatusFacadeImpl extends SMSStatusFacadeImpl //implements GDSMSStatusFacade
{
    private static final Logger logger = LoggerFactory.getLogger( GDSMSStatusFacadeImpl.class );


    @Async
    @Override
    public void parseResult( String statusbox ) throws BizException
    {
        statusbox = StringUtils.trimToEmpty( statusbox );
        logger.info( "国都短信通道状态报告解析:{}.", statusbox );

        String[]         rs   = StringUtils.splitByWholeSeparatorPreserveAllTokens( statusbox, ";" );
        logger.info( "此次国都短信通道共推送{}条状态报告.", rs.length );
        List< TSmsSend > list = new ArrayList<>();
        for ( String status : rs )
        {
            try
            {
                logger.info( "开始解析状态报告：{}.", status );
                String[] strings = StringUtils.splitByWholeSeparatorPreserveAllTokens( status, "," );

                if ( null != strings && ( strings.length == 6 || strings.length == 5 ) )
                {
                    TSmsSend smsSend = new TSmsSend();
                    smsSend.setChannelReceiveStatus( strings[ 2 ] );
                    smsSend.setSmsId( strings[ 3 ] );
                    Date receiveTime = NotifyUtil.INSTANCE.getDate( strings[ 4 ], NotifyUtil.INSTANCE.YYYYMMDDHHMMSS );
                    smsSend.setChannelReceiveTime( ( ( null == receiveTime ) ? new Date() : receiveTime ) );

                    list.add( smsSend );
                }
            }
            catch ( Exception e )
            {
                logger.error( "解析状态报告结果出现异常..{}", e.getMessage(), e );
            }
        }

        udpateDatabase( list );

        logger.info( "国都状态报告更新完成." );
    }


}
