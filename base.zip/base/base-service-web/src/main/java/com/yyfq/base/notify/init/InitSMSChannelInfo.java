/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.init;

import com.yyfq.base.notify.common.dto.ChannelEntity;
import com.yyfq.base.notify.service.sms.SMSChannelCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.InitSMSChannelInfo
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 00:05
 *   LastChange: 2016-1-13 00:05
 *      History:
 * </pre>
 **************************************************************************/
public class InitSMSChannelInfo
{
    private static final Logger logger = LoggerFactory.getLogger( InitSMSChannelInfo.class );
    private Set< ChannelEntity > channelEntitySet;

    public void init()
    {
        initSMSChannelWeight();
    }

    private void initSMSChannelWeight()
    {
        try
        {
            logger.info( "初始化短信通道权重信息...{}..", channelEntitySet.size() );
            SMSChannelCache.updateCache( channelEntitySet );
        }
        catch ( Exception e )
        {
            logger.error( "初始化短信通道权重信息出现异常,{},停止进程..", e.getMessage(), e );
            System.exit( 0 );
        }
        finally
        {
            logger.info( "初始化短信通道权重信息完成...共加载:{}:{}個缓存.", channelEntitySet.size(), SMSChannelCache.size() );
        }
    }

    public Set< ChannelEntity > getChannelEntitySet()
    {
        return channelEntitySet;
    }

    public void setChannelEntitySet( Set< ChannelEntity > channelEntitySet )
    {
        this.channelEntitySet = channelEntitySet;
    }
}
