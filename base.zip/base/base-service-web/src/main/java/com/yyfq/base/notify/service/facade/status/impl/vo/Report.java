/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.status.impl.vo;

/**************************************************************************
 * <pre>
 *     FileName: zzwu.std.util.Report
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-19 12:11
 *   LastChange: 2016-1-19 12:11
 *      History:
 * </pre>
 **************************************************************************/
public class Report
{
    /**
     * <?xml version="1.0" encoding="UTF-8"?>
     * <reportList>
     * <report>
     * <seqId>3456</seqId>
     * <reportStatus>0</reportStatus>
     * <mobile>15010359299</mobile>
     * <errorCode>deliver</errorCode>
     * <submitDate>20100109152333</submitDate>
     * <receiveDate>20100109152339</receiveDate>
     * </report>
     * </reportList>
     */

    private String seqId;
    private String reportStatus;
    private String mobile;
    private String errorCode;
    private String submitDate;
    private String receiveDate;

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof Report ) )
            return false;

        Report report = ( Report ) o;

        if ( getSeqId() != null ? !getSeqId().equals( report.getSeqId() ) : report.getSeqId() != null )
            return false;
        if ( getReportStatus() != null ? !getReportStatus().equals( report.getReportStatus() )
                                       : report.getReportStatus() != null )
            return false;
        if ( getMobile() != null ? !getMobile().equals( report.getMobile() ) : report.getMobile() != null )
            return false;
        if ( getErrorCode() != null ? !getErrorCode().equals( report.getErrorCode() ) : report.getErrorCode() != null )
            return false;
        if ( getSubmitDate() != null ? !getSubmitDate().equals( report.getSubmitDate() )
                                     : report.getSubmitDate() != null )
            return false;
        return getReceiveDate() != null ? getReceiveDate().equals( report.getReceiveDate() )
                                        : report.getReceiveDate() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getSeqId() != null ? getSeqId().hashCode() : 0;
        result = 31 * result + ( getReportStatus() != null ? getReportStatus().hashCode() : 0 );
        result = 31 * result + ( getMobile() != null ? getMobile().hashCode() : 0 );
        result = 31 * result + ( getErrorCode() != null ? getErrorCode().hashCode() : 0 );
        result = 31 * result + ( getSubmitDate() != null ? getSubmitDate().hashCode() : 0 );
        result = 31 * result + ( getReceiveDate() != null ? getReceiveDate().hashCode() : 0 );
        return result;
    }

    public String getSeqId()
    {

        return seqId;
    }

    public void setSeqId( String seqId )
    {
        this.seqId = seqId;
    }

    public String getReportStatus()
    {
        return reportStatus;
    }

    public void setReportStatus( String reportStatus )
    {
        this.reportStatus = reportStatus;
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setMobile( String mobile )
    {
        this.mobile = mobile;
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode( String errorCode )
    {
        this.errorCode = errorCode;
    }

    public String getSubmitDate()
    {
        return submitDate;
    }

    public void setSubmitDate( String submitDate )
    {
        this.submitDate = submitDate;
    }

    public String getReceiveDate()
    {
        return receiveDate;
    }

    public void setReceiveDate( String receiveDate )
    {
        this.receiveDate = receiveDate;
    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "Report{" );
        sb.append( "errorCode='" ).append( errorCode ).append( '\'' );
        sb.append( ", mobile='" ).append( mobile ).append( '\'' );
        sb.append( ", receiveDate='" ).append( receiveDate ).append( '\'' );
        sb.append( ", reportStatus='" ).append( reportStatus ).append( '\'' );
        sb.append( ", seqId='" ).append( seqId ).append( '\'' );
        sb.append( ", submitDate='" ).append( submitDate ).append( '\'' );
        sb.append( '}' );
        return sb.toString();
    }
}
