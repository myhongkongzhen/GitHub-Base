package com.yyfq.base.notify.service.sms.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.yyfq.base.notify.common.dto.QuerySmsDTO;
import com.yyfq.base.notify.dao.SmsSend.SmsSendMapper;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.service.sms.QuerySmsDataService;

/**
 * @ClassName: QuerySmsDataServiceImpl.java
 * @Description: 查询短信接口服务实现类
 * @author zhuweicheng
 * @date 2016年2月19日
 */
@Service
public class QuerySmsDataServiceImpl implements QuerySmsDataService {

	private static final Logger logger = LoggerFactory.getLogger(QuerySmsDataServiceImpl.class);

	@Resource
	private SmsSendMapper smsSendMapper;
	
	/**
	 * 通过条件查询短信数据
	 * @param querySmsDto
	 * @return List<QuerySmsDTO>
	 */
	@Override
	public List<QuerySmsDTO> querySmsData(QuerySmsDTO querySmsDto) {
		List<QuerySmsDTO> result = null;
		try {
			//判断查询开始与结束时间
			Date fromDate = null,endDate = null;
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if(StringUtils.isNotBlank(querySmsDto.getStartDate())) {
				fromDate = df.parse(querySmsDto.getStartDate());
			}
			if(StringUtils.isNotBlank(querySmsDto.getEndDate())) {
				endDate = df.parse(querySmsDto.getEndDate());
			}
			
			List<TSmsSend> list = smsSendMapper.findSmsData(fromDate,endDate,
															querySmsDto.getMobile(),
															querySmsDto.getChannel(),
															querySmsDto.getContent(),
															querySmsDto.getDepartment());
			//TSmsSend转成QuerySmsDTO
			result = convert(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("查询短信失败",e);
		}
		return result;
	}

	/**
	 * 把实体类转换成传输类，返回给调用者
	 * @param list<TsmsSend>
	 * @return List<QuerySmsDTO>
	 */
	private List<QuerySmsDTO> convert(List<TSmsSend> list) {
		List<QuerySmsDTO> result = new ArrayList<QuerySmsDTO>();
		QuerySmsDTO querySmsDto = null;
		for (TSmsSend tsms : list) {
			querySmsDto = new QuerySmsDTO();
			querySmsDto.setContent(tsms.getSmsContent());
			querySmsDto.setChannel(tsms.getSmsChannelCode());
			querySmsDto.setDepartment(tsms.getSubmitBussDepartment());
			querySmsDto.setSource(tsms.getSmsSource());
			querySmsDto.setSendTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(tsms.getSmsSendTime()));
			if(StringUtils.isNotBlank(tsms.getChannelReceiveStatus())) {
				if(tsms.getChannelReceiveStatus().equals("0")) {
					querySmsDto.setStatus("发送成功");
				} else {
					querySmsDto.setStatus("发送失败");
				}
			} else {
				querySmsDto.setStatus("发送失败");
			}
			querySmsDto.setMobile(tsms.getReceiveMobile());
			result.add(querySmsDto);
		}
		return result;
	}

	
}
