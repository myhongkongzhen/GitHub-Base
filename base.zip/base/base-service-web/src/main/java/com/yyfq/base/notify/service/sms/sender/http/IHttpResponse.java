/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.http;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.IHttpResponse
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 13:37
 *   LastChange: 2016-1-13 13:37
 *      History:
 * </pre>
 **************************************************************************/
public interface IHttpResponse< T, W >
{
    T parseResult( W w ) throws Exception;
}
