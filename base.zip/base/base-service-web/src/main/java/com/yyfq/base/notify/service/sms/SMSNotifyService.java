/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms;

import com.yyfq.base.notify.dao.SmsSend.SmsSendMapper;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.SMSNotifyService
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 11:13
 *   LastChange: 2016-1-18 11:13
 *      History:
 * </pre>
 **************************************************************************/
@Service( value = "smsNotifyService" )
public class SMSNotifyService
{
    private SmsSendMapper smsSendMapper;

    public int insert( final TSmsSend smsSend )
    {
        return smsSendMapper.insertSelective( smsSend );
    }

    public int updateByUUID( final TSmsSend smsSend )
    {
        return smsSendMapper.updateByUUIDSelective( smsSend );
    }

    public void updateBatch( final List< TSmsSend > list )
    {
        smsSendMapper.updateBatch( list );
    }

    public SmsSendMapper getSmsSendMapper()
    {
        return smsSendMapper;
    }

    @Resource
    public void setSmsSendMapper( SmsSendMapper smsSendMapper )
    {
        this.smsSendMapper = smsSendMapper;
    }
}
