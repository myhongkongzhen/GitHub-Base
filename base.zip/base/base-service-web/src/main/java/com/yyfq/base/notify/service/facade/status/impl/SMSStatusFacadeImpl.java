/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.status.impl;

import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.dao.SmsSend.SmsSendMapper;
import com.yyfq.base.notify.dao.entity.SmsSend.TSmsSend;
import com.yyfq.base.notify.facade.status.SMSStatusFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.status.impl.SMSStatusFacadeImpl
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-19 12:18
 *   LastChange: 2016-1-19 12:18
 *      History:
 * </pre>
 **************************************************************************/
public abstract class SMSStatusFacadeImpl implements SMSStatusFacade
{
    private static final Logger logger = LoggerFactory.getLogger( SMSStatusFacadeImpl.class );

    private SmsSendMapper smsSendMapper;

    protected void udpateDatabase( final List< TSmsSend > list ) throws BizException
    {
        try
        {
            if ( !list.isEmpty() )
            {
                logger.info( "本次更新状体报告:{}條.", list.size() );
                smsSendMapper.updateBatch( list );
            }
        }
        catch ( Exception e )
        {
            logger.error( "更新状态报告系统异常.{}", e.getMessage(), e );
        }
    }

    public SmsSendMapper getSmsSendMapper()
    {
        return smsSendMapper;
    }

    @Resource
    public void setSmsSendMapper( SmsSendMapper smsSendMapper )
    {
        this.smsSendMapper = smsSendMapper;
    }
}
