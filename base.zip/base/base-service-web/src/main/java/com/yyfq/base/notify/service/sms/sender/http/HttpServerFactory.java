/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.http;

import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.common.exception.ServiceException;
import com.yyfq.base.notify.common.util.HttpClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.http.HttpServerFactory
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-13 13:38
 *   LastChange: 2016-1-13 13:38
 *      History:
 * </pre>
 **************************************************************************/
public abstract class HttpServerFactory implements IHttpRequest< SMSEntity >
{
    private static final Logger logger = LoggerFactory.getLogger( HttpServerFactory.class );

    protected String                result      = "YYFQ_SMS_ERROR";
    protected String                channelName = null;
    protected Map< String, String > param       = null;
    protected Map< String, String > header      = null;

    @Override
    public String send() throws Exception
    {
        try
        {
            if ( StringUtils.isBlank( httpUrl() ) )
                throw ServiceException.SERVICE_NOTIFY_SEND_URL_NULL;
            logger.info( "{} HTTP请求-->url:{} == param:{} == param:{}", channelName, httpUrl(), header, param );

            return ( StringUtils.trimToEmpty( result = HttpClientUtil.INSTANCE.httpPost( httpUrl(), param, header ) ) );
        }
        catch ( Exception e )
        {
            logger.error( "{}HTTP請求出錯 : {}=={}--->{}. ", channelName, httpUrl(), param, e.getMessage(), e );
            throw ServiceException.SERVICE_NOTIFY_SEND_URL_EXCEPTION;
        }
        finally
        {
            logger.info( "{}HTTP请求完成,result:{}.", channelName, result );
        }
    }

    @Override
    public void httpHeader( SMSEntity smsEntity )
    {

    }


}
