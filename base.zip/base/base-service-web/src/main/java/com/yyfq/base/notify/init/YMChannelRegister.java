/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.init;

import com.yyfq.base.notify.common.dto.SMSEntity;
import com.yyfq.base.notify.service.NotifyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.init.YMChannelRegister
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 17:01
 *   LastChange: 2016-1-18 17:01
 *      History:
 * </pre>
 **************************************************************************/
public class YMChannelRegister
{
    private static final Logger logger = LoggerFactory.getLogger( YMChannelRegister.class );

    private NotifyService< SMSEntity > notifyService;

    public void register()
    {
        try
        {
            logger.info( "亿美短信通道注册开始....." );

            notifyService.sendData( null );
        }
        catch ( Exception e )
        {
            logger.error( "亿美短信通道注册出现异常,{}.", e.getMessage(), e );
            System.exit( 1 );
        }
        finally
        {
            logger.info( "亿美短信通道注册完成...." );
        }
    }

    public NotifyService< SMSEntity > getNotifyService()
    {
        return notifyService;
    }

    @Resource( name = "YM_CHANNEL_CODE_REGISTER" )
    public void setNotifyService( NotifyService< SMSEntity > notifyService )
    {
        this.notifyService = notifyService;
    }
}
