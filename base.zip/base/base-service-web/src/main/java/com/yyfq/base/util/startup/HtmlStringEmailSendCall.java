package com.yyfq.base.util.startup;

import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.senders.EmailSender;


/**
 * 邮件发送线程
 * @author 文龙 2014-04-09
 *
 */
class HtmlStringEmailSendCall implements Callable<Integer>{
	
	private static Logger log = LoggerFactory.getLogger(HtmlStringEmailSendCall.class);

	@Resource
	private EmailSender emailSender;
	
	private ConcurrentLinkedQueue<EmailDTO> htmlStringEmailQueue;
	
	/**
	 * 构造器
	 */
	HtmlStringEmailSendCall(EmailSender emailSender, ConcurrentLinkedQueue<EmailDTO> htmlStringEmailQueue){
		this.emailSender = emailSender;
		this.htmlStringEmailQueue = htmlStringEmailQueue;
	}
	
	@Override
	public Integer call() {
		int result = 0;
		
		long start = System.currentTimeMillis();
		
		EmailDTO EmailDTO = this.htmlStringEmailQueue.poll();
		if(EmailDTO == null){
			return result;
		}
		try {
			
			log.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +"：Html模板邮件开始发送：" + EmailDTO);
			long start2 = System.currentTimeMillis();
			emailSender.sendHtmlStringEmail(EmailDTO);
			long end2 = System.currentTimeMillis();
			log.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +"：1.2.1 邮件发送总时间："+ (end2-start2) +"Html模板邮件发送完成。");
			
			result = 1;
		} catch (Exception e) {
			log.error("邮件发送异常。", e);
		}
		
		long end = System.currentTimeMillis();
		log.info("EMAIL_LOG-->"+ Thread.currentThread().getName() +":1.2.2 Html模板邮件线程总执行时间："+ (end-start));
		
		return result;
	}
}
