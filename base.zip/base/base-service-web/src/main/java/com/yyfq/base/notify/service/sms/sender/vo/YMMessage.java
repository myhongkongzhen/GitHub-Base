/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.sms.sender.vo;

import java.io.Serializable;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.sms.sender.vo.YMResponse
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 17:22
 *   LastChange: 2016-1-18 17:22
 *      History:
 * </pre>
 **************************************************************************/
//@XStreamAlias( "" )
public class YMMessage implements Serializable
{

    /**
     * <?xml version="1.0" encoding="utf-8"?>
     * <response>
     * <error>0</error>
     * <message>
     * <srctermid>手机号</srctermid>
     * <submitDate>提交时间</submitDate>
     * <receiveDate>处理时间</receiveDate>
     * <addSerial>未用</addSerial>
     * <addSerialRev>扩展号</addSerialRev>
     * <state>状态值</state>
     * <seqid>消息ID</seqid>
     * </message>
     * </response>
     */

    private String srctermid;
    private String submitDate;
    private String receiveDate;
    private String addSerial;
    private String addSerialRev;
    private String state;
    private String seqid;


    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
            return true;
        if ( !( o instanceof YMMessage ) )
            return false;

        YMMessage ymMessage = ( YMMessage ) o;

        if ( getSrctermid() != null ? !getSrctermid().equals( ymMessage.getSrctermid() )
                                    : ymMessage.getSrctermid() != null )
            return false;
        if ( getSubmitDate() != null ? !getSubmitDate().equals( ymMessage.getSubmitDate() )
                                     : ymMessage.getSubmitDate() != null )
            return false;
        if ( getReceiveDate() != null ? !getReceiveDate().equals( ymMessage.getReceiveDate() )
                                      : ymMessage.getReceiveDate() != null )
            return false;
        if ( getAddSerial() != null ? !getAddSerial().equals( ymMessage.getAddSerial() )
                                    : ymMessage.getAddSerial() != null )
            return false;
        if ( getAddSerialRev() != null ? !getAddSerialRev().equals( ymMessage.getAddSerialRev() )
                                       : ymMessage.getAddSerialRev() != null )
            return false;
        if ( getState() != null ? !getState().equals( ymMessage.getState() ) : ymMessage.getState() != null )
            return false;
        return getSeqid() != null ? getSeqid().equals( ymMessage.getSeqid() ) : ymMessage.getSeqid() == null;

    }

    @Override
    public int hashCode()
    {
        int result = getSrctermid() != null ? getSrctermid().hashCode() : 0;
        result = 31 * result + ( getSubmitDate() != null ? getSubmitDate().hashCode() : 0 );
        result = 31 * result + ( getReceiveDate() != null ? getReceiveDate().hashCode() : 0 );
        result = 31 * result + ( getAddSerial() != null ? getAddSerial().hashCode() : 0 );
        result = 31 * result + ( getAddSerialRev() != null ? getAddSerialRev().hashCode() : 0 );
        result = 31 * result + ( getState() != null ? getState().hashCode() : 0 );
        result = 31 * result + ( getSeqid() != null ? getSeqid().hashCode() : 0 );
        return result;
    }

    public String getSrctermid()
    {

        return srctermid;
    }

    public void setSrctermid( String srctermid )
    {
        this.srctermid = srctermid;
    }

    public String getSubmitDate()
    {
        return submitDate;
    }

    public void setSubmitDate( String submitDate )
    {
        this.submitDate = submitDate;
    }

    public String getReceiveDate()
    {
        return receiveDate;
    }

    public void setReceiveDate( String receiveDate )
    {
        this.receiveDate = receiveDate;
    }

    public String getAddSerial()
    {
        return addSerial;
    }

    public void setAddSerial( String addSerial )
    {
        this.addSerial = addSerial;
    }

    public String getAddSerialRev()
    {
        return addSerialRev;
    }

    public void setAddSerialRev( String addSerialRev )
    {
        this.addSerialRev = addSerialRev;
    }

    public String getState()
    {
        return state;
    }

    public void setState( String state )
    {
        this.state = state;
    }

    public String getSeqid()
    {
        return seqid;
    }

    public void setSeqid( String seqid )
    {
        this.seqid = seqid;
    }

    public YMMessage()
    {

    }

    @Override
    public String toString()
    {
        final StringBuilder sb = new StringBuilder( "YMMessage{" );
        sb.append( "addSerial='" ).append( addSerial ).append( '\'' );
        sb.append( ", addSerialRev='" ).append( addSerialRev ).append( '\'' );
        sb.append( ", receiveDate='" ).append( receiveDate ).append( '\'' );
        sb.append( ", seqid='" ).append( seqid ).append( '\'' );
        sb.append( ", srctermid='" ).append( srctermid ).append( '\'' );
        sb.append( ", state='" ).append( state ).append( '\'' );
        sb.append( ", submitDate='" ).append( submitDate ).append( '\'' );
        sb.append( '}' );
        return sb.toString();
    }
}
