package com.yyfq.base.test;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.yyfq.base.notify.common.dto.CateInfoDTO;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.facade.BaseInfoFacade;

public class QueryCateInfoTest extends BaseTest {

	@Resource(name="baseInfoFacade")
	private BaseInfoFacade cateInfoFacade;
	
	@Test
	public void test() {
		
		CateInfoDTO cateDto = new CateInfoDTO();
		
		Result<List<CateInfoDTO>> result = cateInfoFacade.queryCateInfoList(cateDto);
		System.out.println(result.toString());
		
	}
	
}
