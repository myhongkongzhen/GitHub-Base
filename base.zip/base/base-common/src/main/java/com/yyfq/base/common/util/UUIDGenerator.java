package com.yyfq.base.common.util;

import java.util.UUID;

/**
 * UUID生成器
 * @author 文龙
 * @date 2016-1-5 上午10:32:13
 */
public class UUIDGenerator {
	/**
	 * 生成不带"-"的UUID
	 * @return UUID
	 */
	public static String getUUID() {
		UUID uuid = UUID.randomUUID();
		String uuidTem = uuid.toString();
		return uuidTem.replaceAll("-", "");
	}

}
