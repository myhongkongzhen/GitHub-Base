package com.yyfq.base.common.exception;

import com.yyfq.base.common.dto.Result;
import com.yyfq.base.common.enums.ExceptionEnum;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;


public class ExceptionProcessor {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionProcessor.class);

    /**
     * 参数异常处理
     * 
     * @Title: getParameterExceptionResult
     * @param
     * @return Result 返回类型
     * @throws
     */
    public static Result getParameterExceptionResult( ParameterException e) {
        Result result = new Result();
        result.setRet(Result.FAIL);
        result.setErrCode(ExceptionEnum.ERROE_CODE_PARAMETER);
        result.setMsg(e.getMessage());

        logger.error("ParameterException: errCode={}, errMsg={}",
                new Object[] { result.getErrCode(), result.getMsg() });
        return result;
    }

    /**
     * 业务异常处理
     * 
     * @Title: getBusinessExceptionResult
     * @param
     * @return Result 返回类型
     * @throws
     */
    public static Result getBusinessExceptionResult(BusinessException e) {
        String code = e.getCode();
        String msg = e.getMessage();

        Result result = new Result();
        result.setRet(Result.FAIL);
        if (StringUtils.isNotBlank(code)) {
            result.setErrCode(code);
            if (StringUtils.isNotBlank(msg)) {
                result.setMsg(msg);
            } else {
                result.setMsg(ExceptionEnum.BusExcep.getList().get(code));
            }
        } else {
            result.setErrCode(ExceptionEnum.ERROE_CODE_BUSINESS);
            result.setMsg(msg);
        }

        logger.info("BusinessException: errCode={}, errMsg={}",
                new Object[] { result.getErrCode(), result.getMsg() });
        return result;
    }

    /**
     * 系统异常处理
     * 
     * @Title: getExceptionResult
     * @param
     * @return Result 返回类型
     * @throws
     */
    public static Result getExceptionResult(Exception e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));

        Result result = new Result();
        result.setRet(Result.FAIL);
        result.setErrCode(ExceptionEnum.ERROE_CODE_SYSTEM);
        result.setMsg("system exception,please contact administrator!");

        logger.error("Exception: errCode={}, errMsg={}",
                new Object[] { result.getErrCode(), sw.toString() });
        return result;
    }

}
