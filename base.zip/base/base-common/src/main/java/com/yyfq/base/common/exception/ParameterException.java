package com.yyfq.base.common.exception;
/**
 * 参数异常
 * @ClassName: ParameterException 
 * @author 文龙
 * @date 2016-01-04 上午1:32:13 
 */
public class ParameterException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public ParameterException(String msg){
        super(msg);
    }

    public ParameterException(String msg, Throwable t){
        super(msg, t);
        setStackTrace(t.getStackTrace());
    }
}