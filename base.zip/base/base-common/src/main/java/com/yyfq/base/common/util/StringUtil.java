package com.yyfq.base.common.util;

import org.apache.commons.lang.StringUtils;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Author hedehe
 * Date   15/12/4 11:16
 */
public class StringUtil extends StringUtils {

    private static final String NUMBER_PATTERN = "[0-9]+";

    public static boolean isNum(String v){

        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(v);

        return matcher.matches();
    }

    public static String getExceptionMsg(Throwable t,int maxLeng)
	{
		String msg=t.getMessage();
		if(StringUtil.isEmpty(msg)){
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			try
			{
				t.printStackTrace(pw);
				msg=sw.toString();
				if(msg!=null && msg.length()>maxLeng){
					return msg.substring(0, maxLeng);
				}
				return msg;
			}
			finally
			{
			pw.close();
			}
		}else{
			if(msg.length()>maxLeng){
				return msg.substring(0, maxLeng);
			}else{
				return msg;
			}
		}
	}
    public static void main(String[] args) {
        System.out.println(StringUtil.isNum("jj"));
    }
}
