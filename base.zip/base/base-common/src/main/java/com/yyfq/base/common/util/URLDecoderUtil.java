package com.yyfq.base.common.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/**
 * Author hedehe
 * Date   15/12/16 19:46
 */
public class URLDecoderUtil {

    private static final String DEFAULT_CHART = "utf-8";

    public static final String decode(String v) throws UnsupportedEncodingException {
        return URLDecoder.decode(v, DEFAULT_CHART);
    }

    public static final String encode(String v) throws UnsupportedEncodingException {
        return URLEncoder.encode(v, DEFAULT_CHART);
    }

}
