package com.yyfq.base.common.constant;

public class RedisConstant {

	public static final int ONE_MINUTE = 60;

	public static final int ONE_HOUR = 60 * 60;

	public static final int ONE_DAY = 60 * 60 * 24;

	public static final String KEY_PREFIX_CONTRACT_ID = "contract_id:";

	public static final String KEY_PREFIX_LOGIN = "login_userid:";

	/**用户Redis Key*/
	public static final String KEY_USER = "user_id:";
	
	public static final String KEY_PREFIX_MOBILE_MSG_TIMES = "mobile_msg_times:";

	public static final String KEY_PREFIX_REGISTER_MSG_CODE = "register_msg_code:";
	
	public static final int REGISTER_MSG_CODE_ACTIVE_SECONDS = 60 * 60;

	public static final String KEY_PREFIX_RESET_PASSWORD_MSG_CODE = "reset_password_msg_code";


	/**
	 * 商品的今日申请统计
	 */
	public static final String KEY_GOODS_TODAY_APPLY_STAT = "goods_today_apply_stat";

	/**
	 * 商品销量统计
	 */
	public static final String KEY_GOODS_SALES_STAT = "goods_sales_stat";

	/**
	 * 个人红点
	 */
	public static final String KEY_USER_RED_DOT = "user_red_dot";

	/**
	 * 用户登录 hashMap
	 */
	public static final String KEY_USER_PASSPORT_USER_ID = "user_passport_user_id";

	/**
	 * 用户登录 hashMap
	 */
	public static final String KEY_USER_PASSPORT_MOBILE = "user_passport_mobile";

	/**
	 * 用户认证
	 */
	public static final String KEY_USER_AUTH_ACTIVE = "user_auth_active:";
	
	/** 用户*/
	public static final String KEY_PERSONAL = "personal_id:";

	/** 工作*/
	public static final String KEY_WORK = "work_id:";

	/**
	 * 热销商品
	 */
	public static final String KEY_HOT_SALE_GOODS_LIST = "hot_sale_goods_list";

	public static final String KEY_HOT_SALE_GOODS_ID_LIST = "hot_sale_goods_id_list";

	/**
	 * 推荐商品
	 */
	public static final String KEY_RECOMMEND_GOODS_LIST = "recommend_goods_list";

	public static final String KEY_RECOMMEND_GOODS_ID_LIST = "recommend_goods_id_list";

	/**
	 * 商品
	 */
	public static final String KEY_GOODDS_INFO = "goods_info:";
	
	/**
	 * 账户
	 */
	public static final String KEY_ACCOUNTS_INFO = "accounts_info:";

	/**
	 * 商品列表页默认排序
	 */
	public static final String KEY_GOODS_LIST_DEFAULT_SORT = "goods_list_default_sort";

	/**
	 * 采集成功key
	 */
	public static final String KEY_EXTRA_CREDIT_SUCCESS = "extra_credit_success:";

	/**
	 * 采集异常情况
	 */
	public static final String KEY_EXTRA_CREDIT_EXCEPTION = "extra_credit_exception:";

}
