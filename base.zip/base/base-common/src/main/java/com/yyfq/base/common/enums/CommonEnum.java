package com.yyfq.base.common.enums;

import java.util.HashMap;
import java.util.Map;

public class CommonEnum {
    
    /**
	 * 是否开具发票标识  
	 * 1:开发票   0：不开发票 缺省值为1
	 */
    public enum HasInvoice {
    	
        Invoice(1,"开发票"), 
        NotInvoice(0, "不开发票");

        private final Integer key;
        private final String value;
        
        private HasInvoice(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (HasInvoice e : HasInvoice.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 发票状态  
	 * 状态 1.正常 -1.无效(取消或退货等导致)
	 */
    public enum InvoiceStatus {
    	
        Normal(1,"正常"), 
        Invalid(-1, "无效");

        private final Integer key;
        private final String value;
        
        private InvoiceStatus(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (InvoiceStatus e : InvoiceStatus.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 订单业务日志类型
	 */
    public enum BusLogOptType {
    	
    	AddOrder(1,"新建订单"),
    	UpdateOrder(2,"修改订单"),
    	CancelOrder(3,"取消订单"),
    	OrderStatusToEffectively(4,"转有效订单"),
    	OrderStatusToInvalid(5,"转无效订单"),
    	RefundChangeGoods(6,"申请退换货"),
    	Repair(7,"报修");
    	
        private final Integer key;
        private final String value;
        
        private BusLogOptType(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (BusLogOptType e : BusLogOptType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 下单人类型
     * 1:用户 (默认)
     * 2:客服 
	 */
    public enum CreatorType {
    	
    	USERSELF(1,"用户"),
    	CUSTOMERSERVICE(2,"客服");
    	
        private final Integer key;
        private final String value;
        
        private CreatorType(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (CreatorType e : CreatorType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 订单来源
     * 1:PC  
     * 2:MOBILE
	 */
    public enum OrderForm {
    	
    	PC(1,"PC"),
    	MOBILE(2,"MOBILE");
    	
        private final Integer key;
        private final String value;
        
        private OrderForm(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (OrderForm e : OrderForm.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 订单支付方式
	 * 1 : 货到付款
     * 2 : 在线支付
	 */
    public enum PayType {
    	
    	ONLINEPAY(1,"在线支付"),
    	CDO(2,"货到付款");
    	
        private final Integer key;
        private final String value;
        
        private PayType(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (PayType e : PayType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 物流方式
	 * 1 :EMS
	 */
    public enum LogisticType {
    	
    	EMS(1,"EMS");
    	
        private final Integer key;
        private final String value;
        
        private LogisticType(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (LogisticType e : LogisticType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 订单发票类型
	 * 1 普通发票 
	 * 2 增值税专用发票
	 * 缺省值1
	 */
    public enum InvoiceType {
    	
    	NORMAL_INVOICE(1,"普通发票 "),
    	TAX_INVOICE(2,"增值税专用发票 ");
    	
        private final Integer key;
        private final String value;
        
        private InvoiceType(Integer key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (InvoiceType e : InvoiceType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    /**
	 * 订单类型
	 * 1      :新建普通订单
	 * 2      :抢购订单
	 * 3      :预售订单
	 * 4      :受理单生成订单
	 * 5      :受理单生成换货订单
	 */
    public enum OrderType {
    	
    	addOrder(1,"新建普通订单"),
    	panicBuyOrder(2,"抢购订单"),
    	saleOrder(3,"预售订单"),
    	acceptanceOrder(4,"受理单生成订单"),
    	acceptanceExchangeGoodsOrder(5,"受理单生成换货订单");
    	
        private final int key;
        private final String value;
        
        private OrderType(int key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public int getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<Integer, String> getList() {
            Map<Integer, String> map = new HashMap<Integer, String>();
            for (OrderType e : OrderType.values()) {
                map.put(e.getKey(), e.getValue());
            }
            return map;
        }
    }
    
    public static void main(String[] args){
    	System.out.println(CommonEnum.LogisticType.getList().values());
    }
	
}
