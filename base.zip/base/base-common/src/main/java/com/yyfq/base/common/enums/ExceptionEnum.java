package com.yyfq.base.common.enums;

import java.util.HashMap;
import java.util.Map;

public class ExceptionEnum {
	
	/**
	 * PARAMETER_OBJECT = "入参对象为null"
	 */
	public static final String PARAMETER_OBJECT = "入参对象为null";
	
	/**
	 * PARAMETER_VALUE = "入参对象的属性为null"
	 */
	public static final String PARAMETER_VALUE = "入参对象的属性为null";
	
	/**
	 * PARA_VALUE = "入参不合法"
	 */
	public static final String PARA_VALUE = "入参不合法";
	
	/**
	 * 异常类型:参数异常
	 */
	public static final String ERROE_CODE_PARAMETER = "100";
	
	/**
	 * 异常类型:业务异常
	 */
	public static final String ERROE_CODE_BUSINESS = "200";
	
	/**
	 * 异常类型:系统异常
	 */
	public static final String ERROE_CODE_SYSTEM = "300";
	
	/**
	 * 业务异常 
     * 201：订单不存在
	 */
    public enum BusExcep {
    	
        OrderNotExist("201","订单不存在"),
        OrderNotAllowCancel("202","当前状态不允许取消订单"),
        OrderNotAllowUpdate("203","当前状态不允许修改订单"),
        NoOrderStatusToInvalid("204","当前订单状态已经为无效状态，无需进行订单转无效操作"),
        NoOrderStatusToEffectively("205","当前订单状态不为无效状态，无需进行订单转有效操作"),
        FindOrderDeliverAddrFromUserFail("206","从用户中心获取收货地址信息失败"),
        GetUserInfoFromUserFail("207","从用户中心获取用户信息失败"),
        UserStatusDenied("208","当前用户已冻结"),
        GetGoodsListByGoodsCodeFail("209","从商品中心获取商品信息详情列表失败"),
        GoodsAvailableStockLack("210","商品可定量库存不足"),
        UpdateAvailableStock("211","更新商品可定量库存失败"),
        ListOrderGoodsDetailFail("212","获取商品信息详情列表失败"),
        PayTypeUpdateFail("213","支付方式为在线支付，并且已经完成在线付款的，不能修改为货到付款"),
        OrderSalesExecuteFail("214","调促销中心进行订单价格正算失败"),
        OrderCardExecuteFail("215","调促销优惠券失败");
        
        private final String key;
        private final String value;
        
        private BusExcep(String key, String value) {
            this.key = key;
            this.value = value;
        }
        
        public String getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
         
        public static Map<String, String> getList() {
            Map<String, String> map = new HashMap<String, String>();
            for (BusExcep e : BusExcep.values()) {
                map.put(String.valueOf(e.getKey()), e.getValue());
            }
            return map;
        }
    }
	
}
