package com.yyfq.base.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public class DateUtil
{
	// 默认显示日期的格式
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String TIMEF_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String TIMEF_FORMAT24 = "yyyy-MM-dd HH24:mi:ss";
	// 默认显示日期时间毫秒格式
	public static final String MSEL_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	// 默认显示简体中文日期的格式
	public static final String ZHCN_DATE_FORMAT = "yyyy年MM月dd日";
	// 默认显示简体中文日期时间的格式
	public static final String ZHCN_TIME_FORMAT = "yyyy年MM月dd日HH时mm分ss秒";
	// 默认显示简体中文日期时间毫秒格式
	public static final String ZHCN_MSEL_FORMAT = "yyyy年MM月dd日HH时mm分ss秒SSS毫秒";
	// 获取日期串格式
	public static final String DATE_STR_FORMAT = "yyyyMMdd";
	// 获取日期时间串格式
	public static final String TIME_STR_FORMAT = "yyyyMMddHHmmss";
	// 获取日期时间毫秒串格式
	public static final String MSEL_STR_FORMAT = "yyyyMMddHHmmssSSS";
	
    /**
	 * 取得yyyy-MM-dd HH:mm:ss格式的当前时间
	 * @return
	 */
	public static String yyyyMMddHHmmssNow() {
		return yyyyMMddHHmmss(new Date());
	}
	
	/**
	 * 取得yyyy-MM-dd HH:mm:ss格式的当前时间
	 * @return
	 */
	public static String yyyyMMddHHmmss() {
		return yyyyMMddHHmmss(new Date());
	}
	
	/**
	 * 取得yyyy-MM-dd HH:mm:ss格式的当前时间
	 * @return
	 */
	public static String yyyyMMddHHmmss(long timestamp) {
		return yyyyMMddHHmmss(new Date(timestamp));
	}

	/**
	 * 取得yyyy-MM-dd HH:mm:ss格式的时间
	 * @return
	 */
	public static String yyyyMMddHHmmss(Date date) {
		return dateFormat4yyyyMMddHHmmss().format(date);
	}

	/**
	 * 将yyyy-MM-dd HH:mm:ss转换为Date
	 * @param formatdate
	 * @return
	 */
	public static Date yyyyMMddHHmmss(String formatdate) {
		try 
		{
			return dateFormat4yyyyMMddHHmmss().parse(formatdate);
		} catch (Exception e){throw new IllegalStateException("parse["+formatdate+"] with ex.", e);}
	}
	
	public static Date yyyyMMdd(String formatdate) {
		try 
		{
			return dateFormat4yyyyMMdd().parse(formatdate);
		} catch (Exception e){throw new IllegalStateException("parse["+formatdate+"] with ex.", e);}
	}
	
	public static long getMilliseconds(String unixtime) {
		return Long.valueOf(unixtime)*1000 ;
	}
	
	public static Date setUnixTime(Date date, String unixtime) {
		if(date==null) date = new Date() ;
		date.setTime(getMilliseconds(unixtime)) ;
		return date ;
	}
	
	public static String format(DateFormat format, Date date) {
		try{
			return format.format(date) ;
		} catch (Exception e){throw new IllegalArgumentException("format["+date+"] with ex.", e);}
	}
	
	/**
	 * yyyyMMddHHmmss
	 * @return
	 */
	public static SimpleDateFormat dateFormatyyyyMMddHHmmss() {
		return new SimpleDateFormat("yyyyMMddHHmmss") ;
	}
	
	/**
	 * yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static SimpleDateFormat dateFormat4yyyyMMddHHmmss() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") ;
	}
	
	
	/**
	 * yyyy年MM月dd日  HH时mm分ss秒
	 * @return
	 */
	public static SimpleDateFormat dateFormat2yyyyMMddHHmmss() {
		return new SimpleDateFormat("yyyy年MM月dd日  HH时mm分ss秒") ;
	}
	
	/**
	 * @return yyyy-MM-dd格式
	 */
	public static SimpleDateFormat dateFormat4yyyyMMdd() {
		return new SimpleDateFormat("yyyy-MM-dd") ;
	}
	
	
	/**
	 * @return yyyyMMdd格式
	 */
	public static SimpleDateFormat yyyyMMddFormatter() {
		return new SimpleDateFormat("yyyyMMdd") ;
	}
	
	/**
	 * @return yyyy年MM月dd日格式
	 */
	public static DateFormat yyyyMMddChianiseFormatter() {
		return new SimpleDateFormat("yyyy年MM月dd日") ;
	}
	
	public static String yyyyMMdd(Date date) {
		return dateFormat4yyyyMMdd().format(date) ;
	}
	
	public static String yyyyMMddHHMMSS(Date date){
		return dateFormat2yyyyMMddHHmmss().format(date);
	}
	
	public static Date newDateByUnixTimestamp(long unixTimestamp) {
		return unixTimestamp==0 ? null : new Date(unixTimestamp*1000) ;
	}
	
	public static long getUnixTimestamp(Date date) {
		return date == null ? 0 : date.getTime()/1000 ;
	}
	
	public static long unixtimestampOfNow() {
		return System.currentTimeMillis()/1000 ;
	}
	
	public static String stringOfUnixtimestampNow() {
		return String.valueOf(System.currentTimeMillis()/1000) ;
	}
	
	public static String stringOfUnixtimestamp(Date date) {
		return String.valueOf(date.getTime()/1000) ;
	}
	
	public static String yyyyMMddChianise(Date date) {
		return yyyyMMddChianiseFormatter().format(date) ;
	}
	
	public static Date getDateZero(Date date) {
		Calendar c = Calendar.getInstance() ;
		if(date!=null) c.setTime(date) ;
		setCalendarToZero(c) ;
		return c.getTime() ;		
	}
	
	/**
	 * 获取今天的截至时间
	 * @return
	 */
	public static Date getTodayLimit() {
		return getDateEndTime(new Date()) ;
	}
	
	/**
	 * 获取某一天的开始时间
	 * @param date
	 * @return
	 */
	public static Date getDateStartTime(Date date) {
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		setCalendarToZero(c) ;
		return c.getTime() ;
	}
	
	public static void setCalendarToZero(Calendar c) {
		c.set(Calendar.HOUR_OF_DAY, 0) ;
		c.set(Calendar.MINUTE, 0) ;
		c.set(Calendar.SECOND, 0) ;
		c.set(Calendar.MILLISECOND, 0) ;
	}
	
	/**
	 * 获取某一天的截至时间
	 * @param date
	 * @return
	 */
	public static Date getDateEndTime(Date date) {
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(Calendar.DAY_OF_MONTH, 1) ;
		setCalendarToZero(c) ;
		return c.getTime() ;
	}
	
	
	public static Date getTodayZero() {
		return getDateZero(null) ;
	}
	
	public static Date parse(java.sql.Timestamp timestamp) {
		if(timestamp==null) return null ;
		return new Date(timestamp.getTime()*1000) ;
	}
	
	/**
	 * 得到当月第一天开始时间
	 * @param now
	 * @return
	 */
	public static Date getMonthStartTime(Date date){
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		setCalendarToZero(c);
		c.set(Calendar.DAY_OF_MONTH, 1);
		return c.getTime() ;
	}
	
	public static Date getMonthEndTime(Date date){
		if(date==null) return null ;
		Date newDate = getMonthStartTime(date);
		Calendar c = Calendar.getInstance() ;
		c.setTime(newDate) ;
		setCalendarToZero(c);
		c.set(Calendar.MONTH,c.get(Calendar.MONTH)+1);
		return c.getTime() ;
	}
	/**
	 * 得到本周第一天开始时间
	 * @param now
	 * @return
	 */
	public static Date getWeekStartTime(Date date){
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		setCalendarToZero(c);
		c.set(Calendar.DAY_OF_WEEK, 1);
		return c.getTime() ;
	}
	
	/**
	 * 得到昨天开始时间
	 * @param now
	 * @return
	 */
	public static Date getYesterdayStartTime(Date date){
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		setCalendarToZero(c);
		c.add(Calendar.DAY_OF_MONTH, -1);
		return c.getTime() ;
	}
	
	/**
	 * 得到今天之前多少天的开始时间 — +value
	 * 或今天之后多少天的开始时间  -value
	 * @param date
	 * @return
	 */
	public static Date getDayOffStartTime(Date date,int value){
		
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		setCalendarToZero(c);
		c.add(Calendar.DAY_OF_MONTH,value);
		return c.getTime() ;
	}
	
	/**
	 * 得到几天前或几天后的今天时间
	 * @param date
	 * @param value
	 * @return
	 */
	public static Date getDayOffTime(Date date,int value){
		
		if(date==null) return null ;
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(Calendar.DAY_OF_MONTH,value);
		setCalendarToZero(c);
		return c.getTime() ;
	}
	
	public static Date getYearStartTime(){
		Calendar c = Calendar.getInstance() ;
		setCalendarToZero(c);
		c.set(Calendar.DAY_OF_YEAR, 1);
		return c.getTime() ;
	}
	/**
	 * 获得指定日期的下一天时间
	 * @param date
	 * @return
	 */
	public static Date getNextDay(Date date) {
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, +1);
		return calendar.getTime();
	}
	
	/**
	 * 获得指定日期前一天时间
	 * @param date
	 * @return
	 */
	public static Date getBeforeDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		return calendar.getTime();
	}
	
	/**
	 * 获得当前时间 value小时后的时间
	 * @param value
	 * @return
	 */
	public static int getDiffSecond(int value){
		Calendar c = Calendar.getInstance();
		Date date = new Date();
		c.setTime(date);
	    c.add(Calendar.HOUR, value);
	    date=c.getTime();
	    int second = (int)(getUnixTimestamp(date) - getUnixTimestamp(new Date()));
	    return second;
	}
	
	/**
	 * 根据秒获得时间差
	 * @param second
	 * @return
	 */
	 @SuppressWarnings("unused")
	public static String getTimeDiff(int second) {
		int h = 0, d = 0, s = 0;
		int temp = second % 3600;
		if (second > 3600) {
			h = second / 3600;
			if (temp != 0) {
				if (temp > 60) {
					d = temp / 60;
					if (temp % 60 != 0) {
						s = temp % 60;
					}
				} else {
					s = temp;
				}
			}
		} else {
			d = second / 60;
			if (second % 60 != 0) {
				s = second % 60;
			}
		}
		return h + "小时" + d + "分钟";
	}
	
    public static Date getNextDay()
    {
        Calendar cal = Calendar.getInstance();
        Date date = new Date();
        cal.setTime(date);
        cal.add(5, 1);
        return cal.getTime();
    }
    
    public static Date getNextDay(Date date,int day){
    	Calendar cal = Calendar.getInstance();
    	cal.setTime(date);
    	cal.add(5, day);
        return cal.getTime();
    }
    
    public static Date getNextMinute(Date date, int minute) {
		return new Date(date.getTime() + minute * 60L * 1000L);
	}

    public static Date getNextMonthFirstDay()
    {
        Calendar cal = Calendar.getInstance();
        Date date = new Date();
        cal.setTime(date);
        cal.add(2, 1);
        cal.set(5, 1);
        return cal.getTime();
    }

    public static String getCurrentStringDate(String strFormat)
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat(strFormat);
        return format.format(cal.getTime());
    }

    public static Date getDateByStr(String dateStr)
    {
        if(dateStr == null || dateStr.equals(""))
            return null;
        Date d = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
			d = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
        return d;
    }

    public static Date getDateByFormatStr(String dateStr, String format)
    {
        if(dateStr == null || dateStr.equals("") || format == null || format.equals(""))
            return null;
        Date d = null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
			d = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
        return d;
    }

	/**
	 * 获得当前月及当前月前11个月的数据
	 * 
	 * @return map
	 */
	public static List<Map<String,String>> getLast12Month() {
		LinkedHashMap<String, String> retMap ; 
		List<Map<String,String>> retList = new ArrayList<Map<String,String>>();
		Calendar now = Calendar.getInstance(TimeZone.getDefault());
		String DATE_FORMAT = "yyyyMM";
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(DATE_FORMAT);
		String yearOfMonth = null;
		String year = null;
		String month = null;
		now.add(Calendar.MONTH, 1);
		for (int i = 0; i < 12; i++) {
			retMap = new LinkedHashMap<String, String>();
			now.add(Calendar.MONTH, -1);
			yearOfMonth = sdf.format(now.getTime());
			year = yearOfMonth.substring(0, 4);
			month = yearOfMonth.substring(4, 6);
			retMap.put("encodeKey", yearOfMonth);
			retMap.put("encodeValue", year + "年" + month + "月");
			retList.add(retMap);
		}
		return retList;
	}

	/**
	 * 获取当前季度和之前的三个季度
	 * 
	 * @return map
	 */
	public static List<Map<String,String>> getLast4Quarter() {
		LinkedHashMap<String, String> retMap;
		List<Map<String,String>> retList = new ArrayList<Map<String,String>>();
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
		if (month <= 3) {
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "1");
			retMap.put("encodeValue", year + "年第一季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "4");
			retMap.put("encodeValue", year - 1 + "年第四季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "3");
			retMap.put("encodeValue", year - 1 + "年第三季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "2");
			retMap.put("encodeValue", year - 1 + "年第二季度");
			retList.add(retMap);
		} else if (month > 3 && month <= 6) {
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "2");
			retMap.put("encodeValue", year + "年第二季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "1");
			retMap.put("encodeValue", year + "年第一季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "4");
			retMap.put("encodeValue", year - 1 + "年第四季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "3");
			retMap.put("encodeValue", year - 1 + "年第三季度");
			retList.add(retMap);
		} else if (month > 6 && month <= 9) {
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "3");
			retMap.put("encodeValue", year + "年第三季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "2");
			retMap.put("encodeValue", year + "年第二季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "1");
			retMap.put("encodeValue", year + "年第一季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year - 1 + "4");
			retMap.put("encodeValue", year - 1 + "年第四季度");
			retList.add(retMap);
		} else {
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "4");
			retMap.put("encodeValue", year + "年第四季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "3");
			retMap.put("encodeValue", year + "年第三季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "2");
			retMap.put("encodeValue", year + "年第二季度");
			retList.add(retMap);
			retMap = new LinkedHashMap<String, String>();
			retMap.put("encodeKey", year + "1");
			retMap.put("encodeValue", year + "年第一季度");
			retList.add(retMap);		
		}
		return retList;
	}
	
    public static void main(String[] args){
    	//Calendar   cal   =   Calendar.getInstance(); 
    	//int   year   =   cal.get(Calendar.YEAR); 
    	//int   month   =   cal.get(Calendar.MONTH)   +   1; 
       	//int   day   =   cal.get(Calendar.DATE); 
    	//System.out.println("year="+year);
    	//System.out.println("month="+month);
    	//System.out.println("day="+day);
    	
    	//Date date =  getNextDay(new Date(),-365);
    	//String dateStr= dateToDateString(date,TIMEF_FORMAT);
    	//System.out.println("getNextDay(new Date(),-1)= "+date);
    	//System.out.println("getNextDay(new Date(),-1)= "+dateStr);
    	
//    	Date date2 =  getNextMinute(new Date(),-60);
//    	String dateStr2= dateToDateString(date2,TIMEF_FORMAT);
//    	System.out.println("getNextMinute(new Date(),-60)= "+date2);
//    	System.out.println("getNextMinute(new Date(),-60)= "+dateStr2);
    	
    	//String dateStr2= dateToDateString(new Date(),TIMEF_FORMAT);
    	//System.out.println(dateStr2);
    	//System.out.println(dateStr2.substring(11,16));
    	
    	//System.out.println(""+dateToDateString(new Date(),DATE_FORMAT));
    	//System.out.println(""+dateToDateString(new Date(),DATE_FORMAT)+" 00:00:00");
    	
    	//String dateTime = DateUtil.dateToDateString(new Date(),DateUtil.TIMEF_FORMAT);
    	//String newDateTime = dateTime.substring(0, 11)+"00:00:00";
    	//Date date = DateUtil.getDateByFormatStr(newDateTime,DateUtil.TIMEF_FORMAT);
    	
    	//System.out.println("dateTime="+dateTime);
    	//System.out.println("newDateTime="+newDateTime);
    	//System.out.println("date="+date);
    	
    	//Date datex = KeyNames.getBalanceUpdateTimeExpireTimeEnd();
    	//System.out.println(datex);
    	System.out.println(DateUtil.getDateByFormatStr("2015-12-20 13:12:12", DateUtil.TIMEF_FORMAT));
    }
}