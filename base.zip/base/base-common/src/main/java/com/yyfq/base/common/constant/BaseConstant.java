package com.yyfq.base.common.constant;

public class BaseConstant {

}
