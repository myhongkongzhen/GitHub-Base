package com.yyfq.base.common.util;

import java.io.IOException;
import java.net.URLDecoder;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @author ZZ
 * @Date 2015年12月15日
 */
public class DESUtil {
	/**
     * DES密钥
     */
    private static String appRecordDesKey;
	public static void setAppRecordDesKey(String appRecordDesKey) {
		DESUtil.appRecordDesKey = appRecordDesKey;
	}

	private final static String DES = "DES";

	public static void main(String[] args) throws Exception {
//		String iosData = "JW KIGoRDeBzPwZFK8wuZl6RWZlCYDbKDJJV6ssRCMaP2EQRCqTpkuoyv1c1uT7hh/WAjfroDrnqYseX/X7P2kMH/1TAs1RoGb8k9HbPbrFXqISb5fzxvoTE6j ccwkG4XkNdkDK0vbAS2OVhCQX23TKTy EERjmYzxGKNuoHaQuOsaUToSROKEUIV3V9Kv5zpfyxq/DMsFEK3z0rN YiI9VPHsuO5wYE7 FyCWOPaUny59eEVqPfX2YIZUeG77ZyAPF2/AYPKPuNQwyEJktm8knuuN2rDDC4 irqBSf4pV22stL40pXvNYqTzaKh3ZGA0CcLF8V4QE6Ruv9mNm 7FJOMxuQa4O9N7WV21/2gWqw3FBQtGJ3qnsa0QE9LV/3bJcFHSunACC49dpIatbzRzfuVNWk31kiX5peP4Ku3ZRPU1YIw5Qefzmm2Hm6tqvPv1TTUNgnyal3jyky0SBqyPV31HMME/7wrckInqSSZBtjcQGpEXFuWP/K7SeqSnZ/EDEe4IXxWRzItfj/bU5hNbvZw1h0evBvDFlm7t6DqF6NBoseOOKK s0uCjMasJjfHTlQuwmVfiLuaZcTSvGMGAVZoi1kiilz8quRQM6Wu0pzPwZFK8wuZlF0AcSXHte99Wr NgOlpeOP2EQRCqTpkuoyv1c1uT7hh/WAjfroDrnqYseX/X7P2kMH/1TAs1RoGb8k9HbPbrFXqISb5fzxvmGsIIcKyXrsbd8ht4Z5LWLAS2OVhCQX23TKTy EERjmYzxGKNuoHaTmS9W5 SIeJUoH7ZeT6df/zpfyxq/DMsFEK3z0rN YiI9VPHsuO5wYE7 FyCWOPaUny59eEVqPfX2YIZUeG77ZyAPF2/AYPKPuNQwyEJktm/qgOcDrHFZKz/y8LHfVEMxPamC7MLMKDg==";
//		String androidData = "";
		
		String data = "OFi%2BFDMriHPgy28f%2FNHJHcBow6myUnpvmRajJH0pJZQEtpUYgIKtrUrHYxy2wGF08fazJObDlYwq%0Afr%2BiDFXeu0G2ItNukPnlIGQ8KSMoW16fDvznewOzPiSVQmA6u%2BD8vlUzjUimP7EK%2F0aqyB%2B%2BSSwU%0A5CQAMh6B%2FKl20vjRuIEzBl7qDgaAxLwUjX7PZ%2Fnfzpfyxq%2FDMsFfq%2BYnMKYqC8e%2FFiiG4yC5EDEe%0A4IXxWRzItfj%2FbU5hNbvZw1h0evBv7mmXE0rxjBgFWaItZIopc73xAvMx4rqNsG18JHlHJIDhVLPt%0A3Vj2Foy0OFqapMomuAwdPx9IWMIijJwX0KEi9%2Fb9YXhasJu9bonl8ZgfRgMWox3xiZMXi0PtEpsV%0A9bj1UYFZB9A9eNQfnPFTTFZtqwr%2FRqrIH75JLBTkJAAyHoHSLGM7c1MX8bKcyEPYLMD5Y3EBqRFx%0Ablgc1zCRt%2Bnjn%2BW7KyTLS7wYRCt89KzfmIiPVTx7LjucGBO%2Fhcgljj2lqFwJrxCPYIvRAzgMiKxt%0Aa8RZjp3x8pXo39hjKoTtHcRcQ56geILT8hSUdzBvXt5MJ9RsXPNV%2B4sifis%2BZ3a2UwS2lRiAgq2t%0ASsdjHLbAYXTx9rMk5sOVjCp%2Bv6IMVd67QbYi026Q%2BeUgZDwpIyhbXvqJlkEgh18Wpj%2BlTlsiVlHp%0APscyRkDmd%2FPvMGvtHMbgZsrIJuYbFpM6y5ArXMCfryKMnBfQoSL39v1heFqwm71uieXxmB9GAxaj%0AHfGJkxeLQ%2B0SmxX1uPVRgVkH0D141B%2Bc8VNMVm2rCv9GqsgfvkltLv9xAJRweQ%3D%3D%0A";
		String aa = URLDecoder.decode(data, "utf-8");
//		System.out.println(aa);
//		System.out.println("");
//		String bb = "OFi+FDMriHPgy28f/NHJHcBow6myUnpvmRajJH0pJZQEtpUYgIKtrUrHYxy2wGF08fazJObDlYwqfr+iDFXeu0G2ItNukPnlIGQ8KSMoW16fDvznewOzPiSVQmA6u+D8vlUzjUimP7EK/0aqyB++SSwU5CQAMh6B/Kl20vjRuIEzBl7qDgaAxLwUjX7PZ/nfzpfyxq/DMsFfq+YnMKYqC8e/FiiG4yC5EDEe4IXxWRzItfj/bU5hNbvZw1h0evBv7mmXE0rxjBgFWaItZIopc73xAvMx4rqNsG18JHlHJIDhVLPt3Vj2Foy0OFqapMomuAwdPx9IWMIijJwX0KEi9/b9YXhasJu9bonl8ZgfRgMWox3xiZMXi0PtEpsV9bj1UYFZB9A9eNQfnPFTTFZtqwr/RqrIH75JLBTkJAAyHoHSLGM7c1MX8bKcyEPYLMD5Y3EBqRFxblgc1zCRt+njn+W7KyTLS7wYRCt89KzfmIiPVTx7LjucGBO/hcgljj2lqFwJrxCPYIvRAzgMiKxta8RZjp3x8pXo39hjKoTtHcRcQ56geILT8hSUdzBvXt5MJ9RsXPNV+4sifis+Z3a2UwS2lRiAgq2tSsdjHLbAYXTx9rMk5sOVjCp+v6IMVd67QbYi026Q+eUgZDwpIyhbXvqJlkEgh18Wpj+lTlsiVlHpPscyRkDmd/PvMGvtHMbgZsrIJuYbFpM6y5ArXMCfryKMnBfQoSL39v1heFqwm71uieXxmB9GAxajHfGJkxeLQ+0SmxX1uPVRgVkH0D141B+c8VNMVm2rCv9GqsgfvkltLv9xAJRweQ==";
		System.err.println(decrypt(aa));
	}

	
	/**
	 * Description 根据键值进行加密
	 * @param data
	 * @param key  加密键byte数组
	 * @throws Exception
	 */
	public static String encrypt(String data) throws Exception {
		byte[] bt = encrypt(data.getBytes(), appRecordDesKey.getBytes());
		String strs = new BASE64Encoder().encode(bt);
		return strs;
	}

	/**
	 * Description 根据键值进行解密
	 * @param key  加密键byte数组
	 */
	public static String decrypt(String data) throws IOException, Exception {
		if (data == null) return null;
		BASE64Decoder decoder = new BASE64Decoder();
		byte[] buf = decoder.decodeBuffer(data);
		byte[] bt = decrypt(buf, appRecordDesKey.getBytes());
		return new String(bt);
	}

	/**
	 * Description 根据键值进行加密
	 * @param key 加密键byte数组
	 * @throws Exception
	 */
	private static byte[] encrypt(byte[] data, byte[] key) throws Exception {
		// 生成一个可信任的随机数源
		SecureRandom sr = new SecureRandom();

		// 从原始密钥数据创建DESKeySpec对象
		DESKeySpec dks = new DESKeySpec(key);

		// 创建一个密钥工厂，然后用它把DESKeySpec转换成SecretKey对象
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey securekey = keyFactory.generateSecret(dks);

		// Cipher对象实际完成加密操作
		Cipher cipher = Cipher.getInstance(DES);

		// 用密钥初始化Cipher对象
		cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
		return cipher.doFinal(data);
	}

	/**
	 * Description 根据键值进行解密
	 * @param key 加密键byte数组
	 * @throws Exception
	 */
	private static byte[] decrypt(byte[] data, byte[] key) throws Exception {
		// 生成一个可信任的随机数源
		SecureRandom sr = new SecureRandom();

		// 从原始密钥数据创建DESKeySpec对象
		DESKeySpec dks = new DESKeySpec(key);

		// 创建一个密钥工厂，然后用它把DESKeySpec转换成SecretKey对象
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey securekey = keyFactory.generateSecret(dks);

		// Cipher对象实际完成解密操作
		Cipher cipher = Cipher.getInstance(DES);

		// 用密钥初始化Cipher对象
		cipher.init(Cipher.DECRYPT_MODE, securekey, sr);

		return cipher.doFinal(data);
	}
}
