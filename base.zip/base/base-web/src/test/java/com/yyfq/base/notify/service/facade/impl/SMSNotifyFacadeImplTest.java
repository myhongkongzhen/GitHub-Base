/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.service.facade.impl;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.SMSParam;
import com.yyfq.base.notify.facade.NotifyFacade;
import net.sourceforge.groboutils.junit.v1.MultiThreadedTestRunner;
import net.sourceforge.groboutils.junit.v1.TestRunnable;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collection;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.service.facade.impl.SMSNotifyFacadeImplTest
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 12:02
 *   LastChange: 2016-1-18 12:02
 *      History:
 * </pre>
 **************************************************************************/
@RunWith( SpringJUnit4ClassRunner.class )
@ContextConfiguration( locations = { "classpath:spring/spring.xml" } )
public class SMSNotifyFacadeImplTest
{
    private static final Logger logger = LoggerFactory.getLogger( SMSNotifyFacadeImplTest.class );
    private NotifyFacade notifyFacade;
    int completeThread = 0;
    
    @Test
    public void testSendSingleSMS() throws Exception
    {
        try
        {
            SMSParam param = new SMSParam();
//            param.setSendTime( new Date() );
//            param.setNotifysysuuid( NotifyUtil.INSTANCE.getsysuuid() );
            param.setBussdepartment( "fengkong" );
            param.setMobile( "15098648522" );
            param.setSource( "app" );
            param.setType( "1" );
            param.setBussuid( "zhangsan" );

            Result result = notifyFacade.sendSingleMsg( param );
            logger.info( "===={}==", JSONObject.toJSONString( result ));
        }
        catch ( Exception e )
        {
            logger.error( "error:{}.", e.getMessage(), e );
        }
    }

    /**
     * 13670052057
     15986801501
     18666821665
     13715116671
     18627031525
     * @throws Exception
     */

    @Test
    public void testSendMultSMS() throws Exception
    {

        TestRunnable runner = new TestRunnable()
        {
            @Override
            public void runTest() throws Throwable
            {

                try
                {
                    Collection< SMSParam > list  = new ArrayList<>();
                    SMSParam               param = new SMSParam();
                    param.setBussdepartment( "fengkong" );
                    param.setMobile( "13715116671" );
                    param.setSource( "app" );
                    param.setType( "1" );
                    list.add( param );

                    param = new SMSParam();
                    param.setBussdepartment( "fengkong" );
                    param.setMobile( "" );
                    param.setSource( "html5" );
                    param.setType( "2" );
                    list.add( param );
                    logger.info( "===>>>{}",JSONObject.toJSONString( notifyFacade.sendMultMsg( list ) ) );
                }
                catch ( Exception e )
                {
                    logger.error( "error:{}.", e.getMessage(), e );
                }

                completeThread += 1;
            }
        };

        int            runnerCount = 1; // 开启100线程
        TestRunnable[] trs         = new TestRunnable[ runnerCount ];
        for ( int i = 0; i < runnerCount; i++ )
        {
            trs[ i ] = runner;
        }

        MultiThreadedTestRunner mttr = new MultiThreadedTestRunner( trs );
        try
        {
            mttr.runTestRunnables();
        }
        catch ( Throwable e )
        {
            e.printStackTrace();
        }

        logger.info( ">>##########################>>>>>>>>>completeThread:{}" , completeThread );

//       System.in.read();
    }

    public NotifyFacade getNotifyFacade()
    {
        return notifyFacade;
    }

    @Resource( name = "smsNotifyFacade" )
    public void setNotifyFacade( NotifyFacade notifyFacade )
    {
        this.notifyFacade = notifyFacade;
    }
}