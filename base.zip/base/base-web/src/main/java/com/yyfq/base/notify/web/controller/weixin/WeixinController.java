package com.yyfq.base.notify.web.controller.weixin;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.weixin.AccessToken;
import com.yyfq.base.notify.common.dto.weixin.WeixinBaseInfo;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplateParam;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.common.util.weixin.MessageUtil;
import com.yyfq.base.notify.common.util.weixin.WeixinUtil;
import com.yyfq.base.notify.facade.weixin.WeixinNotifyFacade;

/**
 * @ClassName: WeixinController
 * @Description: 微信接口
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@Controller
@RequestMapping("/weixin")
public class WeixinController {

	private static final Logger logger = LoggerFactory
			.getLogger(WeixinController.class);

	@Resource(name="weixinNotifyFacade")
	private WeixinNotifyFacade<WeixinTemplateParam> weixinNotifyFacade;
	
	//微信文本信息，回复信息
	@Value("#{weixinParam['replyContent_text']}")
	private String replyContent;
	
	//有用登录url
	@Value("#{weixinParam['yyfq_login_url']}")
	private String loginUrl;
	
	//有用注册url
	@Value("#{weixinParam['yyfq_register_url']}")
	private String registerUrl;
	
	//微信关注，回复信息
	@Value("#{weixinParam['weixin_sub']}")
	private String weixin_sub;
	
	//微信已关注推送
	@Value("#{weixinParam['weixin_already_sub']}")
	private String weixin_already_sub;
	
	/**
	 * 微信服务器有效性验证
	 * @param req
	 * @param resp
	 * @return void
	 */
	@RequestMapping(value = "/weixinMljr", method = RequestMethod.GET)
	public void weixinMljrDoGet(HttpServletRequest req, HttpServletResponse resp) {
		String signature = req.getParameter("signature");
		String timestamp = req.getParameter("timestamp");
		String nonce = req.getParameter("nonce");
		String echostr = req.getParameter("echostr");

		PrintWriter out = null;
		try {
			logger.info("进入微信接口服务器有效性验证....{}.", signature, timestamp, nonce,
					echostr);
			out = resp.getWriter();
			if (weixinNotifyFacade.checkSignature(signature, timestamp, nonce)) {
				out.print(echostr);
			}
		} catch (Exception e) {
			logger.error("微信接口服务器有效性验证异常：{}.", e.getMessage(), e);
		} finally {
			out.close();
		}
	}

	/**
	 * 微信 关注公众号，取消关注，图文消息...请求处理
	 * @param req
	 * @param resp
	 * @return void
	 */
	@RequestMapping(value = "/weixinMljr", method = RequestMethod.POST)
	public void weixinMljrDoPost(HttpServletRequest req,
			HttpServletResponse resp) {
		PrintWriter out = null;
		try {
			logger.info("进入微信接口Post请求");
			req.setCharacterEncoding("UTF-8");
			resp.setCharacterEncoding("UTF-8");
			out = resp.getWriter();
			// 请求信息获取xml参数
			Map<String, String> map = MessageUtil.xmlToMap(req);
			String message = null;
			if (null != map && map.size() != 0) {
				String fromUserName = map.get("FromUserName");// 这就是用户的一个OpenId
				String toUserName = map.get("ToUserName");
				String msgType = map.get("MsgType");
				// 判断参数与接收参数
				if (StringUtils.isBlank(fromUserName)
						|| StringUtils.isBlank(toUserName)
						|| StringUtils.isBlank(msgType)) {
					logger.info("微信请求参数为空，WeixinController.weixinMljrDoPost");
					message = "请求参数为空";
				} else {
					// 将微信数据插入数据库
					weixinNotifyFacade.insertWeixinUser(fromUserName);

					// 判断msgType
					if (msgType.equals(MessageUtil.MESSAGE_TEXT)) {//文本
						message = MessageUtil.initText(toUserName,fromUserName, replyContent);
					} else if (msgType.equals(MessageUtil.MESSAGE_EVNET)) {// 事件:
						String eventType = map.get("Event");
						if(eventType.equals(MessageUtil.MESSAGE_SUBSCRIBE)) {//关注
							message = subscribe(req, map, fromUserName,toUserName);
						} else if(eventType.equals(MessageUtil.MESSAGE_SCAN)){//用户已关注时的事件推送
							message = alreadySub(req,map, fromUserName, toUserName);
						} else if(eventType.equals(MessageUtil.MESSAGE_UNSUBSCRIBE)) {//取消关注
							message = unSubscribe(req,map, fromUserName, toUserName);
						} else {
							message = MessageUtil.initText(toUserName, fromUserName, weixin_already_sub);
						}
					}
				}
			}
			logger.info("post请求输出数据：{}", message);
			out.print(message);
		} catch (WebException e) {
			String exceptionJson = BizException.webExceptionJson(e);
			logger.info(
					"微信接口WeixinController.weixinMljrDoPost请求WebException异常：{}.",
					exceptionJson);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("微信接口系统异常：{}.", e.getMessage(), e);
		} finally {
			out.close();
		}
	}

	/**
	 * 用户取消关注公众号
	 * @param req
	 * @param map
	 * @param fromUserName
	 * @param toUserName
	 * @return String
	 */
	private String unSubscribe(HttpServletRequest req, Map<String, String> map,
			String fromUserName, String toUserName) {
		String message = null;
		try {
			message = MessageUtil.initText(toUserName, fromUserName, weixin_already_sub);
			Result<Integer> updateSubStatus = weixinNotifyFacade.updateSubStatus(fromUserName,0);
			logger.info("update weixinUser subStatus result is 【"+updateSubStatus +"】" );
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("weixinController alreadySun find error .{}",e);
		}
		return message;
	}

	/**
	 * 微信已关注的事件推送
	 * @param req
	 * @param map
	 * @param fromUserName
	 * @param toUserName
	 * @return String
	 */
	private String alreadySub(HttpServletRequest req,Map<String, String> map, String fromUserName,
			String toUserName) {
		String message = null;
		try {
			//OAUTH2.0授权，获取code值
//			String url = WeixinUtil.OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(WeixinUtil.YYFQ_REGISTER_URL, "utf-8")).replace("APPID", WeixinUtil.APPID_TEST).replace("SCOPE", "snsapi_base");
			message = MessageUtil.initText(toUserName, fromUserName, weixin_already_sub);
			String scene = map.get("EventKey");
			Result<Integer> updateScene = weixinNotifyFacade.updateWeixinScene(Integer.valueOf(scene),fromUserName);
			if(updateScene.getData() == 1) {
				logger.info("weixinController.doPost update weixinUser scene success .{}",updateScene);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("weixinController alreadySun find error .{}",e);
		}
		return message;
	}

	/**
	 * 关注公众号
	 * @param req
	 * @param map
	 * @param fromUserName
	 * @param toUserName
	 * @return String
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 * @return String
	 * @throws Exception
	 */
	private String subscribe(HttpServletRequest req, Map<String, String> map,
			String fromUserName, String toUserName)
			throws ClientProtocolException, IOException,
			UnsupportedEncodingException {
		String message;
		//获取微信票据
		AccessToken token = WeixinUtil.getAccessToken(req);
		logger.info("weixinController get token success .{}",token.getToken());
		//通过票据获取用户基本信息
		WeixinBaseInfo wubi = WeixinUtil.getUserBaseInfo(token.getToken(), fromUserName);
		logger.info("weixinController get weixinUserBase success .{}",JSONObject.toJSONString(wubi));
		if(null != wubi) {
			Result<Integer> upWxUserResult = weixinNotifyFacade.updateWeixinUser(fromUserName, wubi.getNickname(), wubi.getSex(), wubi.getCity(), wubi.getCountry(), wubi.getProvince(), wubi.getHeadimgurl(),1);
			if(upWxUserResult.getData() == 1) {
				logger.info("update weixinUser success by WeixinController.doPost");
			}
		}
		//OAUTH2.0授权，获取code值
		String url = WeixinUtil.OAUTH_URL.replace("REDIRECT_URI", URLEncoder.encode(loginUrl, "utf-8")).replace("APPID", WeixinUtil.APPID_TEST).replace("SCOPE", "snsapi_base");
		String weixinCode = weixin_sub.replace("login_url", url);
		System.out.println("weixin scope is :"+weixinCode);
		message = MessageUtil.initText(toUserName, fromUserName, weixin_sub.replace("login_url", url));
		
		//获取微信用户二维码场景值
		String eventKey = map.get("EventKey");
		if(StringUtils.isNotEmpty(eventKey)) {
			//String ticket = map.get("Ticket");ticket获取二维码ticket值，暂时不用
			int scene = Integer.parseInt(eventKey.split("_")[1]);
			Result<Integer> updateScene = weixinNotifyFacade.updateWeixinScene(Integer.valueOf(scene),fromUserName);
			if(updateScene.getData() == 1) {
				logger.info("weixinController.doPost update weixinUser scene success .{}",updateScene);
			}
		}
		return message;
	}
	
}
