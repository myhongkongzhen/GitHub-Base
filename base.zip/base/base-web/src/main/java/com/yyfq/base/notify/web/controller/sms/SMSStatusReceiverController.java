/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.web.controller.sms;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.facade.status.SMSStatusFacade;
import com.yyfq.base.notify.common.exception.WebException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.web.controller.sms.SMSStatusReceiverController
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-18 21:17
 *   LastChange: 2016-1-18 21:17
 *      History:
 * </pre>
 **************************************************************************/
@Controller
@RequestMapping( value = "/sms" )
public class SMSStatusReceiverController
{
    private static final Logger logger = LoggerFactory.getLogger( SMSStatusReceiverController.class );
    private SMSStatusFacade    smsStatusFacade;
    private ApplicationContext applicationContext;

    /**
     * http://103.3.120.3:8113/notify/sms/gd/status?args=XXXX 用途：服务通知平台测试
     * http://localhost:6666/notify/sms/gd/status?args=2,4354353465454,0,N013359160114111816,20121019164458,951234;%202,15193792747,0,N018957160114151024,20121019164458,%20951234
     *
     * @param args
     *
     *
     * @return
     */
    @RequestMapping( value = "/gd/{args}", produces = "text/plain;charset=UTF-8" )
    @ResponseBody
    public String gdchannel( String args )
    {
        try
        {
            logger.info( "接收到国都的状态报告数据为(原始)：{}.", args );

            if ( null == args || StringUtils.isBlank( StringUtils.trimToEmpty( args ) ) )
            {
                if ( StringUtils.isBlank( StringUtils.trimToEmpty( args ) ) )
                {
                    throw WebException.WEB_REQ_ARGS_NULL;
                }
            }

            // -- 2016-1-18 21:20:22 業務處理
            smsStatusFacade = ( SMSStatusFacade ) applicationContext.getBean( "gdSMSStatusFacade" );
            smsStatusFacade.parseResult( args );

            return JSONObject.toJSONString( new Result< String >( args ) );
        }
        catch ( BizException e )
        {
            String exceptionJson = WebException.webExceptionJson( e, args );
            logger.error( "接收到国都短信状态报告业务异常：{}.", exceptionJson );
            return exceptionJson;
        }
        catch ( Exception e )
        {
            logger.error( "接收到国都短信状态报告系統异常：{}.", e.getMessage(), e );
            return WebException.webExceptionJson( BizException.SYSTEM_EXCEPTION, args );
        }
    }


    /**
     * http://103.3.120.3:8113/notify/sms/ym/status?reportXml=XXXX 用途：服务通知平台测试
     * http://localhost:6666/notify/sms/ym/status?reportXml=%3C%3Fxml+version%3D%221.0%22+encoding%3D%22UTF-8%22%3F%3E%3CreportList%3E%3Creport%3E%3CseqId%3E3456%3C%2FseqId%3E%3CreportStatus%3E0%3C%2FreportStatus%3E%3Cmobile%3E15010359299%3C%2Fmobile%3E%3CerrorCode%3Edeliver%3C%2FerrorCode%3E%3CsubmitDate%3E20100109152333%3C%2FsubmitDate%3E%3CreceiveDate%3E20100109152339%3C%2FreceiveDate%3E%3C%2Freport%3E%3C%2FreportList%3E
     *
     * @param reportXml
     *
     * @return
     */
    @RequestMapping( value = "/ym/{reportXml}", produces = "text/plain;charset=UTF-8" )
    @ResponseBody
    public String ymchannel( String reportXml )
    {
        try
        {
            logger.info( "接收到亿美的状态报告数据为(原始)：{}.", reportXml );

            if ( null == reportXml || StringUtils.isBlank( StringUtils.trimToEmpty( reportXml ) ) )
            {
                if ( StringUtils.isBlank( StringUtils.trimToEmpty( reportXml ) ) )
                {
                    throw WebException.WEB_REQ_ARGS_NULL;
                }
            }

            // -- 2016-1-18 21:20:22 業務處理
            smsStatusFacade = ( SMSStatusFacade ) applicationContext.getBean( "ymSMSStatusFacade" );
            smsStatusFacade.parseResult( reportXml );

            return JSONObject.toJSONString( new Result< String >( reportXml ) );
        }
        catch ( BizException e )
        {
            String exceptionJson = WebException.webExceptionJson( e, reportXml );
            logger.error( "接收到亿美短信状态报告业务异常：{}.", exceptionJson );
            return exceptionJson;
        }
        catch ( Exception e )
        {
            logger.error( "接收到亿美短信状态报告系統异常：{}.", e.getMessage(), e );
            return WebException.webExceptionJson( BizException.SYSTEM_EXCEPTION, reportXml );
        }
    }

    public ApplicationContext getApplicationContext()
    {
        return applicationContext;
    }

    @Resource
    public void setApplicationContext( ApplicationContext applicationContext )
    {
        this.applicationContext = applicationContext;
    }
}
