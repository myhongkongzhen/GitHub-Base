/**********************************************************************************************************************
 * Copyright (c) 2016. Lorem ipsum dolor sit amet, consectetur adipiscing elit.                                       *
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.                        *
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.                                                   *
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.                     *
 * Vestibulum commodo. Ut rhoncus gravida arcu.                                                                       *
 **********************************************************************************************************************/

package com.yyfq.base.notify.web.controller.sms;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.SMSParam;
import com.yyfq.base.notify.common.exception.BizException;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.facade.NotifyFacade;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

/**************************************************************************
 * <pre>
 *     FileName: com.yyfq.base.notify.web.controller.sms.SMSSendController
 *         Desc:
 *       author: Z_Z.W - myhongkongzhen@gmail.com
 *      version: 2016-1-17 01:29
 *   LastChange: 2016-1-17 01:29
 *      History:
 * </pre>
 **************************************************************************/
@Controller
@RequestMapping( value = "/sms" )
public class SMSSendController
{
    private static final Logger logger = LoggerFactory.getLogger( SMSSendController.class );

    private NotifyFacade< SMSParam >        notifyFacade;

    /**
     * http://localhost:6666/notify/sms/single/send?msg={"mobile": "15098648522","bussdepartment":"風控服務組","bussuid": "usermsg","source": "html5","code": "","type": 500}
     * http://103.3.120.3:8113/notify/sms/single/send?msg={"mobile": "15098648522","bussdepartment":"風控服務組","bussuid": "usermsg","source": "html5","code": "","type": 500}
     *
     * @param msg
     *
     * @return
     */
    @RequestMapping( value = "/single/{msg}", produces = "text/plain;charset=UTF-8" )
    @ResponseBody
    public String single( String msg )
    {
        try
        {
            logger.info( "进入单发短信请求服务....{}.", msg );
            checkMsgNull( msg );

            SMSParam param = getSmsParam( msg );

            Result< SMSParam > result = notifyFacade.sendSingleMsg( param );
            if ( null == result || StringUtils.equalsIgnoreCase( result.getRet(), "1" ) )
            {
                return JSONObject.toJSONString(
                        ( null == result ? new Result< String >( "1", WebException.WEB_REQ_ARGS_FORMAT_ERROR.getMsg() )
                                         : result ) );
            }

            // TODO -- 2016-1-11 19:08:21 其他更細粒度校驗，後續完善
            // 例如：同一個手機號碼，來源，業務，都相同時，60s內不重新發送

            SMSParam resultData = result.getData();
            logger.info( "校验后的参数：{}.", JSONObject.toJSONString( resultData ) );

            return JSONObject.toJSONString( new Result< SMSParam >( resultData ) );
        }
        catch ( BizException e )
        {
            String exceptionJson = WebException.webExceptionJson( e, msg );
            logger.error( "单发短信请求出现业务异常：{}.", exceptionJson );
            return exceptionJson;
        }
        catch ( Exception e )
        {
            logger.error( "单发短信請求出现系統异常：{}.", e.getMessage(), e );
            return WebException.webExceptionJson( BizException.SYSTEM_EXCEPTION.newInstance(
                    StringUtils.join( BizException.SYSTEM_EXCEPTION.getMsg(), "==", e.getMessage() ) ), msg );
        }

    }

    /**
     * http://localhost:6666/notify/sms/batch/send?msg={"mobile": "Sample Konfabulator Widget","bussdepartment": main_window","bussuid": "","source": "","code": "","type": 500}
     *
     * @param msg
     *
     * @return
     */
    @RequestMapping( value = "/batch/{msg}", produces = "text/plain;charset=UTF-8" )
    @ResponseBody
    public String batch( String msg )
    {
        try
        {
            logger.info( "进入群发短信校验服务....{}.", msg );

            checkMsgNull( msg );
//
            List< SMSParam >   smsParams = getSmsParams( msg );
            Result< SMSParam > result    = notifyFacade.sendMultMsg( smsParams );
            return JSONObject.toJSONString( result );
        }
        catch ( BizException e )
        {
            String exceptionJson = WebException.webExceptionJson( e, msg );
            logger.error( "群发短信请求出现业务异常：{}.", exceptionJson );
            return exceptionJson;
        }
        catch ( Exception e )
        {
            logger.error( "群发短信請求出现系統异常：{}.", e.getMessage(), e );
            return WebException.webExceptionJson( BizException.SYSTEM_EXCEPTION, msg );
        }

    }


    private List< SMSParam > getSmsParams( String msg )
    {
        List< SMSParam > smsParams = null;

        try
        {
            msg = URLDecoder.decode( msg, "utf-8" );
        }
        catch ( UnsupportedEncodingException e )
        {
        }

        try
        {
            smsParams = JSONObject.parseArray( msg, SMSParam.class );
            if ( null == smsParams || smsParams.isEmpty() )
            {
                throw WebException.WEB_REQ_ARGS_NULL;
            }
        }
        catch ( Exception e )
        {
            throw WebException.WEB_REQ_ARGS_NULL;
        }
        return smsParams;
    }

    private void checkMsgNull( String msg )
    {
        checkNull( msg, WebException.WEB_REQ_ARGS_NULL );
    }

    private void checkNull( String string, WebException e )
    {
        if ( StringUtils.isBlank( StringUtils.trimToEmpty( string ) ) )
        {
            throw e;
        }

    }

    private SMSParam getSmsParam( String msg )
    {
        SMSParam param = null;

        try
        {
            msg = URLDecoder.decode( msg, "utf-8" );
        }
        catch ( UnsupportedEncodingException e )
        {
        }

        try
        {
            param = JSONObject.parseObject( msg, SMSParam.class );
            if ( null == param )
            {
                throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
            }
            return param;
        }
        catch ( Exception e )
        {
            throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
        }
    }

    public NotifyFacade getNotifyFacade()
    {
        return notifyFacade;
    }

    @Resource( name = "smsNotifyFacade" )
    public void setNotifyFacade( NotifyFacade notifyFacade )
    {
        this.notifyFacade = notifyFacade;
    }
}
