package com.yyfq.base.notify.web.controller.weixin;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.annotation.Resource;

import org.apache.http.client.ClientProtocolException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;
import com.yyfq.base.notify.common.dto.Result;
import com.yyfq.base.notify.common.dto.email.EmailDTO;
import com.yyfq.base.notify.common.dto.weixin.AccessToken;
import com.yyfq.base.notify.common.dto.weixin.WeixinTemplateParam;
import com.yyfq.base.notify.common.exception.WebException;
import com.yyfq.base.notify.common.util.weixin.WeixinUtil;
import com.yyfq.base.notify.facade.email.EmailFacade;
import com.yyfq.base.notify.facade.weixin.WeixinNotifyFacade;

/**
 * 微信测试
 * 
 * @ClassName: WeixinTest
 * @Description:
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@Controller
public class WeixinTest {

	@Resource(name = "weixinNotifyFacade")
	private WeixinNotifyFacade<WeixinTemplateParam> weixinService;

	@Resource(name = "emailFacade")
	private EmailFacade emailFacade;

	public static void main(String[] args) throws ClientProtocolException,
			IOException {

		String url = "https://baidu.com";
		String urlUt = URLEncoder.encode(url, "utf-8");
		System.out.println(urlUt);

		// 创建菜单
		AccessToken token = WeixinUtil.getAccessToken();

		System.out.println("票据：" + token.getToken());
		System.out.println("有效时间：" + token.getExpiresIn());

		String menu = JSONObject.toJSONString(WeixinUtil.initMenuTest());
		System.out.println(menu);
		String to = JSONObject.toJSONString(menu);
		System.out.println(to);

		int result = WeixinUtil.createMenu(token.getToken(), menu);

		if (result == 0) {
			System.out.println("菜单创建成功");
		} else {
			System.out.println("菜单创建失败:" + result);
		}

	}

	/**
	 * 发送模版
	 * 
	 * @return String
	 *         http://localhost:8099/notify/testSendMoBan?param={"mailTitle":"test",
	 *         													 "toEmail":"80281075@qq.com",
	 *         													 "content":"我是测试来的",
	 *         													 "bussName": "业务部门",
	 *         													 "type": 1,
	 *         													 "append_info": ""}
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	@RequestMapping(value = "testSendMoBan", method = RequestMethod.GET)
	public String testSendMoBan(Model model, String param) throws ClientProtocolException, IOException {
		// 这里测试微信发送模版
		WeixinTemplateParam wtp = new WeixinTemplateParam();
		wtp.setType(0);
		wtp.setUserId(0);
		//Result<Integer> result = weixinService.sendWeixinTemplate(wtp);
		
		AccessToken at = WeixinUtil.getAccessToken();
		String url = WeixinUtil.WEIXIN_JS_TICKET.replace("ACCESS_TOKEN", at.getToken());
		JSONObject json = WeixinUtil.doGetStr(url);
		String ticket = json.getString("ticket");
		System.out.println("js ticket is "+ticket);
		
		// 这里测试发送邮件
		/*
		 * EmailDTO email = new EmailDTO(); 
		 * email.setAppend_info("append_info");
		 * email.setBussName("test"); 
		 * email.setContent("test test test");
		 * email.setMailTitle("test success"); 
		 * String toEmail = "80281075@qq.com"; 
		 * email.setToEmail(toEmail); 
		 * email.setType(1);
		 */
		EmailDTO email = getSmsParam(param);
		Result result = null;
		System.out.println("【==>】次发送邮件开始");
		result = emailFacade.sendEmail(email);
		System.out.println("【==>】次发送邮件结束");
		if (result.getRet().equals("0")) {
			model.addAttribute("sendStatus", "send success");
		} else {
			model.addAttribute("sendStatus", "send fail");
		}

		return "index";
	}

	private EmailDTO getSmsParam(String msg) {
		EmailDTO param = null;
		try {
			msg = URLDecoder.decode(msg, "utf-8");
			param = JSONObject.parseObject(msg, EmailDTO.class);
			if (null == param) {
				throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
			}
			return param;
		} catch (Exception e) {
			throw WebException.WEB_REQ_ARGS_FORMAT_ERROR;
		}
	}

}
