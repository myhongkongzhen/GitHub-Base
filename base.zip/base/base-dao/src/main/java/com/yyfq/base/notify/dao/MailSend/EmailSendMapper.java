package com.yyfq.base.notify.dao.MailSend;

import java.util.Date;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.yyfq.base.notify.dao.entity.MailSend.TEmailSend;

/**
 * @ClassName: EmailSendMapper.java
 * @Description: 邮件发送dao
 * @author zhuweicheng
 * @date 2016年1月29日
 */
@Repository
public interface EmailSendMapper {
	
	/**
	 * 添加邮件发送记录
	 * @param email
	 * @return void
	 */
	int insert(TEmailSend email);
	
	/**
	 * 修改邮件发送状态
	 * @param id
	 * @param status
	 * @param msg
	 * @param date
	 * @return int
	 */
	int updateEmailStatus(@Param("id")Long id,
						  @Param("status")int status,
						  @Param("msg")String msg,
						  @Param("updateTime")Date date);

}
