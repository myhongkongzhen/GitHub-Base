package com.yyfq.base.notify.dao.weixin.model;

import java.util.Date;

/**
 * @ClassName: TWeixinSend.java
 * @Description: 微信模版发送记录实体
 * @author zhuweicheng
 * @date 2016年2月1日
 */
public class TWeixinSend {
	
	private Long id;
	private Long userId;
	private String submitBussName;//调用服务名称
	private Date submitBussTime;//调用服务时间
	private String title;//模版标题
	private String content;//模版内容
	private Date createTime;
	private Date updateTime;
	private int status;//-1发送中，0成功，1失败
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getSubmitBussName() {
		return submitBussName;
	}
	public void setSubmitBussName(String submitBussName) {
		this.submitBussName = submitBussName;
	}
	public Date getSubmitBussTime() {
		return submitBussTime;
	}
	public void setSubmitBussTime(Date submitBussTime) {
		this.submitBussTime = submitBussTime;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
