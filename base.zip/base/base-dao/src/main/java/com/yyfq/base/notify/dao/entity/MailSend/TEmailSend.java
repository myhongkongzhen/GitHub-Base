package com.yyfq.base.notify.dao.entity.MailSend;

import java.util.Date;

public class TEmailSend {
	
	private Long id;
	private String mailTitle;//标题
	private String content;//内容
	private String mailPath;//附件地址
	private String toEmail;//收件人
	private String fromEmail;//发件人
	private String recerveName;//收件人姓名
	private String submitBussName;//调用服务名称
	private Date submitBussTime;//调用服务时间
	private Date sendTime;//发送时间
	private Date updateTime;//更新时间
	private Integer status;//状态，0失败，1成功
	private Integer sendType;//发送类型
	private String sendErrMsg;//发送失败描述
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMailTitle() {
		return mailTitle;
	}
	public void setMailTitle(String mailTitle) {
		this.mailTitle = mailTitle;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getMailPath() {
		return mailPath;
	}
	public void setMailPath(String mailPath) {
		this.mailPath = mailPath;
	}
	public String getToEmail() {
		return toEmail;
	}
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}
	public String getFromEmail() {
		return fromEmail;
	}
	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	public String getRecerveName() {
		return recerveName;
	}
	public void setRecerveName(String recerveName) {
		this.recerveName = recerveName;
	}
	public String getSubmitBussName() {
		return submitBussName;
	}
	public void setSubmitBussName(String submitBussName) {
		this.submitBussName = submitBussName;
	}
	public Date getSubmitBussTime() {
		return submitBussTime;
	}
	public void setSubmitBussTime(Date submitBussTime) {
		this.submitBussTime = submitBussTime;
	}
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getSendType() {
		return sendType;
	}
	public void setSendType(Integer sendType) {
		this.sendType = sendType;
	}
	public String getSendErrMsg() {
		return sendErrMsg;
	}
	public void setSendErrMsg(String sendErrMsg) {
		this.sendErrMsg = sendErrMsg;
	}
	
}
