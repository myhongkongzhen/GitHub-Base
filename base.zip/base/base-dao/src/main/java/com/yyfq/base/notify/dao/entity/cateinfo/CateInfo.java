package com.yyfq.base.notify.dao.entity.cateinfo;

/**
 * @ClassName: CateInfo.java
 * @Description: 属性明细实体
 * @author zhuweicheng
 * @date 2016年3月18日
 */
public class CateInfo {

	private long id;
	private String cateCode;// 分类编码
	private String name;// 属性名称
	private String code;// 属性编码
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCateCode() {
		return cateCode;
	}
	public void setCateCode(String cateCode) {
		this.cateCode = cateCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
