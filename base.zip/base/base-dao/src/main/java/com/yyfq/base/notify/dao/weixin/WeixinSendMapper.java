package com.yyfq.base.notify.dao.weixin;

import java.util.Date;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.yyfq.base.notify.dao.weixin.model.TWeixinSend;
import com.yyfq.base.notify.dao.weixin.model.WeixinUser;

/**
 * @ClassName: WeixinMapper.java
 * @Description: 微信模版发送记录dao层类
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@Repository
public interface WeixinSendMapper {

	/**
	 * 插入微信模版发送记录
	 * @param tws
	 * @return int
	 */
	int insertTWeixinSend(TWeixinSend tws);

	/**
	 * 修改发送状态
	 * @param status
	 * @param id
	 * @param date
	 * @return int
	 */
	int updateStatus(@Param("status")int status,@Param("id") Long id,@Param("date") Date date);

}
