package com.yyfq.base.notify.dao.weixin;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.yyfq.base.notify.dao.weixin.model.WeixinUser;

/**
 * @ClassName: WeixinMapper.java
 * @Description: 微信用户dao层类
 * @author zhuweicheng
 * @date 2016年1月22日
 */
@Repository
public interface WeixinMapper {

	/**
	 * 通过openId查找微信用户
	 * @param openId
	 * @return
	 */
	WeixinUser findByOpenid(@Param("openId") String openId);

	/**
	 * 添加微信用户
	 * @param weixinUser
	 * @return int
	 */
	int insertWeixinUser(WeixinUser wxUser);

	/**
	 * 更新微信用户信息
	 * @param openId
	 * @param nickName
	 * @param sex
	 * @param city
	 * @param country
	 * @param province
	 * @param headImgUrl
	 * @param subStatus
	 * @return int
	 */
	int updateWeixinUser(@Param("openId")String openId, 
						@Param("nickName")String nickName,
						@Param("sex")int sex, 
						@Param("city")String city,
						@Param("country")String country, 
						@Param("province")String province, 
						@Param("headImgUrl")String headImgUrl, 
						@Param("subStatus")int subStatus);

	/**
	 * 更新微信用户二维码场景值
	 * @param scene
	 * @return int
	 */
	int updateWeixinScene(@Param("scene")Integer scene,@Param("openId")String openId);

	/**
	 * 更新微信用户关注状态
	 * @param openId
	 * @param subStatus
	 * @return int
	 */
	int updateSubStatus(@Param("openId")String openId,@Param("subStatus") int subStatus);

	/**
	 * 通过用户查找openId
	 * @param userId
	 * @return String
	 */
	String getOpenIdByUser(@Param("userId")long userId);

}
