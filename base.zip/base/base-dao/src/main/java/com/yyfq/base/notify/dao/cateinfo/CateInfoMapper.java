package com.yyfq.base.notify.dao.cateinfo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yyfq.base.notify.dao.entity.cateinfo.CateInfo;


@Repository
public interface CateInfoMapper {

	List<CateInfo> queryCateInfoList(CateInfo cateInfoDto);

}
